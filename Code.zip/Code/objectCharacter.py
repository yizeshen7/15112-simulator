
import random

#Write repr to return all these characterse
# implement the expected value fucntion
    #You would enter the slideselection, it would calculate expected gain from the event
    #You would then check for the second best.


class Character(object):

    def __init__(self, fname, lname, health, sanity, knowledge, profAtt, TAAtt, 
                    grade, conscience, items, attributes):
        self.fname = fname
        self.lname = lname
        self.health = health
        self.sanity = sanity
        self.knowledge = knowledge
        self.profAtt = profAtt
        self.TAAtt = TAAtt
        self.grade = grade
        self.conscience = conscience
        self.items = items
        self.attributes = attributes
        self.base = 64
        self.actionPoint = 4
        self.pathMap = []

    def __repr__(self):
        return (self.fname, self.lname, self.health, self.sanity, self.knowledge, 
                    self.profAtt, self.TAAtt, 
                    self.grade, self.conscience, 
                    self.items, self.attributes)
    
    def modify(self, stats, value):
        if isinstance(value, int):
            stats += value
        elif isinstance(value, str):
            stats = stats.append(value)
        else:
            pass

    def statsModifer(self, n, current, base):
        pass


    def choiceDiction(self, time): #implement time segment?
        result = {}
        choices = ["The Fence", "Recitation", "Dorm", "GHC", "iNoodle", 
                    "La Prima", "The Cut", "Entropy", "Lecture"]
        
        academic = ["Lecture", "Recitation", "GHC"]
        social = ["iNoodle", "La Prima", "The Cut"]
        unknown = ["Dorm", "Entropy", "The Fence"]

        morning = ["Dorm", "La Prima", "The Cut","Lecture",]
        afternoon = ["GHC", "Recitation", "The Cut",
                    "Dorm"]
        evening = [ "iNoodle", "GHC", "Entropy",  "Dorm"]
        night = ["Entropy", "GHC",  "Dorm", ]

        if time == "Morning":

            choices = morning
        elif time == "Afternoon":
            choices = afternoon
        elif time == "Evening":
            choices = evening
        elif time == "Night":
            choices = night

        healthRecover = {'Lecture': -6, 'Recitation': -4, 
                        'Dorm': 8, 'GHC': -4, 'iNoodle': 6, 
                        'La Prima': 4, 'The Cut': -4, 'Entropy': 0, 
                        'The Fence': 0}

        sanRecover = {'Lecture': -10, 'Recitation': -8, 
                        'Dorm': 2, 'GHC': -2, 'iNoodle': 2, 
                        'La Prima': 1, 'The Cut': 8, 'Entropy': 0, 
                        'The Fence': 0}

        knowGain = {'Lecture': 16, 'Recitation': 12, 
                    'Dorm': -10, 'GHC': 6, 'iNoodle': -8, 
                    'La Prima': -5, 'The Cut': -4, 'Entropy': 0, 
                    'The Fence': 0}

        healthScore = (self.health / self.base)
        sanScore = (self.sanity / self.base)
        knowScore = ((self.knowledge + 1) / 50)


        for choice in choices:

            totalScore = 0

            if choice not in result:
                result[choice] = totalScore

            score1 = healthRecover[choice]
            score2 = sanRecover[choice]
            score3 = knowGain[choice]

            totalScore = -(score1 * healthScore + \
                        score2 * sanScore + \
                        score3 * knowScore)

            
            result[choice] = totalScore

        return result

    def suggestChoice(self, result):
        bestLocation = "None"
        bestScore = -999
        secondLocation = "None"
        secondScore = -9999
        for location in result:
            if result[location] > bestScore:
                secondLocation = bestLocation
                secondScore = bestScore
                bestLocation = location
                bestScore = result[location]
        return (secondLocation, secondScore)
            

            

Ben = Character("Ben", "JR", 64 , 48, 99, 0, 4, 99, True, 
                ["orange", "apple", "pen"], ["gifted"])

S1 = Character("None", "None", 0 ,0, 0, 0, 0, 0, False, 
                [], [])

S2 = Character("None", "None", 64 , 48, 99, 0, 4, 99, True, 
                ["lemon"], ["doesNothingRight"])

#print(Ben.choiceDiction())
#result = Ben.choiceDiction()
#print(Ben.suggestChoice(result))




