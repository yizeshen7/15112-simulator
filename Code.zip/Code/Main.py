

import slideTitle
import objectDate
import objectCharacter
import objectText

import random
import pygame
pygame.init()
screen = pygame.display.set_mode((1280, 720))
pygame.display.set_caption("15-112 Simulator")


#Main Loop
clock = pygame.time.Clock()
run = True
current = "slideTitle"
while run == True:
    clock.tick(200)


    if current == "slideTitle":
        time = (objectDate.current.hourSymbol[objectDate.current.hour], 
                                f'Day {objectDate.current.day}', 
                                f'Week {objectDate.current.week}')

        slideTitle.display(time)
        
    #insert

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            run = False
 
    pygame.display.update()

pygame.quit()

