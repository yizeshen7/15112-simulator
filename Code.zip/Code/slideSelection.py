
import slideShop
import slideUCDrama
import slideDorm
import slideiNoodle
import slideRecitation
import slideEspresso
import slideLecture
import slideGHC
import slideFence
import slideFinal

import slideOHQ
import slideZoom

import objectDate
import objectCharacter
import objectText

import pygame
pygame.init()
screen = pygame.display.set_mode((1280, 720))
pygame.display.set_caption("blank")

class Line(object):
    grey = (105, 105, 105)
    white = (255, 255, 255)
    def __init__(self, canvas, color, sp, ep, width):
        self.canvas = canvas
        self.color = color
        self.sp = sp
        self.ep = ep
        self.width = width
    
    def draw(self):
        pygame.draw.line(self.canvas, self.color, self.sp, self.ep,
                            self.width)

class Rect(object):
    grey = (105, 105, 105)
    white = (255, 255, 255)
    def __init__(self, canvas, color, tlsize):
        self.canvas = canvas
        self.color = color
        self.tlsize = tlsize
    
    def draw(self):
        pygame.draw.rect(self.canvas, self.color, self.tlsize)

#OHQ
class Clickable(object):
    hovered = False

    def __init__(self, text, size, pos, tilt):
        self.text = text
        self.pos = pos
        self.size = size
        self.tilt = tilt
        self.clicked = False
        self.set_rect()
        self.draw()

    def set_rend(self):
        font = pygame.font.SysFont('Times New Roman', self.size)
        self.rend = font.render(self.text, True, self.getcolor())
        self.rend = pygame.transform.rotate(self.rend, self.tilt)
        
    def getcolor(self):
        if self.hovered:
            return (0, 0, 0)
        else:
            return (105, 105, 105)
        
    def set_rect(self):
        self.set_rend()
        self.rect = self.rend.get_rect()
        self.rect.topleft = (self.pos)

    def draw(self):
        self.set_rend()
        screen.blit(self.rend, self.rect) #The text    


class Text(object):
    grey = (105, 105, 105)
    white = (255, 255, 255)

    def __init__(self, text, size, pos, tilt):
        self.text = text
        self.pos = pos
        self.size = size
        self.tilt = tilt
    
    def draw(self):
        font = pygame.font.SysFont('Times New Roman', self.size)
        rend = font.render(self.text, True, self.grey)
        rend = pygame.transform.rotate(rend, self.tilt)
        screen.blit(rend, (self.pos))


class Character(object):

    def __init__(self, text, size, pos, speed):
        self.text = text
        self.size = size
        self.pos = pos
        self.speed = speed
        self.set_rect()
        self.endPoint = (0,0)
        self.pos = pygame.Vector2(self.pos)
        self.set_target(self.pos)

    def set_target(self, pos):
        self.target = pygame.Vector2(pos)
        self.endPoint = pos

    def set_rend(self):
        font = pygame.font.SysFont('Times New Roman', self.size)
        self.rend = font.render(self.text, True, (105, 105, 105))

    def set_rect(self):
        self.set_rend()
        self.rect = self.rend.get_rect()
        self.box = (self.pos[0], self.pos[1], self.rect[2], self.rect[3])
        self.rect.topleft = self.pos
    
    def draw(self):
        font = pygame.font.SysFont('Times New Roman', self.size)
        rend = font.render(self.text, True, (105, 105, 105))
        screen.blit(rend, self.pos)

    #Concept(normalize_ip) taken from https://stackoverflow.com/questions/16288905/make-a-sprite-move-to-the-mouse-click-position-step-by-step
    def update(self):
        move = self.target - self.pos
        moveLength = move.length()

        if moveLength < self.speed:
            self.pos = self.target

        elif moveLength != 0:
            move.normalize_ip()
            move = move * self.speed
            self.pos += move

        self.box = (self.pos[0], self.pos[1], self.rect[2], self.rect[3])
    


Line1 = Line(screen, (105,105,105), (80,80), (900,80), 4)
Line2 = Line(screen, (105,105,105), (80,80), (80,380), 4)
Line3 = Line(screen, (105,105,105), (80,380), (900,380), 4)
Line4 = Line(screen, (105,105,105), (900,80), (900,380), 4)

Line5 = Line(screen, (105,105,105), (920,80), (1080,80), 4)
Line6 = Line(screen, (105,105,105), (920,80), (920,380), 4)
Line7 = Line(screen, (105,105,105), (920,380), (1080,380), 4)
Line8 = Line(screen, (105,105,105), (1080,80), (1080,380), 4)

Line9 = Line(screen, (105,105,105), (80,400), (1080,400), 4)
Line10 = Line(screen, (105,105,105), (80,400), (80,680), 4)
Line11 = Line(screen, (105,105,105), (80,680), (1080,680), 4)
Line12 = Line(screen, (105,105,105), (1080,400), (1080,680), 4)

Line13 = Line(screen, (105,105,105), (1100,80), (1170,80), 4)
Line14 = Line(screen, (105,105,105), (1100,680), (1170,680), 4)
Line15 = Line(screen, (105,105,105), (1100,80), (1100,680), 4)
Line16 = Line(screen, (105,105,105), (1170,80), (1170,680), 4)

#ScrollIndicator
Line17 = Line(screen, (105,105,105), (1055,420), (1055,660), 4) #Black 240
Line18 = Line(screen, (255,255,255), (1055,440), (1055,490), 4) #White 50

#itemBlock
rect1 = Rect(screen, (105,105,105), (1113,120,45,45)) #Item bar 1-5
rect2 = Rect(screen, (105,105,105), (1113,240,45,45))
rect3 = Rect(screen, (105,105,105), (1113,360,45,45))
rect4 = Rect(screen, (105,105,105), (1113,480,45,45))
rect5 = Rect(screen, (105,105,105), (1113,600,45,45))


#Game frame

day = Text("None", 33, (85,30), 0)
week = Text("None", 33, (195,10), 0)
hour = Text("None", 33, (335,40), 0)

#How to smartly break lines
firstLine = Text("...Click on locations to enter the time segment, press space to exit",
                        30, (100,420), 0)
secondLine = Text("tempor incididunt ut labore et dolore magna aliqua.",
                         30, (110,450), 0)
thirdLine = Text("...Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu",
                         30,(100,500), 0)
fourthLine = Text("fugiat nulla pariatur.",
                         30,(110,530), 0)
fifthLine = Text("...Etiam erat velit scelerisque in. Metus dictum at tempor commodo ullamco",
                         30,(100,580), 0)
sixthLine = Text("met nisl purus consequat id porta nibh in mollis nunc sed id semper.",
                         30,(110,610), 0)
#Lecture Outline
Line19 = Line(screen, (105,105,105), (230,230), (746,230), 2)
Line20 = Line(screen, (105,105,105), (80,380), (230,230), 2)
Line21 = Line(screen, (105,105,105), (900,380), (746,230), 2)
Line22 = Line(screen, (105,105,105), (230,80), (230,230), 2)
Line23 = Line(screen, (105,105,105), (746,80), (746,230), 2)

Line24 = Line(screen, (105,105,105), (430,380), (480,270), 2) #inner outline
Line25 = Line(screen, (105,105,105), (570,380), (520,270), 2)

Line26 = Line(screen, (105,105,105), (640,80), (640,200), 1) #Screen
Line27 = Line(screen, (105,105,105), (340,80), (340,200), 1)
Line28 = Line(screen, (105,105,105), (340,200), (640,200), 1)
Line29 = Line(screen, (105,105,105), (340,80), (640,80), 1)



#Lecture things
you = Character("You", 18, (700,315), 3)

text0 = Text("Where to", 36, (110, 100), 0)


click1 = Clickable("Lecture", 30, (220,170), 0)
text1 = Text("Lecture", 30, (220,170), 0)

click2 = Clickable("Recitation", 30, (210,240), 0)
text2 = Text("Recitation", 30, (210,240), 0)

click3 = Clickable("GHC", 30, (230,310), 0)
text3 = Text("GHC", 30, (230,310), 0)

click4 = Clickable("iNoodle", 30, (460,170), 0)
text4 = Text("iNoodle", 30, (460,170), 0)

click5 = Clickable("Dorm", 30, (470,240), 0)
text5 = Text("Dorm", 30, (470,240), 0)

click6 = Clickable("La Prima", 30, (450,310), 0)
text6 = Text("La Prima", 30, (450,310), 0)

click7 = Clickable("The Cut", 30, (700,170), 0)
text7 = Text("The Cut", 30, (700,170), 0)

click8 = Clickable("Entropy", 30, (700,240), 0)
text8 = Text("Entropy", 30, (700,240), 0)

click9 = Clickable("The Fence", 30, (680,310), 0)
text9 = Text("The Fence", 30, (680,310), 0)

click10 = Clickable("Final", 30, (470, 110), 0)
#Emploee
#employee1 = Clickable("employee", 18, (565,265), -45)

morning = [click1, click5, click6, click7]

afternoon = [click2, click3, click5, click7]

evening = [click3, click4, click5]

night = [click3, click5, click8]


time = [hour, day, week]

'''
frames = [firstLine, secondLine, thirdLine, fourthLine, 
        fifthLine, sixthLine]
'''
texts = [text0]

clickables = [click1, click2, click3, click4, click5, click6, click7,
            click8, click9, click10]


Lines = [Line1, Line2, Line3, Line4, Line5, Line6, Line7, Line8, Line9, Line10, 
        Line11, Line12, Line13, Line14, Line15, Line16, Line17, Line18]

rects = [rect1, rect2, rect3, rect4, rect5]

characters = []



def updateProgress():
    objectDate.current.progress()

def display(time):

    clock = pygame.time.Clock()
    clock.tick(200)
    pygame.event.pump()
    screen.fill((255, 255, 255))

    fname = Text(str(objectCharacter.Ben.fname), 28, (950,150), 0)
    fname.draw()
    health = Text(f'Health: {str(objectCharacter.Ben.health)}', 24, (930,280), 0)
    sanity = Text(f'Sanity: {str(objectCharacter.Ben.sanity)}', 24, (930,310), 0)
    knowledge = Text(f'Knowledge: {str(objectCharacter.Ben.knowledge)}', 24, (930,340), 0)
    health.draw()
    sanity.draw()
    knowledge.draw()



    objectText.textBox.draw()

    if objectCharacter.Ben.knowledge > 111:
        if click10.rect.collidepoint(pygame.mouse.get_pos()):
                    click10.hovered = True
        else:
            click10.hovered = False
        click10.draw()   



#Draw top hour day week
    day = Text(time[1], 33, (85,30), 0)
    week = Text(time[2], 33, (195,10), 0)
    hour = Text(time[0], 33, (335,40), 0)
    hour.draw()
    day.draw()
    week.draw()


#Original Frame
    for line in Lines:
        line.draw()
    
    for rect in rects:
        rect.draw()
        
#Game Frames
    timeSeg = objectDate.current.hourSymbol[objectDate.current.hour]


    choiceDiction = objectCharacter.Ben.choiceDiction(timeSeg)
    #print(choiceDiction)
    suggestion = objectCharacter.Ben.suggestChoice(choiceDiction)
    #print(suggestion)
    displaySuggestion = Text(f'suggestion: {suggestion[0]}', 24, (660,110), 0)
    displaySuggestion.draw()


    #print(isinstance(timeSeg, str))
    if timeSeg == "Morning":
        for location in morning:
            if isinstance(location, Clickable):
                if location.rect.collidepoint(pygame.mouse.get_pos()):
                    location.hovered = True
                else:
                    location.hovered = False
            location.draw()

    elif timeSeg == "Afternoon":
        for location in afternoon:
            if isinstance(location, Clickable):
                if location.rect.collidepoint(pygame.mouse.get_pos()):
                    location.hovered = True
                else:
                    location.hovered = False
            location.draw()

    elif timeSeg == "Evening":
        for location in evening:
            if isinstance(location, Clickable):
                if location.rect.collidepoint(pygame.mouse.get_pos()):
                    location.hovered = True
                else:
                    location.hovered = False
            location.draw()
        

    elif timeSeg == "Night":
        for location in night:
            if isinstance(location, Clickable):
                if location.rect.collidepoint(pygame.mouse.get_pos()):
                    location.hovered = True
                else:
                    location.hovered = False
            location.draw()

    


#texts
    for text in texts:
        text.draw()

#Keys and sticks
    keys = pygame.key.get_pressed()

    if keys[pygame.K_SPACE]:
        print ("space detected")
        pass

    for event in pygame.event.get():

        if event.type == pygame.QUIT:
            run = False
            pygame.quit()

        if event.type == pygame.MOUSEBUTTONUP:
            for click in clickables:
                if click.rect.collidepoint(pygame.mouse.get_pos()):
                    if click == click1: #lecture
                        while True:
                            time = (objectDate.current.hourSymbol[objectDate.current.hour], 
                                f'Day {objectDate.current.day}', 
                                f'Week {objectDate.current.week}')

                            slideLecture.display(time)

                            if slideLecture.display(time) == 42:
                                objectDate.current.progress()
                                while True:
                                    display(time)


                    elif click == click2: #recitation
                        while True:
                            time = (objectDate.current.hourSymbol[objectDate.current.hour], 
                                f'Day {objectDate.current.day}', 
                                f'Week {objectDate.current.week}')

                            slideRecitation.display(time)

                            if slideRecitation.display(time) == 42:
                                objectDate.current.progress()
                                while True:
                                    display(time)


                    elif click == click3: #GHC
                        while True:
                            time = (objectDate.current.hourSymbol[objectDate.current.hour], 
                                f'Day {objectDate.current.day}', 
                                f'Week {objectDate.current.week}')

                            slideGHC.display(time)

                            if slideGHC.display(time) == 42:
                                objectDate.current.progress()
                                while True:
                                    display(time)

                    elif click == click4:  #iNoodle
                        while True:
                            time = (objectDate.current.hourSymbol[objectDate.current.hour], 
                                f'Day {objectDate.current.day}', 
                                f'Week {objectDate.current.week}')

                            slideiNoodle.display(time)

                            if slideiNoodle.display(time) == 42:
                                objectDate.current.progress()
                                while True:
                                    display(time)

                    elif click == click5: #Dorm
                        while True:
                            time = (objectDate.current.hourSymbol[objectDate.current.hour], 
                                f'Day {objectDate.current.day}', 
                                f'Week {objectDate.current.week}')

                            slideDorm.display(time)

                            if slideDorm.display(time) == 42:
                                objectDate.current.progress()
                                while True:
                                    display(time)

                    elif click == click6: #La Prima
                        while True:
                            time = (objectDate.current.hourSymbol[objectDate.current.hour], 
                                f'Day {objectDate.current.day}', 
                                f'Week {objectDate.current.week}')

                            slideEspresso.display(time)

                            if slideEspresso.display(time) == 42:
                                objectDate.current.progress()
                                while True:
                                    display(time)

                    elif click == click7: #The Cut
                        while True:
                            time = (objectDate.current.hourSymbol[objectDate.current.hour], 
                                f'Day {objectDate.current.day}', 
                                f'Week {objectDate.current.week}')

                            slideUCDrama.display(time)

                            if slideUCDrama.display(time) == 42:
                                objectDate.current.progress()
                                while True:
                                    display(time)

                    elif click == click8: #Entrollpy
                        while True:
                            time = (objectDate.current.hourSymbol[objectDate.current.hour], 
                                f'Day {objectDate.current.day}', 
                                f'Week {objectDate.current.week}')
        
                            slideShop.display(time)

                            if slideShop.display(time) == 42:
                                objectDate.current.progress()
                                while True:
                                    display(time)

                    elif click == click9: #The Fence
                        while True:
                            time = (objectDate.current.hourSymbol[objectDate.current.hour], 
                                f'Day {objectDate.current.day}', 
                                f'Week {objectDate.current.week}')
                    
                            slideFence.display(time)

                            if slideFence.display(time) == 42:
                                objectDate.current.progress()
                                while True:
                                    display(time)

                    elif click == click10:
                        objectText.textBox.bundle("Good luck! As if you needed it.", 99)
                        objectText.textBox.bundle("Use re = True/False if you want to return something, use 'greater than' for >, 'smaller than' for <.", 99)
                        objectText.textBox.bundle("Left arrow key is '(', right arrow is ')', and '*' is up arrow.", 99)
                        objectText.textBox.bundle("Click 'check' to check for syntax, 'run' to run your code in Python", 99)
                        objectText.textBox.bundle("Please write the function defined above", 99)
                        objectText.textBox.bundle("Welcome to final for 15-112 simulator.", 99)
                        while True:
                            slideFinal.display(time)


    pygame.display.update()



