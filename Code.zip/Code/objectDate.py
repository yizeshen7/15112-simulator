

class Time(object):
    def __init__(self, hour, day, week):
        self.hour = hour
        self.day = day
        self.week = week
        self.hourSymbol = ["Morning", "Afternoon", "Evening", "Night"]
    
    def progress(self):

        self.hour += 1
        if self.hour > 3:
            self.hour = 0
            self.day += 1
            if self.day > 4:
                self.day = 1
                self.week += 1

        
        result = (self.hourSymbol[self.hour], 
                f'Day {self.day}', f'Week {self.week}')

        return result

current = Time(0, 1, 1)
