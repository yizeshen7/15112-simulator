
import pygame
import random
import objectCharacter
pygame.init()
#potentially just one big, giant text box class, when press update, automatically rearrange?

class TextBox(object):
    grey = (105, 105, 105)
    white = (255, 255, 255)
    
    #potentially second pos, second text, 
    def __init__(self):
        self.size = 24
        self.line1 = "...Welcome to 15-112 simulator!"
        self.line2 = "...Click on first and last name to enter your name."
        self.line3 = "...Press 'start' to start the game, have fun!"
        self.line4 = "...By Sean Shen"
        self.line5 = ""
        self.line6 = ""
        self.screen = pygame.display.set_mode((1280, 720))


    def modify(self, text, san):
        result = ""
        original = text

        scrabble = ['妗', '冩', '爲', '銆', '佹', '潖', '鏍', '戙', '佹', '鏍', '戯', 
                    '紝', '浣', '犱', '笉', '璁', '垜', '锛', '屾', '垜', '涓', '嶈', 
                    '浣', '狅', '紝', '閮', '藉', '紑', '婊', '簡', '鑺', '辫', 
                    '瓒', '熷', '効', '銆', '傜', '孩', '鐨', '勫', '儚', '鐏',  
                    '紝', '绮', '夌', '殑', '鍍', '忛', '湠', '锛', '岀', '櫧', '鐨', 
                    '勫', '儚', '闆', '傝', '姳', '閲', '屽', '甫', '鐫', '鐢', '滃', 
                    '懗', '锛', '岄', '棴', '浜', '嗙', '溂', '锛', '屾', '爲', '涓', 
                    '婁', '豢', '浣', '涘', '凡', '缁', '忔', '鍎', '裤', '灏', '忕', 
                    '殑', '铦', '磋', '澏', '椋', '炴', '潵', '椋', '炲', '幓', '銆', 
                    '傞', '噹', '鑺', '遍', '亶', '鍦', '版', '槸', '锛', '氭', '潅', 
                    '鏍', '峰', '効', '锛', '屾', '湁', '鍚', '嶅', '瓧', '鐨', '勶', 
                    '紝', '娌', '悕', '瀛', '楃', '殑', '锛', '屾', '暎', '鍦', 
                    '崏', '涓', '涢', '噷', '锛', '屽', '儚', '鐪', '肩', '潧', '锛', 
                    '屽', '儚', '鏄', '熸', '槦', '锛', '岃', '繕', '鐪', '憖', 
                    '鐪', '殑', '銆', '闈', '笉', '瀵', '掓', '潹', '鏌', '抽',  
                    '鈥', '濓', '紝', '涓', '嶉', '敊', '鐨', '勶', '紝', '鍍', '忔', 
                    '瘝', '浜', '茬', ' 殑', '鎵', '嬫', '姎', '鎽', '哥', '潃', 
                    '浣', '犮', '笂', '椋', '庣', '瓭', '娓', '愭', '笎', '澶', '氫', 
                    '簡', '锛', '屽', '湴', '涓', '婂', '瀛', '愪', '篃', 
                    '澶', '氫', '簡', '銆', '傚', '煄', '閲', '屼', '埂', '涓', '嬶', 
                    '紝', '瀹', '跺', '卞', '拹', '鑼', '舵', '埧', '锛', '岀', '敋', 
                    '鏄', '粩', '缁', '嗐', '莠',

                    "!", "@", "#", "$", "%", "^", "&", "*", "?", ">", "<", 
                    ":", "}", "{", "+", "=", "_", "-"

                    "!", "@", "#", "$", "%", "^", "&", "*", "?", ">", "<", 
                    ":", "}", "{", "+", "=", "_", "-"

                    ]

        for letter in original:
            hold = letter
            dice = random.randint(1, 48)
            if letter.isalnum():
                if dice >= san:
                    hold = random.choice(scrabble)
            result = result + hold

        return result


    def breakLine(self, text):
        temp1 = text
        temp2 = ""
        if len(text) >= 72:
            breaker = 72
            for i in range(50, 72):
                if text[i] == " " or text[i] == "," \
                    or text[i] == ".":
                    breaker = i
            temp1 = text[:breaker]
            temp2 = text[breaker:]  
        return (temp1, temp2)

    def update(self, chunk):
        if len(chunk[1]) == 0:
            self.line6 = self.line5
            self.line5 = self.line4
            self.line4 = self.line3
            self.line3 = self.line2
            self.line2 = self.line1
            self.line1 = f'...{chunk[0]}'

        else:
            self.line6 = self.line4
            self.line5 = self.line3
            self.line4 = self.line2
            self.line3 = self.line1
            self.line2 = f'{chunk[1]}'
            self.line1 = f'...{chunk[0]}'

    def draw(self):
        font = pygame.font.SysFont('SimHei', self.size)

        rend1 = font.render(self.line1, True, self.grey)
        rend2 = font.render(self.line2, True, self.grey)
        rend3 = font.render(self.line3, True, self.grey)
        rend4 = font.render(self.line4, True, self.grey)
        rend5 = font.render(self.line5, True, self.grey)
        rend6 = font.render(self.line6, True, self.grey)

        self.screen.blit(rend1, (100,420))
        self.screen.blit(rend2, (100,460))
        self.screen.blit(rend3, (100,500))
        self.screen.blit(rend4, (100,540))
        self.screen.blit(rend5, (100,580))
        self.screen.blit(rend6, (100,620))

    def bundle(self, text, san):
        shuffled = self.modify(text, san)
        breaked = textBox.breakLine(shuffled)
        updated = textBox.update(breaked)
        self.draw()

textBox = TextBox()

'''
textBox.bundle("The quick fox jumps over the lazy dog, I have no idea what I am doing right now, but hey, so doesn't anyone else...", 36)
textBox.bundle("The quick fox jumps over the lazy dog, I have no idea what I am doing right now, but hey, so doesn't anyone else...", 36)
textBox.bundle("The quick fox jumps over the lazy dog, I have no idea what I am doing right now, but hey, so doesn't anyone else...", 36)

print(textBox.line1)
print(textBox.line2)
print(textBox.line3)
print(textBox.line4)
print(textBox.line5)
print(textBox.line6)
'''