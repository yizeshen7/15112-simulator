import objectDate
import objectCharacter
import objectText
import slideTitle

import pygame
pygame.init()
screen = pygame.display.set_mode((1280, 720))
pygame.display.set_caption("blank")

class Line(object):
    grey = (105, 105, 105)
    white = (255, 255, 255)
    def __init__(self, canvas, color, sp, ep, width):
        self.canvas = canvas
        self.color = color
        self.sp = sp
        self.ep = ep
        self.width = width
    
    def draw(self):
        pygame.draw.line(self.canvas, self.color, self.sp, self.ep,
                            self.width)

class Rect(object):
    grey = (105, 105, 105)
    white = (255, 255, 255)
    def __init__(self, canvas, color, tlsize):
        self.canvas = canvas
        self.color = color
        self.tlsize = tlsize
    
    def draw(self):
        pygame.draw.rect(self.canvas, self.color, self.tlsize)

#OHQ
class Clickable(object):
    hovered = False

    def __init__(self, text, size, pos, tilt):
        self.text = text
        self.pos = pos
        self.size = size
        self.tilt = tilt
        self.clicked = False
        self.set_rect()
        self.draw()

    def set_rend(self):
        font = pygame.font.SysFont('Times New Roman', self.size)
        self.rend = font.render(self.text, True, self.getcolor())
        self.rend = pygame.transform.rotate(self.rend, self.tilt)
        
    def getcolor(self):
        if self.hovered:
            return (0, 0, 0)
        else:
            return (105, 105, 105)
        
    def set_rect(self):
        self.set_rend()
        self.rect = self.rend.get_rect()
        self.rect.topleft = (self.pos)

    def draw(self):
        self.set_rend()
        screen.blit(self.rend, self.rect) #The text    


class Text(object):
    grey = (105, 105, 105)
    white = (255, 255, 255)

    def __init__(self, text, size, pos, tilt):
        self.text = text
        self.pos = pos
        self.size = size
        self.tilt = tilt
    
    def draw(self):
        font = pygame.font.SysFont('Times New Roman', self.size)
        rend = font.render(self.text, True, self.grey)
        rend = pygame.transform.rotate(rend, self.tilt)
        screen.blit(rend, (self.pos))


class Character(object):

    def __init__(self, text, size, pos, speed):
        self.text = text
        self.size = size
        self.pos = pos
        self.speed = speed
        self.set_rect()
        self.endPoint = (0,0)
        self.pos = pygame.Vector2(self.pos)
        self.set_target(self.pos)

    def set_target(self, pos):
        self.target = pygame.Vector2(pos)
        self.endPoint = pos

    def set_rend(self):
        font = pygame.font.SysFont('Times New Roman', self.size)
        self.rend = font.render(self.text, True, (105, 105, 105))

    def set_rect(self):
        self.set_rend()
        self.rect = self.rend.get_rect()
        self.box = (self.pos[0], self.pos[1], self.rect[2], self.rect[3])
        self.rect.topleft = self.pos
    
    def draw(self):
        font = pygame.font.SysFont('Times New Roman', self.size)
        rend = font.render(self.text, True, (105, 105, 105))
        screen.blit(rend, self.pos)

    #Concept(normalize_ip) taken from https://stackoverflow.com/questions/16288905/make-a-sprite-move-to-the-mouse-click-position-step-by-step
    def update(self):
        move = self.target - self.pos
        moveLength = move.length()

        if moveLength < self.speed:
            self.pos = self.target

        elif moveLength != 0:
            move.normalize_ip()
            move = move * self.speed
            self.pos += move

        self.box = (self.pos[0], self.pos[1], self.rect[2], self.rect[3])
    



#Lecture things

text1 = Text("Congrats!", 96, (300,100), 0)
text2 = Text("Thanks for playing.", 48, (500,250), 0)

click1 = Clickable("Play again?", 24, (1100,600), 0)
click2 = Clickable("Exit", 24, (1100, 640), 0)




#Emploee
#employee1 = Clickable("employee", 18, (565,265), -45)


texts = [text1, text2]

clickables = [click1, click2]



def display(time):
    run = True
    #pygame.time.delay(100)
    pygame.event.pump()
    screen.fill((255, 255, 255))


#texts
    for text in texts:
        text.draw()

    for click in clickables:
        if click.rect.collidepoint(pygame.mouse.get_pos()):
            click.hovered = True
        else:
            click.hovered = False
        click.draw()

    health = Text(f'Health left: {str(objectCharacter.Ben.health)}', 24, (500, 500), 0)
    sanity = Text(f'Sanity left: {str(objectCharacter.Ben.sanity)}', 24, (500, 530), 0)
    conscience = Text(f'Still have a kind heart? {str(objectCharacter.Ben.conscience)}', 24, (500, 560), 0)
    TAAtt = Text(f'TA Attitude: {str(objectCharacter.Ben.TAAtt)}', 24, (500, 590), 0)
    profAtt = Text(f"Professor's Attitude: {str(objectCharacter.Ben.profAtt)}", 24, (500, 620), 0)

    health.draw()
    sanity.draw()
    conscience.draw()
    TAAtt.draw()
    profAtt.draw()
    
#Keys and sticks
    keys = pygame.key.get_pressed()

    if keys[pygame.K_SPACE]:
        while True:
            slideSelection.display()

    for event in pygame.event.get():

        if event.type == pygame.QUIT:
            run = False

        if event.type == pygame.MOUSEBUTTONUP:
            for click in clickables:
                if click.rect.collidepoint(pygame.mouse.get_pos()):
                    if click == click1: #play agina
                        while True:
                            time = (objectDate.current.hourSymbol[objectDate.current.hour], 
                                f'Day {objectDate.current.day}', 
                                f'Week {objectDate.current.week}')
                            slideTitle.display(time)

                    if click == click2: #exit
                        pygame.quit()
                    

    pygame.display.update()




