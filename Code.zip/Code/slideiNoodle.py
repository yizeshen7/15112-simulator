
import objectDate
import objectCharacter
import objectText
import slideOHQ

import random
import pygame
import heapq

from os import path
from collections import deque

vec = pygame.math.Vector2
pygame.init()
screen = pygame.display.set_mode((1280, 720))
pygame.display.set_caption("testInGameDorm")

class Line(object):
    grey = (105, 105, 105)
    white = (255, 255, 255)
    def __init__(self, canvas, color, sp, ep, width):
        self.canvas = canvas
        self.color = color
        self.sp = sp
        self.ep = ep
        self.width = width
    
    def draw(self):
        pygame.draw.line(self.canvas, self.color, self.sp, self.ep,
                            self.width)

class Rect(object):
    grey = (105, 105, 105)
    white = (255, 255, 255)
    def __init__(self, canvas, color, tlsize):
        self.canvas = canvas
        self.color = color
        self.tlsize = tlsize
    
    def draw(self):
        pygame.draw.rect(self.canvas, self.color, self.tlsize)

class Text(object):
    grey = (105, 105, 105)
    white = (255, 255, 255)

    def __init__(self, text, size, position, tilt):
        self.text = text
        self.pos = position
        self.size = size
        self.tilt = tilt
        self.set_rect()
    
    def set_rect(self):
        font = pygame.font.SysFont('Times New Roman', self.size)
        rend = font.render(self.text, True, self.grey)
        rend = pygame.transform.rotate(rend, self.tilt)
        self.rend = rend
        self.rect = self.rend.get_rect()
        self.box = (self.pos[0], self.pos[1], self.rect[2], self.rect[3])
        self.rect.topleft = self.pos

    def checkCollision(self, playerBox):
    #convert rectangles into x,y,w,h
        playerX = playerBox[0]
        playerY = playerBox[1]
        playerWidth = playerBox[2]
        playerHeight = playerBox[3]

        obstacleX = self.box[0]
        obstacleY = self.box[1]
        obstacleWidth = self.box[2]
        obstacleHeight = self.box[3]

        #get the right left top and bottom
        myRight = playerX + playerWidth
        myLeft = playerX
        myTop = playerY
        myBottom = playerY + playerHeight

        otherRight = obstacleX + obstacleWidth
        otherLeft = obstacleX
        otherTop = obstacleY
        otherBottom = obstacleY + obstacleHeight

        #now the collision code
        checker = True

        if ((myRight < otherLeft) or (myLeft > otherRight) \
            or (myBottom < otherTop) or (myTop > otherBottom)):
            checker = False

        return checker

    def draw(self):
        font = pygame.font.SysFont('Times New Roman', self.size)
        rend = font.render(self.text, True, self.grey)
        rend = pygame.transform.rotate(rend, self.tilt)
        screen.blit(rend, self.pos)

class Character(object):

    def __init__(self, text, size, pos, speed):
        self.text = text
        self.size = size
        self.pos = pos
        self.speed = speed
        self.set_rect()
        self.endPoint = (0,0)
        self.pos = pygame.Vector2(self.pos)
        self.set_target(self.pos)

    def set_target(self, pos):
        self.target = pygame.Vector2(pos)
        self.endPoint = pos

    def set_rend(self):
        font = pygame.font.SysFont('Times New Roman', self.size)
        self.rend = font.render(self.text, True, (105, 105, 105))

    def set_rect(self):
        self.set_rend()
        self.rect = self.rend.get_rect()
        self.box = (self.pos[0], self.pos[1], self.rect[2], self.rect[3])
        self.rect.topleft = self.pos
    
    def draw(self):
        font = pygame.font.SysFont('Times New Roman', self.size)
        rend = font.render(self.text, True, (105, 105, 105))
        screen.blit(rend, self.pos)

    #Concept(normalize_ip) taken from https://stackoverflow.com/questions/16288905/make-a-sprite-move-to-the-mouse-click-position-step-by-step
    def update(self):
        move = self.target - self.pos
        moveLength = move.length()

        if moveLength < self.speed:
            self.pos = self.target

        elif moveLength != 0:
            move.normalize_ip()
            move = move * self.speed
            self.pos += move

        self.box = (self.pos[0], self.pos[1], self.rect[2], self.rect[3])

class Clickable(object):

    def __init__(self, text, size, pos, tilt):
        self.text = text
        self.pos = pos
        self.size = size
        self.tilt = tilt
        self.hovered = False
        self.clicked = False
        self.set_rect()
        self.draw()

    def draw(self):
        self.set_rend()
        screen.blit(self.rend, self.rect)
        
    def set_rend(self):
        font = pygame.font.SysFont('Times New Roman', self.size)
        self.rend = font.render(self.text, True, self.getcolor())
        self.rend = pygame.transform.rotate(self.rend, self.tilt)
        
    def getcolor(self):
        if self.hovered:
            return (0, 0, 0)
        else:
            return (105, 105, 105)
        
    def set_rect(self):
        self.set_rend()
        self.rect = self.rend.get_rect()
        self.box = (self.pos[0], self.pos[1], self.rect[2], self.rect[3])
        self.rect.topleft = self.pos


    #Concept(index into tuples & boxes) from https://stackoverflow.com/questions/35001207/how-to-detect-collision-between-objects-in-pygame
    def checkCollision(self, playerBox):
    #convert rectangles into x,y,w,h
        playerX = playerBox[0]
        playerY = playerBox[1]
        playerWidth = playerBox[2]
        playerHeight = playerBox[3]

        obstacleX = self.box[0]
        obstacleY = self.box[1]
        obstacleWidth = self.box[2]
        obstacleHeight = self.box[3]

        #get the right left top and bottom
        myRight = playerX + playerWidth
        myLeft = playerX
        myTop = playerY
        myBottom = playerY + playerHeight

        otherRight = obstacleX + obstacleWidth
        otherLeft = obstacleX
        otherTop = obstacleY
        otherBottom = obstacleY + obstacleHeight

        #now the collision code
        checker = True

        if ((myRight < otherLeft) or (myLeft > otherRight) \
            or (myBottom < otherTop) or (myTop > otherBottom)):
            checker = False

        return checker

#From https://www.youtube.com/watch?v=fa1NSUBqiJc
class Grid(object):
    def __init__(self, width, height):
        self.width = width
        self.height = height
        self.walls = [(10, 7)]
        #self.connections = [vec(1, 0), vec(-1, 0), vec(0, 1), vec(0, -1), 
                            #vec(-1, 1), vec(-1, -1), vec(1, 1), vec(1, -1)]
        self.connections = [vec(1, 0), vec(-1, 0), vec(0, 1), vec(0, -1)]

    def isInBound(self, node):
        if node.x >= 0 and node.x < self.width:
            if node.y >= 0 and node.y < self.height:
                return True
        return False

    def isPassable(self, node):
        if node in self.walls:
            return False
        return True

    def getNeighbors(self, node):
        counter = 0
        self.neighbors = []
        for direction in self.connections:
            counter += 1
            temp = node + direction
            #Didn't implement no perference path
            if self.isInBound(temp) == True:
                if self.isPassable(temp) == True:
                    self.neighbors.append(temp)
        return self.neighbors

    def draw(self):
        for wall in self.walls:
            rect = pygame.Rect((wall[0])*TILESIZE, (wall[1])*TILESIZE,
                                TILESIZE, TILESIZE)
            pygame.draw.rect(screen, (105, 105, 105), rect)

#From https://www.youtube.com/watch?v=fa1NSUBqiJc
class DijkGrid(Grid):
    def __init__(self, width, height):
        super().__init__(width, height)
        self.weights = {}
    
    def cost(self, fromNode, toNode):
        checker = (abs(fromNode[0] - toNode[0]) - \
                    abs(fromNode[1] - toNode[1])) ** 0.5
        if checker == 1:
            return self.weights.get(toNode, 0) + 10
        else:
            return self.weights.get(toNode, 0) + 14

#From https://www.youtube.com/watch?v=fa1NSUBqiJc
class PriorityQueue(object):
    def __init__(self):
        self.nodes = []

    def put(self, node, cost):
        heapq.heappush(self.nodes, (cost, node))

    def get(self):
        return heapq.heappop(self.nodes)[1]

    def empty(self):
        checker = len(self.nodes)
        if checker == 0:
            return True
        else:
            return False

TILESIZE = 10
GRIDWIDTH = 90 #52
GRIDHEIGHT = 38 #15
WIDTH = TILESIZE * GRIDWIDTH
HEIGHT = TILESIZE * GRIDHEIGHT



def round(n):
    last = n % 10
    if last == 0:
        n = 10
    elif last <= 3:
        n = (n//10) * 10
    elif last > 3:
        n = (n//10) * 10 + 10
    return n

#no need to worry about +230, just a placeholder
#From https://www.youtube.com/watch?v=fa1NSUBqiJc
def drawGrid():
    for x in range(0, WIDTH+1, TILESIZE):
        pygame.draw.line(screen, (105,105,105), (x, 0), (x, HEIGHT))
    for y in range(0, HEIGHT+1, TILESIZE):
        pygame.draw.line(screen, (105,105,105), (0, y), (WIDTH, y))

def getObstacles(things):
    obstacles = []
    for text in things:
        coordinateTop = (text.pos[0]//10, text.pos[1]//10)
        obstacles.append(coordinateTop)

        restX, restY = (round(text.box[2]) //10, round(text.box[3]) //10)
        for i in range (0, restX ):
            for j in range(0, restY):
                coordinateTemp = (coordinateTop[0] + i, coordinateTop[1] + j)
                obstacles.append(coordinateTemp)

    for stuff in obstacles:
        g.weights[stuff] = 20

    return obstacles

def intVec(vector):
    return (int(vector[0]), int(vector[1]))

#Concept (deque) from: https://www.youtube.com/watch?v=hettiSrJjM4
def ruleOfThumb(node1, node2):
    #mahattan distance
    distance = (abs(node1[0] - node2[0]) + \
                    abs(node1[1] - node2[1]))

    value = 10 * distance
    return value

#From https://www.youtube.com/watch?v=fa1NSUBqiJc
def aStar(graph, start, end):
    frontier = PriorityQueue()
    frontier.put(intVec(start), 0)
    path = {}
    cost = {}
    path[intVec(start)] = None
    cost[intVec(start)] = 0

    while frontier.empty() == False:
        current = frontier.get()
        if current == end:
            break
        for next in graph.getNeighbors(vec(current)):
            next = intVec(next)
            nextCost = cost[current] + graph.cost(current, next)
            if next not in cost or nextCost < cost[next]:
                cost[next] = nextCost
                priority = nextCost + ruleOfThumb(end, vec(next))
                frontier.put(next, priority)
                path[next] = vec(current) - vec(next)
    
    return path

def findRoute(diction, playerInital, gridMousePos):
    playerInital = intVec(playerInital)
    pathMap = []
    while playerInital != (gridMousePos): #should be mouse position
        if playerInital in diction:
            tempDirect = diction[playerInital]
            tempDirect = intVec(tempDirect)

            tempPos = (playerInital[0] + tempDirect[0],
                        playerInital[1] + tempDirect[1])

            pathMap.append(tempPos)

            playerInital = tempPos

    print(pathMap)
    return pathMap


g= DijkGrid(90, 38)
path = aStar(g, vec(28,28), vec(70,32))

Line1 = Line(screen, (105,105,105), (80,80), (900,80), 4)
Line2 = Line(screen, (105,105,105), (80,80), (80,380), 4)
Line3 = Line(screen, (105,105,105), (80,380), (900,380), 4)
Line4 = Line(screen, (105,105,105), (900,80), (900,380), 4)

Line5 = Line(screen, (105,105,105), (920,80), (1080,80), 4)
Line6 = Line(screen, (105,105,105), (920,80), (920,380), 4)
Line7 = Line(screen, (105,105,105), (920,380), (1080,380), 4)
Line8 = Line(screen, (105,105,105), (1080,80), (1080,380), 4)

Line9 = Line(screen, (105,105,105), (80,400), (1080,400), 4)
Line10 = Line(screen, (105,105,105), (80,400), (80,680), 4)
Line11 = Line(screen, (105,105,105), (80,680), (1080,680), 4)
Line12 = Line(screen, (105,105,105), (1080,400), (1080,680), 4)

Line13 = Line(screen, (105,105,105), (1100,80), (1170,80), 4)
Line14 = Line(screen, (105,105,105), (1100,680), (1170,680), 4)
Line15 = Line(screen, (105,105,105), (1100,80), (1100,680), 4)
Line16 = Line(screen, (105,105,105), (1170,80), (1170,680), 4)

#ScrollIndicator
Line17 = Line(screen, (105,105,105), (1055,420), (1055,660), 4) #Black 240
Line18 = Line(screen, (255,255,255), (1055,440), (1055,490), 4) #White 50

#itemBlock
rect1 = Rect(screen, (105,105,105), (1113,120,45,45))
rect2 = Rect(screen, (105,105,105), (1113,240,45,45))
rect3 = Rect(screen, (105,105,105), (1113,360,45,45))
rect4 = Rect(screen, (105,105,105), (1113,480,45,45))
rect5 = Rect(screen, (105,105,105), (1113,600,45,45))

#iNoodle outline
Line19 = Line(screen, (105,105,105), (820,80), (850,380), 2) #Right
Line20 = Line(screen, (105,105,105), (130,380), (160,80), 2) #Left
Line21 = Line(screen, (105,105,105), (240,380), (270,80), 2)
Line22 = Line(screen, (105,105,105), (255,380), (285,80), 2)
Line23 = Line(screen, (105,105,105), (310,380), (340,80), 2)

#Game frame
day = Text("Day 2", 33, (85, 30), 0)
week = Text("Week 3", 33, (195, 10), 0)
time = Text("Noon", 33, (335, 40), 0)


#How to smartly break lines
firstLine = Text("...Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod",
                        30, (100,420), 0)
secondLine = Text("tempor incididunt ut labore et dolore magna aliqua.",
                         30, (110,450), 0)
thirdLine = Text("...Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu",
                         30,(100,500), 0)
fourthLine = Text("fugiat nulla pariatur.",
                         30,(110,530), 0)
fifthLine = Text("...Etiam erat velit scelerisque in. Metus dictum at tempor commodo ullamco",
                         30,(100,580), 0)
sixthLine = Text("met nisl purus consequat id porta nibh in mollis nunc sed id semper.",
                         30,(110, 610), 0)

#iNoodle
tableOne = Text("table", 30, (460,205), 0)
tableTwo = Text("table", 30, (560,270), 0)
tableThree = Text("table", 30, (640,130), 0)

sOne = Text("s", 30, (445,190), 0)
sTwo = Text("s", 30, (520,205), 0)
sThree = Text("s", 30, (635,110), 0)
sFour = Text("s", 30, (660,150), 0)
sFive = Text("s", 30, (570,250), 0)
sSix = Text("s", 30, (350,90), 0)
sSeven = Text("s", 30, (345,140), 0)
sEight = Text("s", 30, (340,200), 0)
sNine = Text("s", 30, (325,330), 0)
sTen = Text("s", 30, (780,320), 0)

you = Character("You", 18, (700,320), 3)

trashOne = Text("trash", 18, (788, 100), 0)
canOne = Text("can", 18, (798, 110), 0)
trashTwo = Text("trash", 18, (805, 270), 0)
canTwo = Text("can", 18, (815, 280), 0)

potOne = Text("pot", 15, (812, 180), 0)
plantOne = Text("plant", 15, (803, 190), 0)
potTwo = Text("pot", 15, (825, 320), 0)
plantTwo = Text("plant", 15, (817, 330), 0)

employeeOne = Text("employee", 24, (175, 100), 0)
employeeTwo = Text("employee", 24, (165, 200), 0)
employeeThree = Text("employee", 24, (155, 270), 0)


foodOne = Text("edible", 15, (290, 100), 0)
foodTwo = Text("edible", 15, (285, 160), 0)
foodThree = Text("edible", 15, (280, 220), 0)
foodFour = Text("edible", 15, (270, 280), 0)
foodFive = Text("raw", 15, (270, 330), 0)

#iNoodle sign and bowls
signOne = Text("iNoodle", 48, (90,130), 85)

bowlOne = Text("bowl", 12, (265, 95), 80)
bowlTwo = Text("bowl", 12, (260, 145), 80)
bowlThree = Text("bowl", 12, (255, 205), 80)
bowlFour = Text("bowl", 12, (248, 275), 80)
bowlFive = Text("bowl", 12, (243, 335), 80)

click1 = Clickable("door", 24, (730, 90), 0)


object1 = Clickable("table", 30, (460,205), 0)
object2 = Clickable("table", 30, (560,270), 0)
object3 = Clickable("table", 30, (640,130), 0)

object4 = Clickable("s", 30, (445,190), 0)
object5 = Clickable("s", 30, (520,205), 0)
object6 = Clickable("s", 30, (635,110), 0)
object7 = Clickable("s", 30, (660,150), 0)
object8 = Clickable("s", 30, (570,250), 0)
object9 = Clickable("s", 30, (350,90), 0)
object10 = Clickable("s", 30, (345,140), 0)
object11 = Clickable("s", 30, (340,200), 0)
object12 = Clickable("s", 30, (325,330), 0)
object13 = Clickable("s", 30, (780,320), 0)


things = [object1, object2, object3, object4, object5, object6, object7, 
            object8, object9, object10, object11, object12, object13]

frames = [firstLine, secondLine, thirdLine, fourthLine, 
        fifthLine, sixthLine]

rects = [rect1, rect2, rect3, rect4, rect5]

Lines = [Line1, Line2, Line3, Line4, Line5, Line6, Line7, Line8, Line9, Line10, 
        Line11, Line12, Line13, Line14, Line15, Line16, Line17, Line18, Line19,
        Line20, Line21, Line22, Line23]

texts = [tableOne, tableTwo, tableThree, sOne, sTwo, sThree, sFour, sFive, 
        sSix, sSeven, sEight, sNine, sTen, you, trashOne, canOne, trashTwo,
        canTwo, potOne, plantOne, potTwo, plantTwo, employeeOne, employeeTwo,
        employeeThree, foodOne, foodTwo, foodThree, foodFour, foodFive,
        bowlOne, bowlTwo, bowlThree, bowlFour, bowlFive, signOne]

choice1 = Clickable("get food", 24, (950,150), 0)
choice2 = Clickable("study", 24, (950,180), 0)
choice3 = Clickable("explore", 24, (950,210), 0)


choices = [choice1, choice2, choice3]

clickables = [click1]

characters = [you]

def display(time):
    clock = pygame.time.Clock()
    clock.tick(200)
    pygame.event.pump()
    screen.fill((255, 255, 255))
    g = DijkGrid(90, 38)
    g.walls = getObstacles(things)
    #drawGrid()
    #g.draw()
    pathDiction = {}

    if len(objectCharacter.Ben.pathMap) > 0:
    #print(you.pos)
        nextPos = (objectCharacter.Ben.pathMap[0][0] * 10, 
                    objectCharacter.Ben.pathMap[0][1] * 10)
        objectCharacter.Ben.pathMap.pop(0)
        you.set_target(nextPos)
        vecYouPos = (you.pos[0]//10, you.pos[1]//10)
        you.update()
#Draw top hour day week
    day = Text(time[1], 33, (85,30), 0)
    week = Text(time[2], 33, (195,10), 0)
    hour = Text(time[0], 33, (335,40), 0)
    hour.draw()
    day.draw()
    week.draw()

    action = Text(f'Action: {objectCharacter.Ben.actionPoint} / 4', 18, (930,100), 0)
    action.draw()

    health = Text(f'Health: {str(objectCharacter.Ben.health)}', 24, (930,280), 0)
    sanity = Text(f'Sanity: {str(objectCharacter.Ben.sanity)}', 24, (930,310), 0)
    knowledge = Text(f'Knowledge: {str(objectCharacter.Ben.knowledge)}', 24, (930,340), 0)
    health.draw()
    sanity.draw()
    knowledge.draw()


    for choice in choices:
        if choice.rect.collidepoint(pygame.mouse.get_pos()):
            choice.hovered = True
        else:
            choice.hovered = False
        
        choice.draw()

#Original Frame
    for line in Lines:
        line.draw()
    
    for rect in rects:
        rect.draw()

        
#Game Frames
    objectText.textBox.draw()

#iNoodle
    for text in texts:
        text.draw()
    
    for chara in characters:
        chara.draw()
        chara.update()
        #pygame.draw.line(screen, (105, 105, 105), chara.pos, 
        #chara.endPoint, 1)

    keys = pygame.key.get_pressed()

    if keys[pygame.K_SPACE]:
        objectCharacter.Ben.actionPoint = 4
        return 42

    #Interactiables
        for click in clickables:
            if click.rect.collidepoint(pygame.mouse.get_pos()):
                click.hovered = True
            else:
                click.hovered = False
            
            click.draw()

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            run = False
            pygame.quit()

        if event.type == pygame.MOUSEBUTTONUP:
            cX, cY = pygame.mouse.get_pos()
            vecPos = vec(pygame.mouse.get_pos()) // TILESIZE
            if ((cX >= 80) and (cX <= 900) and (cY >=230) and (cY <=380)):
                if vecPos not in g.walls:
                    pathDiction = aStar(g, vecPos, 
                            vec(you.pos[0]//10, you.pos[1]//10))

                    objectCharacter.Ben.pathMap = findRoute(pathDiction, 
                                                    (you.pos[0]//10, you.pos[1]//10),
                                                        intVec(vecPos))

            for click in clickables:
                if click.rect.collidepoint(pygame.mouse.get_pos()):
                    if click == click1:
                        objectCharacter.Ben.actionPoint = 4
                        return 42

            for choice in choices:
                if choice.rect.collidepoint(pygame.mouse.get_pos()):
                    if objectCharacter.Ben.actionPoint > 0:
                        if choice == choice1:
                            objectCharacter.Ben.actionPoint -= 1
                            quotes1 = {
                                "Something reminds you about cmuhack112, you felt a chill run up your spine.":(5, -5, 3),
                                "Not great, but definately the second best choice.":(3, 0, 0),
                            }
                            tempResponse = random.choice(list(quotes1.keys()))
                            objectCharacter.Ben.health += quotes1[tempResponse][0]
                            objectCharacter.Ben.sanity += quotes1[tempResponse][1]
                            objectCharacter.Ben.knowledge += quotes1[tempResponse][2]
                            objectText.textBox.bundle(tempResponse, 99)

                        elif choice == choice2:
                            objectCharacter.Ben.actionPoint -= 1
                            quotes2 = {
                                "'Study at iNoodle...... is not optimal but definately has its upsides', you tried to convince yourself.":(-2, -4, 8),
                                "Not great, but definately the second best choice.":(-3, -3, 5),
                            }
                            tempResponse = random.choice(list(quotes2.keys()))
                            objectCharacter.Ben.health += quotes2[tempResponse][0]
                            objectCharacter.Ben.sanity += quotes2[tempResponse][1]
                            objectCharacter.Ben.knowledge += quotes2[tempResponse][2]
                            objectText.textBox.bundle(tempResponse, objectCharacter.Ben.sanity)


                        elif choice == choice3:
                            quotes3 = {
                                "You didn't feel the need to explore around iNoodle":(0, 0, 0),
                            }
                            tempResponse = random.choice(list(quotes3.keys()))
                            objectCharacter.Ben.health += quotes3[tempResponse][0]
                            objectCharacter.Ben.sanity += quotes3[tempResponse][1]
                            objectCharacter.Ben.knowledge += quotes3[tempResponse][2]
                            objectText.textBox.bundle(tempResponse, objectCharacter.Ben.sanity)


    pygame.display.update()
