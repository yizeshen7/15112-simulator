
import objectDate
import objectCharacter
import objectText
import pygame
import slideSelection

pygame.init()
screen = pygame.display.set_mode((1280, 720))
pygame.display.set_caption("blank")

class Line(object):
    grey = (105, 105, 105)
    white = (255, 255, 255)
    def __init__(self, canvas, color, sp, ep, width):
        self.canvas = canvas
        self.color = color
        self.sp = sp
        self.ep = ep
        self.width = width
    
    def draw(self):
        pygame.draw.line(self.canvas, self.color, self.sp, self.ep,
                            self.width)

class Rect(object):
    grey = (105, 105, 105)
    white = (255, 255, 255)
    def __init__(self, canvas, color, tlsize):
        self.canvas = canvas
        self.color = color
        self.tlsize = tlsize
    
    def draw(self):
        pygame.draw.rect(self.canvas, self.color, self.tlsize)

#OHQ
class Clickable(object):
    hovered = False

    def __init__(self, text, size, pos, tilt):
        self.text = text
        self.pos = pos
        self.size = size
        self.tilt = tilt
        self.clicked = False
        self.set_rect()
        self.draw()

    def set_rend(self):
        font = pygame.font.SysFont('Times New Roman', self.size)
        self.rend = font.render(self.text, True, self.getcolor())
        self.rend = pygame.transform.rotate(self.rend, self.tilt)
        
    def getcolor(self):
        if self.hovered:
            return (0, 0, 0)
        else:
            return (105, 105, 105)
        
    def set_rect(self):
        self.set_rend()
        self.rect = self.rend.get_rect()
        self.rect.topleft = (self.pos)

    def draw(self):
        self.set_rend()
        screen.blit(self.rend, self.rect) #The text    


class Text(object):
    grey = (105, 105, 105)
    white = (255, 255, 255)

    def __init__(self, text, size, pos, tilt):
        self.text = text
        self.pos = pos
        self.size = size
        self.tilt = tilt
    
    def draw(self):
        font = pygame.font.SysFont('Times New Roman', self.size)
        rend = font.render(self.text, True, self.grey)
        rend = pygame.transform.rotate(rend, self.tilt)
        screen.blit(rend, (self.pos))


class Character(object):

    def __init__(self, text, size, pos, speed):
        self.text = text
        self.size = size
        self.pos = pos
        self.speed = speed
        self.set_rect()
        self.endPoint = (0,0)
        self.pos = pygame.Vector2(self.pos)
        self.set_target(self.pos)

    def set_target(self, pos):
        self.target = pygame.Vector2(pos)
        self.endPoint = pos

    def set_rend(self):
        font = pygame.font.SysFont('Times New Roman', self.size)
        self.rend = font.render(self.text, True, (105, 105, 105))

    def set_rect(self):
        self.set_rend()
        self.rect = self.rend.get_rect()
        self.box = (self.pos[0], self.pos[1], self.rect[2], self.rect[3])
        self.rect.topleft = self.pos
    
    def draw(self):
        font = pygame.font.SysFont('Times New Roman', self.size)
        rend = font.render(self.text, True, (105, 105, 105))
        screen.blit(rend, self.pos)

    #Concept(normalize_ip) taken from https://stackoverflow.com/questions/16288905/make-a-sprite-move-to-the-mouse-click-position-step-by-step
    def update(self):
        move = self.target - self.pos
        moveLength = move.length()

        if moveLength < self.speed:
            self.pos = self.target

        elif moveLength != 0:
            move.normalize_ip()
            move = move * self.speed
            self.pos += move

        self.box = (self.pos[0], self.pos[1], self.rect[2], self.rect[3])
    
class Input(object):

    def __init__(self, text, size, pos, tilt):
        self.text = text
        self.pos = pos
        self.size = size
        self.tilt = tilt
        self.clicked = False
        self.hovered = False
        self.inputStat = False
        self.set_rect()
        self.draw()

    def set_rend(self):
        font = pygame.font.SysFont('Times New Roman', self.size)
        self.rend = font.render(self.text, True, self.getcolor())
        self.rend = pygame.transform.rotate(self.rend, self.tilt)
        
    def getcolor(self):
        if self.hovered:
            return (0, 0, 0)
        else:
            return (105, 105, 105)
        
    def set_rect(self):
        self.set_rend()
        self.rect = self.rend.get_rect()
        self.rect.topleft = (self.pos)

    def draw(self):
        self.set_rend()
        screen.blit(self.rend, self.rect) #The text    

class Counter(object):
    def __init__(self, stat):
        self.counter = stat

remainCounter = Counter(6)



Line1 = Line(screen, (105,105,105), (80,80), (900,80), 4)
Line2 = Line(screen, (105,105,105), (80,80), (80,380), 4)
Line3 = Line(screen, (105,105,105), (80,380), (900,380), 4)
Line4 = Line(screen, (105,105,105), (900,80), (900,380), 4)

Line5 = Line(screen, (105,105,105), (920,80), (1080,80), 4)
Line6 = Line(screen, (105,105,105), (920,80), (920,380), 4)
Line7 = Line(screen, (105,105,105), (920,380), (1080,380), 4)
Line8 = Line(screen, (105,105,105), (1080,80), (1080,380), 4)

Line9 = Line(screen, (105,105,105), (80,400), (1080,400), 4)
Line10 = Line(screen, (105,105,105), (80,400), (80,680), 4)
Line11 = Line(screen, (105,105,105), (80,680), (1080,680), 4)
Line12 = Line(screen, (105,105,105), (1080,400), (1080,680), 4)

Line13 = Line(screen, (105,105,105), (1100,80), (1170,80), 4)
Line14 = Line(screen, (105,105,105), (1100,680), (1170,680), 4)
Line15 = Line(screen, (105,105,105), (1100,80), (1100,680), 4)
Line16 = Line(screen, (105,105,105), (1170,80), (1170,680), 4)

#ScrollIndicator
Line17 = Line(screen, (105,105,105), (1055,420), (1055,660), 4) #Black 240
Line18 = Line(screen, (255,255,255), (1055,440), (1055,490), 4) #White 50

#itemBlock
rect1 = Rect(screen, (105,105,105), (1113,120,45,45)) #Item bar 1-5
rect2 = Rect(screen, (105,105,105), (1113,240,45,45))
rect3 = Rect(screen, (105,105,105), (1113,360,45,45))
rect4 = Rect(screen, (105,105,105), (1113,480,45,45))
rect5 = Rect(screen, (105,105,105), (1113,600,45,45))


#Game frame
day = Text("Day 0", 33, (85,30), 0)
week = Text("Week 1", 33, (195,10), 0)
time = Text("???", 33, (335,40), 0)

#How to smartly break lines
firstLine = Text("...You can create your character right here, click on names to enter your name,",
                        30, (100,420), 0)
secondLine = Text("you can also check your name, see if there is a unexpected surprise...",
                         30, (110,450), 0)
thirdLine = Text("...Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu",
                         30,(100,500), 0)
fourthLine = Text("fugiat nulla pariatur.",
                         30,(110,530), 0)
fifthLine = Text("...Etiam erat velit scelerisque in. Metus dictum at tempor commodo ullamco",
                         30,(100,580), 0)
sixthLine = Text("met nisl purus consequat id porta nibh in mollis nunc sed id semper.",
                         30,(110,610), 0)
#Lecture Outline
Line19 = Line(screen, (105,105,105), (230,230), (746,230), 2)
Line20 = Line(screen, (105,105,105), (80,380), (230,230), 2)
Line21 = Line(screen, (105,105,105), (900,380), (746,230), 2)
Line22 = Line(screen, (105,105,105), (230,80), (230,230), 2)
Line23 = Line(screen, (105,105,105), (746,80), (746,230), 2)

Line24 = Line(screen, (105,105,105), (430,380), (480,270), 2) #inner outline
Line25 = Line(screen, (105,105,105), (570,380), (520,270), 2)

Line26 = Line(screen, (105,105,105), (640,80), (640,200), 1) #Screen
Line27 = Line(screen, (105,105,105), (340,80), (340,200), 1)
Line28 = Line(screen, (105,105,105), (340,200), (640,200), 1)
Line29 = Line(screen, (105,105,105), (340,80), (640,80), 1)



#Lecture things
you = Character("You", 18, (700,315), 3)

click1 = Input("First Name", 36, (100,100), 0)
click2 = Input("Last Name", 36, (150,150), 0)
click3 = Input("check", 24, (500,125), 0)

click4 = Input("+", 30, (750,235), 0)
click5 = Input("-", 30, (700,235), 0)
click6 = Input("+", 30, (750,275), 0)
click7 = Input("-", 30, (700,275), 0)
click8 = Input("+", 30, (750,315), 0)
click9 = Input("-", 30, (700,315), 0)

click10 = Clickable("Start", 30, (975,315), 0)

text1 = Text("Health", 30, (90,230), 0)
text2 = Text("Sanity", 30, (90,270), 0)
text3 = Text("Knowledge", 30, (90,310), 0)







#Emploee
#employee1 = Clickable("employee", 18, (565,265), -45)

frames = [day, week, time, firstLine, secondLine, thirdLine, fourthLine, 
        fifthLine, sixthLine]

texts = [text1, text2, text3]

clickables = [click1, click2, click3, click4, click5, click6,
                click7, click8, click9, click10]


Lines = [Line1, Line2, Line3, Line4, Line5, Line6, Line7, Line8, Line9, Line10, 
        Line11, Line12, Line13, Line14, Line15, Line16, Line17, Line18]

rects = [rect1, rect2, rect3, rect4, rect5]

characters = []

def redraw(text, size, pos):
    font = pygame.font.SysFont('Times New Roman', size)
    rend = font.render(text, True, (105, 105, 105))
    screen.blit(rend, pos)


class Creation(object):
    def __init__(self):
        self.fname = ""
        self.lname = ""
        self.health = 48
        self.sanity = 64
        self.knowledge = 0
        self.attributes = []
    
    def easterEggCheck(self, diction):
        fullName = self.fname + self.lname
        if fullName in diction:
            #print("here")
            self.health = int(diction[fullName][0][0])
            self.sanity = int(diction[fullName][0][1])
            self.knowledge = int(diction[fullName][0][2])
            self.attributes = diction[fullName][1]
            print(self.attributes)
    
    def drawStat(self, screen):

        font = pygame.font.SysFont('Times New Roman', 24)
        rend1 = font.render(str(self.health), True, (105, 105, 105))
        rend2 = font.render(str(self.sanity), True, (105, 105, 105))
        rend3 = font.render(str(self.knowledge), True, (105, 105, 105))
        
        screen.blit(rend1, (650, 240))
        screen.blit(rend2, (650, 280))
        screen.blit(rend3, (650, 320))

        font2 = pygame.font.SysFont('Times New Roman', 20)
        rend4 = font2.render(f'points: {str(remainCounter.counter)}', True, (105, 105, 105))
        screen.blit(rend4, (700, 210))

        pygame.draw.line(screen, (105, 105, 105), 
                        (300,250), (300 + (self.health * 4), 250), 8)

        pygame.draw.line(screen, (105, 105, 105), 
                        (300,290), (300 + (self.sanity * 4), 290), 8)

        pygame.draw.line(screen, (105, 105, 105), 
                        (300,330), (300 + (self.knowledge * 4), 330), 8)

    def drawAttribute(self, screen):
        counter = 0
        for elem in self.attributes:
            pos = (750, 100 + (counter*30))
            font = pygame.font.SysFont('Times New Roman', 24)
            rend = font.render(elem, True, (105, 105, 105))
            screen.blit(rend, pos)
            counter += 1


# from: https://www.cs.cmu.edu/~112/notes/notes-strings.html#basicFileIO
def readFile(path):
    with open(path, "rt") as f:
        return f.read()

def getFile():
    name = f'CC.csv'
    read = readFile(name)
    table = []
    for i in read.splitlines():
        table.append(i.split(","))
    
    #print(table)
    return table

def tableToDiction(table):
    table = table[1:]
    diction = {}
    for List in table:
        key = List[0] + List[1]
        diction[key] = []
        stats = (List[2], List[3], List[4])
        diction[key].append(stats)

        attributes = []
        for elem in List[5:]:
            if elem == "null":
                pass
            else:
                attributes.append(elem)

        diction[key].append(attributes)

    #print(diction)
    return diction


table = getFile()
diction = tableToDiction(table)

creation = Creation()

def display(time):
    run = True
    #pygame.time.delay(100)
    pygame.event.pump()
    screen.fill((255, 255, 255))

#Original Frame
    for line in Lines:
        line.draw()
    
    for rect in rects:
        rect.draw()
        
#Game Frames
    objectText.textBox.draw()

#texts
    for text in texts:
        text.draw()

    for click in clickables:
        if click.rect.collidepoint(pygame.mouse.get_pos()):
            click.hovered = True
        else:
            click.hovered = False
        click.draw()

    for chara in characters:
        chara.draw()
    
#Keys and sticks

    creation.drawAttribute(screen)
    creation.drawStat(screen)
    redraw(creation.fname, 28, (300, 110))
    redraw(creation.lname, 28, (350, 160))

    for event in pygame.event.get():

        if event.type == pygame.QUIT:
            run = False
            pygame.quit()

        if event.type == pygame.MOUSEBUTTONUP:
            for click in clickables:
                            if click.rect.collidepoint(pygame.mouse.get_pos()):
                                if click == click1:
                                    #print("firstName")
                                    click1.inputStat = not click1.inputStat
                                    click2.inputStat = False
                                    #print(click1.inputStat)

                                elif click == click2:
                                    #print("lastName")
                                    click2.inputStat = not click2.inputStat
                                    click1.inputStat = False
                                    #print(click2.inputStat)
                                
                                elif click == click3:
                                    creation.easterEggCheck(diction)
                                    print(creation.health)
                                    print(creation.sanity)
                                    print(creation.knowledge)

                                elif click == click4:
                                    if remainCounter.counter > 0:
                                        remainCounter.counter -= 1
                                        creation.health += 1
                                
                                elif click == click5:
                                    remainCounter.counter += 1
                                    creation.health -= 1

                                elif click == click6:
                                    if remainCounter.counter > 0:
                                        remainCounter.counter -= 1
                                        creation.sanity += 1

                                elif click == click7:
                                    remainCounter.counter += 1
                                    creation.sanity -= 1

                                elif click == click8:
                                    if remainCounter.counter > 0:
                                        remainCounter.counter -= 1
                                        creation.knowledge += 10


                                elif click == click9:
                                    if creation.knowledge > 0:
                                        creation.knowledge -= 10
                                        remainCounter.counter += 1
                                    else:
                                        objectText.textBox.bundle("You are not me, you can't have negative knoweldge buddy.", 99)

                                elif click == click10:
                                    objectCharacter.Ben.fname = creation.fname
                                    objectCharacter.Ben.lname = creation.lname
                                    objectCharacter.Ben.health = creation.health
                                    objectCharacter.Ben.sanity = creation.sanity
                                    objectCharacter.Ben.knowledge = creation.knowledge
                                    objectCharacter.Ben.attributes = creation.attributes
                                    print(objectCharacter.Ben.attributes)

                                    while True:
                                        time = (objectDate.current.hourSymbol[objectDate.current.hour], 
                                            f'Day {objectDate.current.day}', 
                                            f'Week {objectDate.current.week}')

                                        slideSelection.display(time)

                                


        if event.type == pygame.KEYUP and event.key == pygame.K_SPACE:
            if click1.inputStat == True:
                creation.fname = creation.fname + " "

            if click2.inputStat == True:
                creation.lname = creation.lname + " "

        if event.type == pygame.KEYUP and event.key == pygame.K_a:
            if click1.inputStat == True:
                creation.fname = creation.fname + "a"

            if click2.inputStat == True:
                creation.lname = creation.lname + "a"


        if event.type == pygame.KEYUP and event.key == pygame.K_b:
            if click1.inputStat == True:
                creation.fname = creation.fname + "b"

            if click2.inputStat == True:
                creation.lname = creation.lname + "b"

        if event.type == pygame.KEYUP and event.key == pygame.K_c:
            if click1.inputStat == True:
                creation.fname = creation.fname + "c"

            if click2.inputStat == True:
                creation.lname = creation.lname + "c"

        if event.type == pygame.KEYUP and event.key == pygame.K_d:
            if click1.inputStat == True:
                creation.fname = creation.fname + "d"

            if click2.inputStat == True:
                creation.lname = creation.lname + "d"

        if event.type == pygame.KEYUP and event.key == pygame.K_e:
            if click1.inputStat == True:
                creation.fname = creation.fname + "e"

            if click2.inputStat == True:
                creation.lname = creation.lname + "e"

        if event.type == pygame.KEYUP and event.key == pygame.K_f:
            if click1.inputStat == True:
                creation.fname = creation.fname + "f"

            if click2.inputStat == True:
                creation.lname = creation.lname + "f"

        if event.type == pygame.KEYUP and event.key == pygame.K_g:
            if click1.inputStat == True:
                creation.fname = creation.fname + "g"

            if click2.inputStat == True:
                creation.lname = creation.lname + "g"

        if event.type == pygame.KEYUP and event.key == pygame.K_h:
            if click1.inputStat == True:
                creation.fname = creation.fname + "h"
        
            if click2.inputStat == True:
                creation.lname = creation.lname + "h"

        if event.type == pygame.KEYUP and event.key == pygame.K_i:
            if click1.inputStat == True:
                creation.fname = creation.fname + "i"
        
            if click2.inputStat == True:
                creation.lname = creation.lname + "i"

        if event.type == pygame.KEYUP and event.key == pygame.K_j:
            if click1.inputStat == True:
                creation.fname = creation.fname + "j"
            
            if click2.inputStat == True:
                creation.lname = creation.lname + "j"

        if event.type == pygame.KEYUP and event.key == pygame.K_k:
            if click1.inputStat == True:
                creation.fname = creation.fname + "k"

            if click2.inputStat == True:
                creation.lname = creation.lname + "k"
        
        if event.type == pygame.KEYUP and event.key == pygame.K_l:
            if click1.inputStat == True:
                creation.fname = creation.fname + "l"
            
            if click2.inputStat == True:
                creation.lname = creation.lname + "l"

        if event.type == pygame.KEYUP and event.key == pygame.K_m:
            if click1.inputStat == True:
                creation.fname = creation.fname + "m"

            if click2.inputStat == True:
                creation.lname = creation.lname + "m"

        if event.type == pygame.KEYUP and event.key == pygame.K_n:
            if click1.inputStat == True:
                creation.fname = creation.fname + "n"
            
            if click2.inputStat == True:
                creation.lname = creation.lname + "n"

        if event.type == pygame.KEYUP and event.key == pygame.K_o:
            if click1.inputStat == True:
                creation.fname = creation.fname + "o"

            if click2.inputStat == True:
                creation.lname = creation.lname + "o"

        if event.type == pygame.KEYUP and event.key == pygame.K_p:
            if click1.inputStat == True:
                creation.fname = creation.fname + "p"
            
            if click2.inputStat == True:
                creation.lname = creation.lname + "p"

        if event.type == pygame.KEYUP and event.key == pygame.K_q:
            if click1.inputStat == True:
                creation.fname = creation.fname + "q"
            
            if click2.inputStat == True:
                creation.lname = creation.lname + "q"

        if event.type == pygame.KEYUP and event.key == pygame.K_r:
            if click1.inputStat == True:
                creation.fname = creation.fname + "r"

            if click2.inputStat == True:
                creation.lname = creation.lname + "r"

        if event.type == pygame.KEYUP and event.key == pygame.K_s:
            if click1.inputStat == True:
                creation.fname = creation.fname + "s"
        
            if click2.inputStat == True:
                creation.lname = creation.lname + "s"

        if event.type == pygame.KEYUP and event.key == pygame.K_t:
            if click1.inputStat == True:
                creation.fname = creation.fname + "t"
            
            if click2.inputStat == True:
                creation.lname = creation.lname + "t"

        if event.type == pygame.KEYUP and event.key == pygame.K_u:
            if click1.inputStat == True:
                creation.fname = creation.fname + "u"

            if click2.inputStat == True:
                creation.lname = creation.lname + "u"

        if event.type == pygame.KEYUP and event.key == pygame.K_v:
            if click1.inputStat == True:
                creation.fname = creation.fname + "v"
            
            if click2.inputStat == True:
                creation.lname = creation.lname + "v"

        if event.type == pygame.KEYUP and event.key == pygame.K_w:
            if click1.inputStat == True:
                creation.fname = creation.fname + "w"
            
            if click2.inputStat == True:
                creation.lname = creation.lname + "w"

        if event.type == pygame.KEYUP and event.key == pygame.K_x:
            if click1.inputStat == True:
                creation.fname = creation.fname + "x"

            if click2.inputStat == True:
                creation.lname = creation.lname + "x"

        if event.type == pygame.KEYUP and event.key == pygame.K_y:
            if click1.inputStat == True:
                creation.fname = creation.fname + "y"

            if click2.inputStat == True:
                creation.lname = creation.lname + "y"

        if event.type == pygame.KEYUP and event.key == pygame.K_z:
            if click1.inputStat == True:
                creation.fname = creation.fname + "z"
            
            if click2.inputStat == True:
                creation.lname = creation.lname + "z"

        if event.type == pygame.KEYUP and event.key == pygame.K_BACKSPACE:
            if click1.inputStat == True:
                creation.fname = creation.fname[:-1]

            if click2.inputStat == True:
                creation.lname = creation.lname[:-1]




    pygame.display.update()





