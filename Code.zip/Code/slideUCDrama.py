



import objectDate
import objectCharacter
import objectText
import slideOHQ


import random
import pygame
import heapq

from os import path
from collections import deque

vec = pygame.math.Vector2

pygame.init()
screen = pygame.display.set_mode((1280, 720))
pygame.display.set_caption("blank")

class Line(object):
    grey = (105, 105, 105)
    white = (255, 255, 255)

    def __init__(self, canvas, color, sp, ep, width):
        self.canvas = canvas # Screen
        self.color = color  # Color of the line
        self.sp = sp  # Starting point
        self.ep = ep  # Ending point
        self.width = width # Width of the line
    
    def draw(self):  # Just draw the function out
        pygame.draw.line(self.canvas, self.color, self.sp, self.ep,
                            self.width)


class Rect(object):
    grey = (105, 105, 105)
    white = (255, 255, 255)

    def __init__(self, canvas, color, tlsize):
        self.canvas = canvas # Screen
        self.color = color  # Color of the rect
        self.tlsize = tlsize  # tuple for top, left, height and width
    
    def draw(self):  # Just draw the function out
        pygame.draw.rect(self.canvas, self.color, self.tlsize)



class Text(object):
    grey = (105, 105, 105)
    white = (255, 255, 255)

    def __init__(self, text, size, position, tilt):
        self.text = text
        self.pos = position
        self.size = size
        self.tilt = tilt
        self.set_rect()
    
    def set_rect(self):
        font = pygame.font.SysFont('Times New Roman', self.size)
        rend = font.render(self.text, True, self.grey)
        rend = pygame.transform.rotate(rend, self.tilt)
        self.rend = rend
        self.rect = self.rend.get_rect()
        self.box = (self.pos[0], self.pos[1], self.rect[2], self.rect[3])
        self.rect.topleft = self.pos


    def draw(self):
        font = pygame.font.SysFont('Times New Roman', self.size)
        rend = font.render(self.text, True, self.grey)
        rend = pygame.transform.rotate(rend, self.tilt)
        screen.blit(rend, self.pos)


class Clickable(object):

    def __init__(self, text, size, pos, tilt):
        self.text = text
        self.pos = pos
        self.size = size
        self.tilt = tilt
        self.hovered = False
        self.clicked = False
        self.set_rect()
        self.draw()
        
    def set_rend(self):
        font = pygame.font.SysFont('Times New Roman', self.size)
        self.rend = font.render(self.text, True, self.getcolor())
        self.rend = pygame.transform.rotate(self.rend, self.tilt)
        
    def getcolor(self):
        if self.hovered:
            return (0, 0, 0)
        else:
            return (105, 105, 105)
        
    def set_rect(self):
        self.set_rend()
        self.rect = self.rend.get_rect()
        self.box = (self.pos[0], self.pos[1], self.rect[2], self.rect[3])
        self.rect.topleft = self.pos
    
    
    #Concept(index into tuples & boxes) from https://stackoverflow.com/questions/35001207/how-to-detect-collision-between-objects-in-pygame
    def checkCollision(self, playerBox):
    #convert rectangles into x,y,w,h
        playerX = playerBox[0]
        playerY = playerBox[1]
        playerWidth = playerBox[2]
        playerHeight = playerBox[3]

        obstacleX = self.box[0]
        obstacleY = self.box[1]
        obstacleWidth = self.box[2]
        obstacleHeight = self.box[3]

        myRight = playerX + playerWidth
        myLeft = playerX
        myTop = playerY
        myBottom = playerY + playerHeight

        otherRight = obstacleX + obstacleWidth
        otherLeft = obstacleX
        otherTop = obstacleY
        otherBottom = obstacleY + obstacleHeight

        checker = True
        if ((myRight < otherLeft) or (myLeft > otherRight) \
            or (myBottom < otherTop) or (myTop > otherBottom)):
            checker = False
        return checker

    def draw(self):
        self.set_rend()
        screen.blit(self.rend, self.rect)

class StatCheck(object):
    def __init__(self, stat):
        self.stat = stat
        self.targetPos = (0, 0)

s8Stat = StatCheck("still")
s9Stat = StatCheck("still")
s10Stat = StatCheck("still")
s11Stat = StatCheck("still")
s12Stat = StatCheck("still")


s5Stat = StatCheck("still")
s6Stat = StatCheck("still")


class Character(object):

    def __init__(self, text, size, pos, speed):
        self.text = text
        self.size = size
        self.pos = pos
        self.speed = speed
        self.set_rect()
        self.endPoint = (0,0)
        self.pos = pygame.Vector2(self.pos)
        self.set_target(self.pos)

    def set_target(self, pos):
        self.target = pygame.Vector2(pos)
        self.endPoint = pos

    def set_rend(self):
        font = pygame.font.SysFont('Times New Roman', self.size)
        self.rend = font.render(self.text, True, (105, 105, 105))

    def set_rect(self):
        self.set_rend()
        self.rect = self.rend.get_rect()
        self.box = (self.pos[0], self.pos[1], self.rect[2], self.rect[3])
        self.rect.topleft = self.pos
    
    def draw(self):
        font = pygame.font.SysFont('Times New Roman', self.size)
        rend = font.render(self.text, True, (105, 105, 105))
        screen.blit(rend, self.pos)

    #Concept(normalize_ip) taken from https://stackoverflow.com/questions/16288905/make-a-sprite-move-to-the-mouse-click-position-step-by-step
    def update(self):
        move = self.target - self.pos
        moveLength = move.length()

        if moveLength < self.speed:
            self.pos = self.target

        elif moveLength != 0:
            move.normalize_ip()
            move = move * self.speed
            self.pos += move

        self.set_rect()
        self.box = (self.pos[0], self.pos[1], self.rect[2], self.rect[3])

#From https://www.youtube.com/watch?v=fa1NSUBqiJc
class Grid(object):
    def __init__(self, width, height):
        self.width = width
        self.height = height
        self.walls = [(10, 7)]
        self.connections = [vec(1, 0), vec(-1, 0), vec(0, 1), vec(0, -1), 
                            vec(-1, 1), vec(-1, -1), vec(1, 1), vec(1, -1)]

    def isInBound(self, node):
        if node.x >= 0 and node.x < self.width:
            if node.y >= 0 and node.y < self.height:
                return True
        return False

    def isPassable(self, node):
        if node in self.walls:
            return False
        return True

    def getNeighbors(self, node):
        counter = 0
        self.neighbors = []
        for direction in self.connections:
            counter += 1
            temp = node + direction
            #Didn't implement no perference path
            if self.isInBound(temp) == True:
                if self.isPassable(temp) == True:
                    self.neighbors.append(temp)
        return self.neighbors

    def draw(self):
        for wall in self.walls:
            rect = pygame.Rect((wall[0])*TILESIZE, (wall[1])*TILESIZE,
                                TILESIZE, TILESIZE)
            pygame.draw.rect(screen, (105, 105, 105), rect)

#From https://www.youtube.com/watch?v=fa1NSUBqiJc
class DijkGrid(Grid):
    def __init__(self, width, height):
        super().__init__(width, height)
        self.weights = {}
    
    def cost(self, fromNode, toNode):
        checker = (abs(fromNode[0] - toNode[0]) - \
                    abs(fromNode[1] - toNode[1])) ** 0.5
        if checker == 1:
            return self.weights.get(toNode, 0) + 10
        else:
            return self.weights.get(toNode, 0) + 14

#From https://www.youtube.com/watch?v=fa1NSUBqiJc
class PriorityQueue(object):
    def __init__(self):
        self.nodes = []

    def put(self, node, cost):
        heapq.heappush(self.nodes, (cost, node))

    def get(self):
        return heapq.heappop(self.nodes)[1]

    def empty(self):
        checker = len(self.nodes)
        if checker == 0:
            return True
        else:
            return False

TILESIZE = 10
GRIDWIDTH = 90 #52
GRIDHEIGHT = 38 #15
WIDTH = TILESIZE * GRIDWIDTH
HEIGHT = TILESIZE * GRIDHEIGHT

def round(n):
    last = n % 10
    if last == 0:
        n = 10
    elif last <= 3:
        n = (n//10) * 10
    elif last > 3:
        n = (n//10) * 10 + 10
    return n
#no need to worry about +230, just a placeholder
def drawGrid():
    for x in range(0, WIDTH+1, TILESIZE):
        pygame.draw.line(screen, (105,105,105), (x, 0), (x, HEIGHT))
    for y in range(0, HEIGHT+1, TILESIZE):
        pygame.draw.line(screen, (105,105,105), (0, y), (WIDTH, y))

def getObstacles(things):
    obstacles = []
    for text in things:
        coordinateTop = (text.pos[0]//10, text.pos[1]//10)
        obstacles.append(coordinateTop)

        restX, restY = (round(text.box[2]) //10, round(text.box[3]) //10)
        for i in range (0, restX ):
            for j in range(0, restY):
                coordinateTemp = (coordinateTop[0] + i, coordinateTop[1] + j)
                obstacles.append(coordinateTemp)

    for stuff in obstacles:
        g.weights[stuff] = 20

    return obstacles

def intVec(vector):
    return (int(vector[0]), int(vector[1]))


#Concept (deque) from: https://www.youtube.com/watch?v=hettiSrJjM4
def ruleOfThumb(node1, node2):
    #mahattan distance
    distance = (abs(node1[0] - node2[0]) + \
                    abs(node1[1] - node2[1]))

    value = 10 * distance
    return value

#From https://www.youtube.com/watch?v=fa1NSUBqiJc
def aStar(graph, start, end):
    frontier = PriorityQueue()
    frontier.put(intVec(start), 0)
    path = {}
    cost = {}
    path[intVec(start)] = None
    cost[intVec(start)] = 0

    while frontier.empty() == False:
        current = frontier.get()
        if current == end:
            break
        for next in graph.getNeighbors(vec(current)):
            next = intVec(next)
            nextCost = cost[current] + graph.cost(current, next)
            if next not in cost or nextCost < cost[next]:
                cost[next] = nextCost
                priority = nextCost + ruleOfThumb(end, vec(next))
                frontier.put(next, priority)
                path[next] = vec(current) - vec(next)
    
    return path

def findRoute(diction, playerInital, gridMousePos):
    playerInital = intVec(playerInital)
    pathMap = []
    while playerInital != (gridMousePos): #should be mouse position
        if playerInital in diction:
            tempDirect = diction[playerInital]
            tempDirect = intVec(tempDirect)

            tempPos = (playerInital[0] + tempDirect[0],
                        playerInital[1] + tempDirect[1])

            pathMap.append(tempPos)

            playerInital = tempPos

    print(pathMap)
    return pathMap


g= DijkGrid(90, 38)
path = aStar(g, vec(28,28), vec(70,32))

day = Text("Day 2", 33, (85, 30), 0)
week = Text("Week 3", 33, (195, 10), 0)
time = Text("Noon", 33, (335, 40), 0)

textHealth = Text("H", 33, (940, 340), 0)
textSanity = Text("S", 33, (995, 340), 0)
textKnowledge = Text("K", 33, (1040, 340), 0)

textHealthIndicator = Text("52", 33, (935, 145), 0)
textSanityIndicator = Text("18", 33, (986, 255), 0)
textKnowledgeIndicator = Text("74", 33, (1032, 100), 0)

#How to smartly break lines
firstLine = Text("...Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod",
                        30, (100,420), 0)
secondLine = Text("tempor incididunt ut labore et dolore magna aliqua.",
                         30, (110,450), 0)
thirdLine = Text("...Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu",
                         30,(100,500), 0)
fourthLine = Text("fugiat nulla pariatur.",
                         30,(110,530), 0)
fifthLine = Text("...Etiam erat velit scelerisque in. Metus dictum at tempor commodo ullamco",
                         30,(100,580), 0)
sixthLine = Text("met nisl purus consequat id porta nibh in mollis nunc sed id semper.",
                         30,(110, 610), 0)

line1 = Line(screen, (105,105,105), (80,80), (900,80), 4)
line2 = Line(screen, (105,105,105), (80,80), (80,380), 4)
line3 = Line(screen, (105,105,105), (80,380), (900,380), 4)
line4 = Line(screen, (105,105,105), (900,80), (900,380), 4)

line5 = Line(screen, (105,105,105), (920,80), (1080,80), 4)
line6 = Line(screen, (105,105,105), (920,80), (920,380), 4)
line7 = Line(screen, (105,105,105), (920,380), (1080,380), 4)
line8 = Line(screen, (105,105,105), (1080,80), (1080,380), 4)

line9 = Line(screen, (105,105,105), (80,400), (1080,400), 4)
line10 = Line(screen, (105,105,105), (80,400), (80,680), 4)
line11 = Line(screen, (105,105,105), (80,680), (1080,680), 4)
line12 = Line(screen, (105,105,105), (1080,400), (1080,680), 4)

line13 = Line(screen, (105,105,105), (1100,80), (1170,80), 4)
line14 = Line(screen, (105,105,105), (1100,680), (1170,680), 4)
line15 = Line(screen, (105,105,105), (1100,80), (1100,680), 4)
line16 = Line(screen, (105,105,105), (1170,80), (1170,680), 4)

#ScrollIndicator
line17 = Line(screen, (105,105,105), (1055,420), (1055,660), 4) #Black 240
line18 = Line(screen, (255,255,255), (1055,440), (1055,490), 4) #White 50

#Bars
line19 = Line(screen, (105,105,105), (950,190), (950,340), 5)
line20 = Line(screen, (105,105,105), (1003,300), (1003,340), 5)
line21 = Line(screen, (105,105,105), (1050,140), (1050,340), 5)

#UCDrama Outline
line22 = Line(screen, (105,105,105), (80,380), (250,80), 2) #left
line23 = Line(screen, (105,105,105), (900,380), (730,80), 2) #right
line24 = Line(screen, (105,105,105), (205,160), (775,160), 2) #top
line25 = Line(screen, (105,105,105), (143,270), (838,270), 2) #bot
line26 = Line(screen, (105,105,105), (620,300), (700,380), 2) #flagpole

#itemBlock
rect1 = Rect(screen, (105,105,105), (1113,120,45,45)) #Item bar 1-5
rect2 = Rect(screen, (105,105,105), (1113,240,45,45))
rect3 = Rect(screen, (105,105,105), (1113,360,45,45))
rect4 = Rect(screen, (105,105,105), (1113,480,45,45))
rect5 = Rect(screen, (105,105,105), (1113,600,45,45))


#Game frame
day = Text("Day 2", 33, (85, 30), 0)
week = Text("Week 3", 33, (195, 10), 0)
time = Text("Noon", 33, (335, 40), 0)

#How to smartly break lines
firstLine = Text("...Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod",
                        30, (100,420), 0)
secondLine = Text("tempor incididunt ut labore et dolore magna aliqua.",
                         30, (110,450), 0)
thirdLine = Text("...Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu",
                         30,(100,500), 0)
fourthLine = Text("fugiat nulla pariatur.",
                         30,(110,530), 0)
fifthLine = Text("...Etiam erat velit scelerisque in. Metus dictum at tempor commodo ullamco",
                         30,(100,580), 0)
sixthLine = Text("met nisl purus consequat id porta nibh in mollis nunc sed id semper.",
                         30,(110, 610), 0)


#Render
# owner and dogs and balls

click1 = Clickable("owner",20,(320, 300), 0) #20
click2 = Clickable("owner",20,(250,340), 0)
click3 = Clickable("dog",20,(220, 290), 0) #14
click4 = Clickable("dog",20,(350, 320), 0)
click5 = Clickable("dog",20,(300,320), 0)
click5 = Clickable("dog",20,(310,350), 0)
click5 = Clickable("dog",20,(260,330), 0)
text1 = Text("ball",10,(220,305), 0) #10

#Dog students
text2 = Text("S", 18, (300,290), 0) #18
text3 = Text("S", 18, (320,330), 0)
text4 = Text("S", 18, (270,310), 0)
text5 = Text("S", 18, (210,300), 0)
text6 = Text("S", 18, (350,340), 0)
text7 = Text("S", 18, (340,320), 0)

#student 5 (210, 300) holds the ball
chara5 = Character("dog", 18, (236,290), 4)
chara6 = Character("Toby", 10, (220,290), 8)


#Freesbe Students
text8 = Text("S", 18, (270,170), 0)
text9 = Text("S", 18, (490,180), 0)
text10 = Text("S", 18, (270,230), 0)
text11 = Text("S", 18, (470,240), 0)
text12 = Text("frisbee", 10, (400, 230), 0) #10


chara8 = Character("S", 18, (270,170), 3)
chara9 = Character("S", 18, (490,180), 3)
chara10 = Character("S", 18, (270,230), 3)
chara11 = Character("S", 18, (470,240), 3)
chara12 = Character("frisbee", 10, (400,230), 3)


#Drone Studenst
text13 = Text("S", 18, (340,320), 0)

#you
you = Character("You", 12, (700,320), 4)

text14 = Text("t", 18, (260,80), 0) #18
text15 = Text("r", 18, (260,90), 0)
text16 = Text("e", 18, (260,100), 0)
text17 = Text("e", 18, (258,110), 0)

text18 = Text("t", 18, (205,170), 0)
text19 = Text("r", 18, (205,180), 0)
text20 = Text("e", 18, (203,190), 0)
text21 = Text("e", 18, (203,200), 0)

text22 = Text("t", 18, (151,280), 0)
text23 = Text("r", 18, (150,290), 0)
text24 = Text("e", 18, (150,300), 0)
text25 = Text("e", 18, (150,310), 0)

text26 = Text("t", 18, (720,80), 0)
text27 = Text("r", 18, (720,90), 0)
text28 = Text("e", 18, (720,100), 0)
text29 = Text("e", 18, (720,110), 0)

text30 = Text("t", 18, (770,170), 0)
text31 = Text("r", 18, (770,180), 0)
text32 = Text("e", 18, (770,190), 0)
text33 = Text("e", 18, (770,200), 0)

text34 = Text("t", 18, (840,280), 0)
text35 = Text("r", 18, (840,290), 0)
text36 = Text("e", 18, (840,300), 0)
text37 = Text("e", 18, (840,310), 0)

text38 = Text("t", 18, (240,100), 0)
text39 = Text("r", 18, (240,110), 0)
text40 = Text("e", 18, (240,120), 0)
text41 = Text("e", 18, (240,130), 0)

text42 = Text("t", 18, (190,200), 0)
text43 = Text("r", 18, (190,210), 0)
text44 = Text("e", 18, (190,220), 0)
text45 = Text("e", 18, (190,230), 0)

text46 = Text("t", 18, (130,310), 0)
text47 = Text("r", 18, (130,320), 0)
text48 = Text("e", 18, (130,330), 0)
text49 = Text("e", 18, (130,340), 0)

text50 = Text("t", 18, (740,100), 0)
text51 = Text("r", 18, (740,110), 0)
text52 = Text("e", 18, (740,120), 0)
text53 = Text("e", 18, (740,130), 0)

text54 = Text("t", 18, (795,210), 0)
text55 = Text("r", 18, (798,220), 0)
text56 = Text("e", 18, (795,230), 0)
text57 = Text("e", 18, (795,240), 0)

text58 = Text("t", 18, (860,320), 0)
text59 = Text("r", 18, (860,330), 0)
text60 = Text("e", 18, (860,340), 0)
text61 = Text("e", 18, (860,350), 0)

text62 = Text("CUC", 64,(80, 100), 55) #64   55
text63 = Text("Drama", 64, (770,100), -60) #64 -60

choice1 = Clickable("rest", 24, (950,150), 0)
choice2 = Clickable("explore", 24, (950,180), 0)
choice3 = Clickable("explore", 24, (950,210), 0)

text64 = Text("???", 8,(80, 100), 0)
text65 = Text("???", 8,(80, 100), 0)
text66 = Text("???", 8,(80, 100), 0)
text67 = Text("???", 8,(80, 100), 0)
text68 = Text("???", 8,(80, 100), 0)


choices = [choice1, choice2]

frames = [firstLine, secondLine, thirdLine, fourthLine, 
        fifthLine, sixthLine]

lines = [line1, line2, line3, line4, line5, line6, line7, line8, line9, line10, 
        line11, line12, line13, line14, line15, line16, line17, line18, 
         line22, line23, line24, line25, line26]

rects = [rect1, rect2, rect3, rect4, rect5]

texts = [text1, text2, text3, text4, text5, text6, text7,
        text13, text14, text15, text16, text17, text18, text19,
        text20, text21, text22, text23, text24, text25, text26, text27, text28,
        text29, text30, text31, text32, text33, text34, text35, text36,
        text37, text38, text39, text40, text41, text42, text43, text44, text45,
        text46, text47, text48, text49, text50, text51, text52, text53, text54,
        text55, text56, text57, text58, text59, text60, text61, text62, text63]

things = []

clickables = [click1, click2, click4, click5]

characters = [you]

students = [chara8, chara9, chara10, chara11, chara12, 
            chara5, chara6]

def display(time):
    clock = pygame.time.Clock()
    clock.tick(200)
    pygame.event.pump()
    screen.fill((255, 255, 255))
    g = DijkGrid(90, 38)
    g.walls = getObstacles(things)
    #drawGrid()
    #g.draw()
    pathDiction = {}

    health = Text(f'Health: {str(objectCharacter.Ben.health)}', 24, (930,280), 0)
    sanity = Text(f'Sanity: {str(objectCharacter.Ben.sanity)}', 24, (930,310), 0)
    knowledge = Text(f'Knowledge: {str(objectCharacter.Ben.knowledge)}', 24, (930,340), 0)
    health.draw()
    sanity.draw()
    knowledge.draw()

    if len(objectCharacter.Ben.pathMap) > 0:
    #print(you.pos)
        nextPos = (objectCharacter.Ben.pathMap[0][0] * 10, 
                    objectCharacter.Ben.pathMap[0][1] * 10)
        objectCharacter.Ben.pathMap.pop(0)
        you.set_target(nextPos)
        vecYouPos = (you.pos[0]//10, you.pos[1]//10)
        you.update()


    action = Text(f'Action: {objectCharacter.Ben.actionPoint} / 4', 18, (930,100), 0)
    action.draw()

#Draw top hour day week
    day = Text(time[1], 33, (85,30), 0)
    week = Text(time[2], 33, (195,10), 0)
    hour = Text(time[0], 33, (335,40), 0)
    hour.draw()
    day.draw()
    week.draw()


    s5Pos = (random.randint(250, 280), random.randint(285, 320))
    if s5Stat.stat == "still":
        chara5.set_target(s5Pos)
        s5Stat.stat = "move"
        s5Stat.targetPos = s5Pos
    chara5.update()
    if s5Stat.stat == "move":
        if chara5.pos == s5Stat.targetPos:
            s5Stat.stat = "still"

    s6Pos = (random.randint(400, 700), random.randint(290, 320))
    if s6Stat.stat == "still":
        chara6.set_target(s6Pos)
        s6Stat.stat = "move"
        s6Stat.targetPos = s6Pos
    chara6.update()
    if s6Stat.stat == "move":
        if chara6.pos == s6Stat.targetPos and you.rect.collidepoint(chara6.pos):
            if "Artifact" in objectCharacter.Ben.items:
                chara6.text = ""
                objectCharacter.Ben.items.append("Toby")
            else:
                s6Stat.stat = "still"
    




    s8Pos = (random.randint(250, 500), random.randint(160, 210))
    if s8Stat.stat == "still" and s12Stat.stat == "still":
        chara8.set_target(s8Pos)
        s8Stat.stat = "move"
        s8Stat.targetPos = s8Pos
    chara8.update()
    if s8Stat.stat == "move":
        if chara8.pos == s8Stat.targetPos:
            s8Stat.stat = "still"

    s9Pos = (random.randint(450, 730), random.randint(160, 210))
    if s9Stat.stat == "still" and s12Stat.stat == "still":
        chara9.set_target(s9Pos)
        s9Stat.stat = "move"
        s9Stat.targetPos = s9Pos
    chara9.update()
    if s9Stat.stat == "move":
        if chara9.pos == s9Stat.targetPos:
            s9Stat.stat = "still"

    s10Pos = (random.randint(230, 450), random.randint(180, 250))
    if s10Stat.stat == "still" and s12Stat.stat == "still":
        chara10.set_target(s10Pos)
        s10Stat.stat = "move"
        s10Stat.targetPos = s10Pos
    chara10.update()
    if s10Stat.stat == "move":
        if chara10.pos == s10Stat.targetPos:
            s10Stat.stat = "still"

    s11Pos = (random.randint(300, 760), random.randint(200, 250))
    if s11Stat.stat == "still" and s12Stat.stat == "still":
        chara11.set_target(s11Pos)
        s11Stat.stat = "move"
        s11Stat.targetPos = s11Pos
    chara11.update()
    if s11Stat.stat == "move":
        if chara11.pos == s11Stat.targetPos:
            s11Stat.stat = "still"

    s12Pos = [s8Stat.targetPos, s9Stat.targetPos, s10Stat.targetPos, s11Stat.targetPos]
    if s12Stat.stat == "still":
        tempPos = random.choice(s12Pos)
        chara12.set_target(tempPos)
        s12Stat.stat = "move"
        s12Stat.targetPos = tempPos
    chara12.update()
    if s12Stat.stat == "move":
        if chara12.pos == s12Stat.targetPos:
            s12Stat.stat = "still"

    if you.rect.collidepoint(chara12.pos):
        s12Stat.stat = "grabbed"
    
    if s12Stat.stat == "grabbed":
        chara12.pos = you.pos
        s12Stat.targetpos = you.pos
        chara12.set_target(you.pos)

        saying = ["?", "??", "???", "?>!@#", "?!", "&*!@*#", "&^!@S", 
                    "!!!", "!", ".....", "@#$!@"]

        text64.text = random.choice(saying)
        text64.pos = (chara8.pos[0] + random.randint(-25, 15), 
                        chara8.pos[1] + random.randint(-10, -5))
        text64.draw()

        text65.text = random.choice(saying)
        text65.pos = (chara9.pos[0] + random.randint(-25, 15), 
                        chara9.pos[1] + random.randint(-10, -5))
        text65.draw()

        text66.text = random.choice(saying)
        text66.pos = (chara10.pos[0] + random.randint(-25, 15), 
                        chara10.pos[1] + random.randint(-10, -5))
        text66.draw()
    
        text67.text = random.choice(saying)
        text67.pos = (chara11.pos[0] + random.randint(-25, 15), 
                        chara11.pos[1] + random.randint(-10, -5))
        text67.draw()

        chara8.set_target(you.pos)
        chara9.set_target(you.pos)
        chara10.set_target(you.pos)
        chara11.set_target(you.pos)

        if you.rect.collidepoint(chara8.pos) or you.rect.collidepoint(chara9.pos) \
            or you.rect.collidepoint(chara10.pos) or you.rect.collidepoint(chara11.pos):
            objectCharacter.Ben.health -= 1
            if objectCharacter.Ben.actionPoint > 0:
                objectCharacter.Ben.actionPoint -= 1
            s12Stat.stat = "still"

            s11Stat.stat == "still"
            s10Stat.stat == "still"
            s9Stat.stat == "still"
            s8Stat.stat == "still"
            s8Stat.targetPos = s8Pos
            s9Stat.targetPos = s9Pos
            s10Stat.targetPos = s10Pos
            s11Stat.targetPos = s11Pos
            chara8.set_target(s8Pos)
            chara9.set_target(s9Pos)
            chara10.set_target(s10Pos)
            chara11.set_target(s11Pos)
            



    for student in students:
        student.draw()
        student.update()

    for choice in choices:
        if choice.rect.collidepoint(pygame.mouse.get_pos()):
            choice.hovered = True
        else:
            choice.hovered = False
        
        choice.draw()

#Original Frame
    for line in lines:
        line.draw()
    
    for rect in rects:
        rect.draw()
        
#Game Frames
    objectText.textBox.draw()

#texts
    for text in texts:
        text.draw()

    for chara in characters:
        chara.draw()
        chara.update()
        #pygame.draw.line(screen, (105, 105, 105), chara.pos, 
        #chara.endPoint, 1)

#Interactiables
    for click in clickables:
        if click.rect.collidepoint(pygame.mouse.get_pos()):
            click.hovered = True
        else:
            click.hovered = False
        
        click.draw()


    keys = pygame.key.get_pressed()

    if keys[pygame.K_SPACE]:
        objectCharacter.Ben.actionPoint = 4
        return 42

    
    for event in pygame.event.get():
        
        if event.type == pygame.QUIT:
            run = False
            pygame.quit()

        if event.type == pygame.MOUSEBUTTONUP:
            cX, cY = pygame.mouse.get_pos()
            vecPos = vec(pygame.mouse.get_pos()) // TILESIZE
            if ((cX >= 80) and (cX <= 960) and (cY >=20) and (cY <=380)):
                if vecPos not in g.walls:
                    pathDiction = aStar(g, vecPos, 
                            vec(you.pos[0]//10, you.pos[1]//10))

                    objectCharacter.Ben.pathMap = findRoute(pathDiction, 
                                                    (you.pos[0]//10, you.pos[1]//10),
                                                        intVec(vecPos))
                                        
            for choice in choices:
                if choice.rect.collidepoint(pygame.mouse.get_pos()):
                    if objectCharacter.Ben.actionPoint > 0:
                        if choice == choice1:
                            objectCharacter.Ben.actionPoint -= 1
                            objectCharacter.Ben.health += 3
                            objectCharacter.Ben.sanity += 3
                            quotes1 = {
                                "You sat down on the lawn":(5, 3, -3),
                                "This seems to be a good time for you to take a rest.":(7, 2, -5),
                                "There are definately better things that you can do, but you ended up going with the second best choice.":(2, 6, -3),
                            }
                            tempResponse = random.choice(list(quotes1.keys()))
                            objectCharacter.Ben.health += quotes1[tempResponse][0]
                            objectCharacter.Ben.sanity += quotes1[tempResponse][1]
                            objectCharacter.Ben.knowledge += quotes1[tempResponse][2]
                            objectText.textBox.bundle(tempResponse, objectCharacter.Ben.sanity)


                        elif choice == choice2:
                            objectCharacter.Ben.actionPoint -= 1
                            items = ["Fedora", "Kimchee", "copying toast", "PyZero", "Stella", "Artifact", "chair"]
                            chose = random.choice(items)
                            if chose not in objectCharacter.Ben.items:
                                objectText.textBox.bundle(f'It seems like you found a (the) {chose}.', 99)
                                objectCharacter.Ben.items.append(chose)
                            else:
                                objectText.textBox.bundle("No luck this time it seems.", 99)
                                




    pygame.display.update()

    