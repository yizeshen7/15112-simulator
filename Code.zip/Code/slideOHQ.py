

import random
import objectDate
import objectCharacter
import objectText

import pygame
pygame.init()
screen = pygame.display.set_mode((1280, 720))
pygame.display.set_caption("slideOHQ")

class Character(object):

    def __init__(self, text, size, pos, speed):
        self.text = text
        self.size = size
        self.pos = pos
        self.speed = speed
        self.set_rect()
        self.endPoint = (0,0)
        self.pos = pygame.Vector2(self.pos)
        self.set_target(self.pos)

    def set_target(self, pos):
        self.target = pygame.Vector2(pos)
        self.endPoint = pos

    def set_rend(self):
        font = pygame.font.SysFont('Times New Roman', self.size)
        self.rend = font.render(self.text, True, (105, 105, 105))

    def set_rect(self):
        self.set_rend()
        self.rect = self.rend.get_rect()
        self.box = (self.pos[0], self.pos[1], self.rect[2], self.rect[3])
        self.rect.topleft = self.pos
    
    def draw(self):
        font = pygame.font.SysFont('Times New Roman', self.size)
        rend = font.render(self.text, True, (105, 105, 105))
        screen.blit(rend, self.pos)

    #Concept (normalize_ip) taken from https://stackoverflow.com/questions/16288905/make-a-sprite-move-to-the-mouse-click-position-step-by-step
    def update(self):
        move = self.target - self.pos
        moveLength = move.length()

        if moveLength < self.speed:
            self.pos = self.target

        elif moveLength != 0:
            move.normalize_ip()
            move = move * self.speed
            self.pos += move
        
        self.box = (self.pos[0], self.pos[1], self.rect[2], self.rect[3])


def check_collision(playerRect, obstacleRect):
    #convert rectangles into x,y,w,h
    playerX = playerRect[0]
    playerY = playerRect[1]
    playerWidth = playerRect[2]
    playerHeight = playerRect[3]

    obstacleX = obstacleRect[0]
    obstacleY = obstacleRect[1]
    obstacleWidth = obstacleRect[2]
    obstacleHeight = obstacleRect[3]

    #get the right left top and bottom
    myRight = playerX + playerWidth
    myLeft = playerX
    myTop = playerY
    myBottom = playerY + playerHeight

    otherRight = obstacleX + obstacleWidth
    otherLeft = obstacleX
    otherTop = obstacleY
    otherBottom = obstacleY + obstacleHeight

    #now the collision code
    collision = True

    if ((myRight < otherLeft) or (myLeft > otherRight) \
        or (myBottom < otherTop) or (myTop > otherBottom)):
        collision = False

    return collision


you = Character("You", 18, (700,320), 3)
characters = [you]

class Line(object):
    grey = (105, 105, 105)
    white = (255, 255, 255)
    def __init__(self, canvas, color, sp, ep, width):
        self.canvas = canvas
        self.color = color
        self.sp = sp
        self.ep = ep
        self.width = width
    
    def draw(self):
        pygame.draw.line(self.canvas, self.color, self.sp, self.ep,
                            self.width)

class Rect(object):
    grey = (105, 105, 105)
    white = (255, 255, 255)
    def __init__(self, canvas, color, tlsize):
        self.canvas = canvas
        self.color = color
        self.tlsize = tlsize
    
    def draw(self):
        pygame.draw.rect(self.canvas, self.color, self.tlsize)

#OHQ
class Clickable(object):
    hovered = False

    def __init__(self, text, size, pos, tilt):
        self.text = text
        self.pos = pos
        self.size = size
        self.tilt = tilt
        self.clicked = False
        self.set_rect()
        self.draw()

    def set_rend(self):
        font = pygame.font.SysFont('Times New Roman', self.size)
        self.rend = font.render(self.text, True, self.getcolor())
        self.rend = pygame.transform.rotate(self.rend, self.tilt)
        
    def getcolor(self):
        if self.hovered:
            return (0, 0, 0)
        else:
            return (105, 105, 105)
        
    def set_rect(self):
        self.set_rend()
        self.rect = self.rend.get_rect()
        self.rect.topleft = (self.pos)

    def draw(self):
        self.set_rend()
        screen.blit(self.rend, self.rect) #The text    

class Text(object):
    grey = (105, 105, 105)
    white = (255, 255, 255)

    def __init__(self, text, size, pos, tilt):
        self.text = text
        self.pos = pos
        self.size = size
        self.tilt = tilt
    
    def draw(self):
        font = pygame.font.SysFont('Times New Roman', self.size)
        rend = font.render(self.text, True, self.grey)
        rend = pygame.transform.rotate(rend, self.tilt)
        screen.blit(rend, (self.pos))

class Icon(object):

    def __init__(self, direct, direct2, size, pos):
        self.direct = direct
        self.pos = pos
        self.size = size
        self.hovered = False

    def getIcon(self, direct):
        icon = pygame.image.load(direct)
        icon = pygame.transform.scale(icon, (self.size, self.size))
        return icon

    def draw(self):
        if self.hovered == False:
            icon = self.getIcon(self.direct)
        elif self.hovered == True:
            icon = self.getIcon(self.direct2)
        screen.blit(icon, (self.pos))


Line1 = Line(screen, (105,105,105), (80,80), (900,80), 4)
Line2 = Line(screen, (105,105,105), (80,80), (80,380), 4)
Line3 = Line(screen, (105,105,105), (80,380), (900,380), 4)
Line4 = Line(screen, (105,105,105), (900,80), (900,380), 4)

Line5 = Line(screen, (105,105,105), (920,80), (1080,80), 4)
Line6 = Line(screen, (105,105,105), (920,80), (920,380), 4)
Line7 = Line(screen, (105,105,105), (920,380), (1080,380), 4)
Line8 = Line(screen, (105,105,105), (1080,80), (1080,380), 4)

Line9 = Line(screen, (105,105,105), (80,400), (1080,400), 4)
Line10 = Line(screen, (105,105,105), (80,400), (80,680), 4)
Line11 = Line(screen, (105,105,105), (80,680), (1080,680), 4)
Line12 = Line(screen, (105,105,105), (1080,400), (1080,680), 4)

Line13 = Line(screen, (105,105,105), (1100,80), (1170,80), 4)
Line14 = Line(screen, (105,105,105), (1100,680), (1170,680), 4)
Line15 = Line(screen, (105,105,105), (1100,80), (1100,680), 4)
Line16 = Line(screen, (105,105,105), (1170,80), (1170,680), 4)

#ScrollIndicator
Line17 = Line(screen, (105,105,105), (1055,420), (1055,660), 4) #Black 240
Line18 = Line(screen, (255,255,255), (1055,440), (1055,490), 4) #White 50

#itemBlock
rect1 = Rect(screen, (105,105,105), (1113,120,45,45)) #Item bar 1-5
rect2 = Rect(screen, (105,105,105), (1113,240,45,45))
rect3 = Rect(screen, (105,105,105), (1113,360,45,45))
rect4 = Rect(screen, (105,105,105), (1113,480,45,45))
rect5 = Rect(screen, (105,105,105), (1113,600,45,45))


#Game frame
day = Text("Day 2", 33, (85,30), 0)
week = Text("Week 3", 33, (195,10), 0)
time = Text("Noon", 33, (335,40), 0)

#How to smartly break lines
firstLine = Text("...Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod",
                        30, (100,420), 0)
secondLine = Text("tempor incididunt ut labore et dolore magna aliqua.",
                         30, (110,450), 0)
thirdLine = Text("...Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu",
                         30,(100,500), 0)
fourthLine = Text("fugiat nulla pariatur.",
                         30,(110,530), 0)
fifthLine = Text("...Etiam erat velit scelerisque in. Metus dictum at tempor commodo ullamco",
                         30,(100,580), 0)
sixthLine = Text("met nisl purus consequat id porta nibh in mollis nunc sed id semper.",
                         30,(110,610), 0)
#Entrollpy Outline


#OHQ Things
#employee1 = Clickable("employee", 18, 765,265, -45)
#day = Text("Day 2", 33, 85,30, 0)
#Line18 = Line(screen, (105,105,105), (1055,440), (1055,490), 4)

Line19 = Line(screen, (105,105,105), (80,130), (900,130), 2)

Line20 = Line(screen, (105,105,105), (200,150), (780,150), 2) #top box
Line21 = Line(screen, (105,105,105), (200,230), (780,230), 2)
Line22 = Line(screen, (105,105,105), (200,150), (200,230), 2)
Line23 = Line(screen, (105,105,105), (780,150), (780,230), 2)

Line24 = Line(screen, (105,105,105), (200,250), (780,250), 2) #bot box
Line25 = Line(screen, (105,105,105), (200,250), (200,360), 2)
Line26 = Line(screen, (105,105,105), (780,250), (780,360), 2)
Line27 = Line(screen, (105,105,105), (200,360), (780,360), 2)

Line28 = Line(screen, (105,105,105), (230,180), (750,180), 2) #top inner
Line29 = Line(screen, (105,105,105), (230,280), (750,280), 2) #bot inner

#top text
text1 = Text("Happening now", 12, (230, 160), 0)
text2 = Text("The queue is open", 12, (230, 187), 0)
text3 = Text("39 students", 18, (230, 205), 0)
text4 = Text("are on the queue", 18, (315, 205), 0)

#bot text
text5 = Text("Your question", 12, (230, 260), 0)
text6 = Text("You are", 16, (260, 290), 0)
text7 = Text("18th", 16, (310, 290), 0)
text8 = Text("in line", 16, (340, 290), 0)
text9  = Text("GHC 5208", 12, (265, 317), 0)
text10  = Text("Homework", 12, (265, 340), 0)

#Header text
text11 = Text("15-112 Queue", 36, (380, 85), 0)
text12 = Text("Courses", 14, (100, 100), 0)
text13 = Text("Queue", 14, (160, 100), 0)
text14 = Text("FAQ", 14, (670, 100), 0)
text15 = Text("Debugging", 14, (710, 100), 0)
text16 = Text("Account", 14, (780, 100), 0)
click1 = Clickable("Log out", 14, (840, 100), 0)




icon1 = Icon("images/pause1.png", "images/pause2.png", 20, (650, 257))
icon2 = Icon("images/mark1.png", "images/mark2.png", 20, (680, 257))
icon3 = Icon("images/trashC1.png", "images/trashC2.png", 20, (715, 257))
icon4 = Icon("images/rank1.png", "images/rank2.png", 20, (230, 290))
icon5 = Icon("images/destination1.png", "images/destination2.png", 20, (230, 312))
icon6 = Icon("images/help1.png", "images/help2.png", 20, (230, 335))




  


frames = [firstLine, secondLine, thirdLine, fourthLine, 
        fifthLine, sixthLine]

texts = [text1, text2, text4, text5, text6, text8, text9,
        text10, text11, text12, text13, text14, text15, text16,
        ]

icons = [icon1, icon2, icon3, icon4, icon5, icon6]

Lines = [Line1, Line2, Line3, Line4, Line5, Line6, Line7, Line8, Line9, Line10, 
        Line11, Line12, Line13, Line14, Line15, Line16, Line17, Line18, Line19,
        Line20, Line21, Line22, Line23, Line24, Line25, Line26, Line27, Line28,
        Line29]

clickables = [click1]

rects = [rect1, rect2, rect3, rect4, rect5]


def display(time):
    clock = pygame.time.Clock()
    clock.tick(2000)
    #pygame.time.delay(100)
    pygame.event.pump()
    screen.fill((255, 255, 255))

    text3 = Text(f'{objectCharacter.Ben.knowledge} students', 18, (230, 205), 0)
    text3.draw()
    if objectCharacter.Ben.knowledge > 0:
        print("here")
        objectCharacter.Ben.knowledge -= 1
        print(objectCharacter.Ben.knowledge)
        pygame.time.delay(random.randint(1000, 2500))

    text7 = Text(f'{objectCharacter.Ben.knowledge}th', 16, (310, 290), 0)
    text7.draw()


#Draw top hour day week
    day = Text(time[1], 33, (85,30), 0)
    week = Text(time[2], 33, (195,10), 0)
    hour = Text(time[0], 33, (335,40), 0)
    hour.draw()
    day.draw()
    week.draw()



#Original Frame
    for line in Lines:
        line.draw()
    
    for rect in rects:
        rect.draw()
        
#Game Frames
    objectText.textBox.draw()

#texts
    for text in texts:
        text.draw()

#icons
    for icon in icons:
        icon.draw()

    for clickable in clickables:
        if clickable.rect.collidepoint(pygame.mouse.get_pos()):
            clickable.hovered = True
        else:
            clickable.hovered = False
        clickable.draw()

#Keys and sticks
    keys = pygame.key.get_pressed()

    if keys[pygame.K_SPACE]:
        pass


    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            run = False
            pygame.quit()

        if event.type == pygame.MOUSEBUTTONUP:
            cX, cY = pygame.mouse.get_pos()
            if cX >= 80 and cX <= 900 and cY >=80 and cY <=380:
                pass
                #chara.set_target(pygame.mouse.get_pos())

            for click in clickables:
                if click.rect.collidepoint(pygame.mouse.get_pos()):
                    if click == click1:
                        return 42
 
    pygame.display.update()

