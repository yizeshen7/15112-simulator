


import objectDate
import objectCharacter
import objectText
import slideZoom

import random
import pygame
import heapq
pygame.init()
screen = pygame.display.set_mode((1280, 720))
pygame.display.set_caption("Dorm")


from os import path
from collections import deque

vec = pygame.math.Vector2


class Line(object):
    grey = (105, 105, 105)
    white = (255, 255, 255)
    def __init__(self, canvas, color, sp, ep, width):
        self.canvas = canvas
        self.color = color
        self.sp = sp
        self.ep = ep
        self.width = width
    
    def draw(self):
        pygame.draw.line(self.canvas, self.color, self.sp, self.ep,
                            self.width)

class Rect(object):
    grey = (105, 105, 105)
    white = (255, 255, 255)
    def __init__(self, canvas, color, tlsize):
        self.canvas = canvas
        self.color = color
        self.tlsize = tlsize
    
    def draw(self):
        pygame.draw.rect(self.canvas, self.color, self.tlsize)

class Text(object):
    grey = (105, 105, 105)
    white = (255, 255, 255)

    def __init__(self, text, size, position, tilt):
        self.text = text
        self.pos = position
        self.size = size
        self.tilt = tilt
        self.set_rect()
    
    def set_rect(self):
        font = pygame.font.SysFont('Times New Roman', self.size)
        rend = font.render(self.text, True, self.grey)
        rend = pygame.transform.rotate(rend, self.tilt)
        self.rend = rend
        self.rect = self.rend.get_rect()
        self.box = (self.pos[0], self.pos[1], self.rect[2], self.rect[3])
        self.rect.topleft = self.pos

    def checkCollision(self, playerBox):
    #convert rectangles into x,y,w,h
        playerX = playerBox[0]
        playerY = playerBox[1]
        playerWidth = playerBox[2]
        playerHeight = playerBox[3]

        obstacleX = self.box[0]
        obstacleY = self.box[1]
        obstacleWidth = self.box[2]
        obstacleHeight = self.box[3]

        #get the right left top and bottom
        myRight = playerX + playerWidth
        myLeft = playerX
        myTop = playerY
        myBottom = playerY + playerHeight

        otherRight = obstacleX + obstacleWidth
        otherLeft = obstacleX
        otherTop = obstacleY
        otherBottom = obstacleY + obstacleHeight

        #now the collision code
        checker = True

        if ((myRight < otherLeft) or (myLeft > otherRight) \
            or (myBottom < otherTop) or (myTop > otherBottom)):
            checker = False

        return checker

    def draw(self):
        font = pygame.font.SysFont('Times New Roman', self.size)
        rend = font.render(self.text, True, self.grey)
        rend = pygame.transform.rotate(rend, self.tilt)
        screen.blit(rend, self.pos)

class Character(object):

    def __init__(self, text, size, pos, speed):
        self.text = text
        self.size = size
        self.pos = pos
        self.speed = speed
        self.set_rect()
        self.endPoint = (0,0)
        self.pos = pygame.Vector2(self.pos)
        self.set_target(self.pos)

    def set_target(self, pos):
        self.target = pygame.Vector2(pos)
        self.endPoint = pos

    def set_rend(self):
        font = pygame.font.SysFont('Times New Roman', self.size)
        self.rend = font.render(self.text, True, (105, 105, 105))

    def set_rect(self):
        self.set_rend()
        self.rect = self.rend.get_rect()
        self.box = (self.pos[0], self.pos[1], self.rect[2], self.rect[3])
        self.rect.topleft = self.pos
    
    def draw(self):
        font = pygame.font.SysFont('Times New Roman', self.size)
        rend = font.render(self.text, True, (105, 105, 105))
        screen.blit(rend, self.pos)

    #Concept(normalize_ip) taken from https://stackoverflow.com/questions/16288905/make-a-sprite-move-to-the-mouse-click-position-step-by-step
    def update(self):
        move = self.target - self.pos
        moveLength = move.length()

        if moveLength < self.speed:
            self.pos = self.target

        elif moveLength != 0:
            move.normalize_ip()
            move = move * self.speed
            self.pos += move

        self.box = (self.pos[0], self.pos[1], self.rect[2], self.rect[3])
    

class Clickable(object):

    def __init__(self, text, size, pos, tilt):
        self.text = text
        self.pos = pos
        self.size = size
        self.tilt = tilt
        self.hovered = False
        self.clicked = False
        self.set_rect()
        self.draw()

    def draw(self):
        self.set_rend()
        screen.blit(self.rend, self.rect)
        
    def set_rend(self):
        font = pygame.font.SysFont('Times New Roman', self.size)
        self.rend = font.render(self.text, True, self.getcolor())
        self.rend = pygame.transform.rotate(self.rend, self.tilt)
        
    def getcolor(self):
        if self.hovered:
            return (0, 0, 0)
        else:
            return (105, 105, 105)
        
    def set_rect(self):
        self.set_rend()
        self.rect = self.rend.get_rect()
        self.box = (self.pos[0], self.pos[1], self.rect[2], self.rect[3])
        self.rect.topleft = self.pos


    #Concept(index into tuples & boxes) from https://stackoverflow.com/questions/35001207/how-to-detect-collision-between-objects-in-pygame
    def checkCollision(self, playerBox):
    #convert rectangles into x,y,w,h
        playerX = playerBox[0]
        playerY = playerBox[1]
        playerWidth = playerBox[2]
        playerHeight = playerBox[3]

        obstacleX = self.box[0]
        obstacleY = self.box[1]
        obstacleWidth = self.box[2]
        obstacleHeight = self.box[3]

        #get the right left top and bottom
        myRight = playerX + playerWidth
        myLeft = playerX
        myTop = playerY
        myBottom = playerY + playerHeight

        otherRight = obstacleX + obstacleWidth
        otherLeft = obstacleX
        otherTop = obstacleY
        otherBottom = obstacleY + obstacleHeight

        #now the collision code
        checker = True

        if ((myRight < otherLeft) or (myLeft > otherRight) \
            or (myBottom < otherTop) or (myTop > otherBottom)):
            checker = False

        return checker

        
class Grid(object):
    def __init__(self, width, height):
        self.width = width
        self.height = height
        self.walls = [(10, 7)]
        #self.connections = [vec(1, 0), vec(-1, 0), vec(0, 1), vec(0, -1), 
                            #vec(-1, 1), vec(-1, -1), vec(1, 1), vec(1, -1)]
        self.connections = [vec(1, 0), vec(-1, 0), vec(0, 1), vec(0, -1)]

    def isInBound(self, node):
        if node.x >= 0 and node.x < self.width:
            if node.y >= 0 and node.y < self.height:
                return True
        return False

    def isPassable(self, node):
        if node in self.walls:
            return False
        return True

    def getNeighbors(self, node):
        counter = 0
        self.neighbors = []
        for direction in self.connections:
            counter += 1
            temp = node + direction
            #Didn't implement no perference path
            if self.isInBound(temp) == True:
                if self.isPassable(temp) == True:
                    self.neighbors.append(temp)
        return self.neighbors

    def draw(self):
        for wall in self.walls:
            rect = pygame.Rect((wall[0])*TILESIZE, (wall[1])*TILESIZE,
                                TILESIZE, TILESIZE)
            pygame.draw.rect(screen, (105, 105, 105), rect)


class DijkGrid(Grid):
    def __init__(self, width, height):
        super().__init__(width, height)
        self.weights = {}
    
    def cost(self, fromNode, toNode):
        checker = (abs(fromNode[0] - toNode[0]) - \
                    abs(fromNode[1] - toNode[1])) ** 0.5
        if checker == 1:
            return self.weights.get(toNode, 0) + 10
        else:
            return self.weights.get(toNode, 0) + 14


class PriorityQueue(object):
    def __init__(self):
        self.nodes = []

    def put(self, node, cost):
        heapq.heappush(self.nodes, (cost, node))

    def get(self):
        return heapq.heappop(self.nodes)[1]

    def empty(self):
        checker = len(self.nodes)
        if checker == 0:
            return True
        else:
            return False

TILESIZE = 10
GRIDWIDTH = 90 #52
GRIDHEIGHT = 38 #15
WIDTH = TILESIZE * GRIDWIDTH
HEIGHT = TILESIZE * GRIDHEIGHT



def round(n):
    last = n % 10
    if last == 0:
        n = 10
    elif last <= 3:
        n = (n//10) * 10
    elif last > 3:
        n = (n//10) * 10 + 10
    return n
#no need to worry about +230, just a placeholder
def drawGrid():
    for x in range(0, WIDTH+1, TILESIZE):
        pygame.draw.line(screen, (105,105,105), (x, 0), (x, HEIGHT))
    for y in range(0, HEIGHT+1, TILESIZE):
        pygame.draw.line(screen, (105,105,105), (0, y), (WIDTH, y))

def getObstacles(things):
    obstacles = []
    for text in things:
        coordinateTop = (text.pos[0]//10, text.pos[1]//10)
        obstacles.append(coordinateTop)

        restX, restY = (round(text.box[2]) //10, round(text.box[3]) //10)
        for i in range (0, restX ):
            for j in range(0, restY):
                coordinateTemp = (coordinateTop[0] + i, coordinateTop[1] + j)
                obstacles.append(coordinateTemp)

    for stuff in obstacles:
        g.weights[stuff] = 20

    return obstacles

def intVec(vector):
    return (int(vector[0]), int(vector[1]))

#Concept (deque) from: https://www.youtube.com/watch?v=hettiSrJjM4
#Concept (deque) from: https://www.youtube.com/watch?v=hettiSrJjM4
def ruleOfThumb(node1, node2):
    #mahattan distance
    distance = (abs(node1[0] - node2[0]) + \
                    abs(node1[1] - node2[1]))

    value = 10 * distance
    return value

#From https://www.youtube.com/watch?v=fa1NSUBqiJc
def aStar(graph, start, end):
    frontier = PriorityQueue()
    frontier.put(intVec(start), 0)
    path = {}
    cost = {}
    path[intVec(start)] = None
    cost[intVec(start)] = 0

    while frontier.empty() == False:
        current = frontier.get()
        if current == end:
            break
        for next in graph.getNeighbors(vec(current)):
            next = intVec(next)
            nextCost = cost[current] + graph.cost(current, next)
            if next not in cost or nextCost < cost[next]:
                cost[next] = nextCost
                priority = nextCost + ruleOfThumb(end, vec(next))
                frontier.put(next, priority)
                path[next] = vec(current) - vec(next)
    
    return path

def findRoute(diction, playerInital, gridMousePos):
    playerInital = intVec(playerInital)
    pathMap = []
    while playerInital != (gridMousePos): #should be mouse position
        if playerInital in diction:
            tempDirect = diction[playerInital]
            tempDirect = intVec(tempDirect)

            tempPos = (playerInital[0] + tempDirect[0],
                        playerInital[1] + tempDirect[1])

            pathMap.append(tempPos)

            playerInital = tempPos

    print(pathMap)
    return pathMap


g= DijkGrid(90, 38)
path = aStar(g, vec(28,28), vec(70,32))

Line1 = Line(screen, (105,105,105), (80,80), (900,80), 4)
Line2 = Line(screen, (105,105,105), (80,80), (80,380), 4)
Line3 = Line(screen, (105,105,105), (80,380), (900,380), 4)
Line4 = Line(screen, (105,105,105), (900,80), (900,380), 4)

Line5 = Line(screen, (105,105,105), (920,80), (1080,80), 4)
Line6 = Line(screen, (105,105,105), (920,80), (920,380), 4)
Line7 = Line(screen, (105,105,105), (920,380), (1080,380), 4)
Line8 = Line(screen, (105,105,105), (1080,80), (1080,380), 4)

Line9 = Line(screen, (105,105,105), (80,400), (1080,400), 4)
Line10 = Line(screen, (105,105,105), (80,400), (80,680), 4)
Line11 = Line(screen, (105,105,105), (80,680), (1080,680), 4)
Line12 = Line(screen, (105,105,105), (1080,400), (1080,680), 4)

Line13 = Line(screen, (105,105,105), (1100,80), (1170,80), 4)
Line14 = Line(screen, (105,105,105), (1100,680), (1170,680), 4)
Line15 = Line(screen, (105,105,105), (1100,80), (1100,680), 4)
Line16 = Line(screen, (105,105,105), (1170,80), (1170,680), 4)

#ScrollIndicator
Line17 = Line(screen, (105,105,105), (1055,420), (1055,660), 4) #Black 240
Line18 = Line(screen, (255,255,255), (1055,440), (1055,490), 4) #White 50

#itemBlock
rect1 = Rect(screen, (105,105,105), (1113,120,45,45))
rect2 = Rect(screen, (105,105,105), (1113,240,45,45))
rect3 = Rect(screen, (105,105,105), (1113,360,45,45))
rect4 = Rect(screen, (105,105,105), (1113,480,45,45))
rect5 = Rect(screen, (105,105,105), (1113,600,45,45))

#Game frame
day = Text("Day 2", 33, (85, 30), 0)
week = Text("Week 3", 33, (195, 10), 0)
time = Text("Noon", 33, (335, 40), 0)


#How to smartly break lines
firstLine = Text("...Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod",
                        30, (100,420), 0)
secondLine = Text("tempor incididunt ut labore et dolore magna aliqua.",
                         30, (110,450), 0)
thirdLine = Text("...Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu",
                         30,(100,500), 0)
fourthLine = Text("fugiat nulla pariatur.",
                         30,(110,530), 0)
fifthLine = Text("...Etiam erat velit scelerisque in. Metus dictum at tempor commodo ullamco",
                         30,(100,580), 0)
sixthLine = Text("met nisl purus consequat id porta nibh in mollis nunc sed id semper.",
                         30,(110, 610), 0)

#Dorm outline
Line19 = Line(screen, (105,105,105), (230,230), (746,230), 2)
Line20 = Line(screen, (105,105,105), (80,380), (230,230), 2)
Line21 = Line(screen, (105,105,105), (900,380), (746,230), 2)
Line22 = Line(screen, (105,105,105), (230,80), (230,230), 2)
Line23 = Line(screen, (105,105,105), (746,80), (746,230), 2)




#Dorm
#Major Item
dresserOne = Text("dresser", 30, (240,240), 0)
deskOne = Text("desk", 30, (410,240), 0)
b1 = Text("b", 30, (550,240), 0)
e1 = Text("e", 30, (595,240), 0)
d1 = Text("d", 30, (640,240), 0)

dresserTwo = Text("dresser", 38, (210,300), 0)
deskTwo = Text("desk", 38, (400,300), 0)
b2 = Text("b", 38, (550,300), 0)
e2 = Text("e", 38, (595,300), 0)
d2 = Text("d", 38, (645,300), 0)

doord = Clickable("d", 38, (165,180), 0)
dooro1 = Clickable("o", 38, (165,200), 0)
dooro2 = Clickable("o", 38, (165,220), 0)
doorr = Clickable("r", 38, (165,240), 0)

#Roommate and you
roommate = Text("roommate", 22, (560,230), 0)
you = Character("You", 12, (700,320), 3)
#closet
closetc1 = Text("c", 28, (203,110), 0)
closetl1 = Text("l", 28, (205,135), 0)
closeto1 = Text("o", 28, (203,155), 0)
closets1 = Text("s", 28, (203,172), 0)
closete1 = Text("e", 28, (203,190), 0)
closett1 = Text("t", 28, (205,210), 0)

closetc2 = Text("c", 28, (120,180), 0)
closetl2 = Text("l", 28, (120,210), 0)
closeto2 = Text("o", 28, (120,230), 0)
closets2 = Text("s", 28, (120,250), 0)
closete2 = Text("e", 28, (118,270), 0)
closett2 = Text("t", 28, (120,290), 0)

#heater and windows
heater1 = Clickable("heater", 24, (735,230), -45)
heater2 = Clickable("heater", 24, (795,290), -45)

#Chairs
chair1 = Text("chair", 14, (400,260), 0)
chair2 = Text("chair", 14, (430,290), 0)

#Windows
windoww11 = Text("w", 28, (770,110), 0)
windowi1 = Text("i", 28, (773,130), 0)
windown1 = Text("n", 28, (770,150), 0)
windowd1 = Text("d", 28, (770,170), 0)
windowo1 = Text("o", 28, (770,190), 0)
windoww12 = Text("w", 28, (770,210), 0)

windoww21 = Text("w", 28, (840,160), 0)
windowi2 = Text("i", 28, (843,180), 0)
windown2 = Text("n", 28, (840,200), 0)
windowd2 = Text("d", 28, (840,220), 0)
windowo2 = Text("o", 28, (840,240), 0)
windoww22 = Text("w", 28, (840,260), 0)

# How to make two words together, like left shoe and right shoe
#Random stuff
orange1 = Text("orange", 12, (700,290), 0)
cloth1 = Text("cloth", 12, (720,310), 0)
cloth2 = Text("cloth", 12, (670,280), 0)
cloth3 = Text("cloth", 12, (570,330), 0)
cloth4 = Text("cloth", 12, (220,240), 0)
cloth5 = Text("cloth", 12, (260,290), 0)
cloth6 = Text("cloth", 12, (330,330), 0)
cloth7 = Text("cloth", 12, (360,250), 0)
cloth8 = Text("cloth", 12, (400,290), 0)
cloth9 = Text("cloth", 12, (480,350), 0)
sock1 = Text("sock", 12, (350,350), 0)
sock2 = Text("sock", 12, (340,280), 0)
sock3 = Text("sock", 12, (130,350), 0)
sock4 = Text("sock", 12, (380,300), 0)
sock5 = Text("sock", 12, (710,240), 0)
sock6 = Text("sock", 12, (620,320), 0)
sock7 = Text("sock", 12, (580,280), 0)
left1 = Text("left", 12, (480,240), 0)
left2 = Text("left", 12, (250,350), 0)
left3 = Text("left", 12, (500,290), 0)
left4 = Text("left", 12, (760,330), 0)
right1 = Text("right", 12, (180,290), 0)
right2 = Text("right", 12, (660,355), 0)
right3 = Text("right", 12, (630,280), 0)
right4 = Text("right", 12, (750,280), 0)
shoe11 = Text("shoe", 12, (480,250), 0)
shoe21 = Text("shoe", 12, (250,360), 0)
shoe31 = Text("shoe", 12, (500,300), 0)
shoe41 = Text("shoe", 12, (760,340), 0)
shoe12 = Text("shoe", 12, (180,300), 0)
shoe22 = Text("shoe", 12, (660,365), 0)
shoe32 = Text("shoe", 12, (630,290), 0)
shoe42 = Text("shoe", 12, (750,290), 0)



actionRemain = 3
choice0 = Text(f'Action: {objectCharacter.Ben.actionPoint} / 4', 18, (930,100), 0)
choice1 = Clickable("rest", 24, (950,150), 0)
choice2 = Clickable("excerise", 24, (950,180), 0)
choice3 = Clickable("zoom", 24, (950,210), 0)
choice4 = Clickable("study", 24, (950,240), 0)




frames = [firstLine, secondLine, thirdLine, fourthLine, 
        fifthLine, sixthLine]

lines = [Line1, Line2, Line3, Line4, Line5, Line6, Line7, Line8, Line9, Line10, 
        Line11, Line12, Line13, Line14, Line15, Line16, Line17, Line18, Line19,
        Line20, Line21, Line22, Line23]

rects = [rect1, rect2, rect3, rect4, rect5]

texts = [dresserOne, deskOne, b1, e1, d1, dresserTwo, deskTwo, b2, e2, d2,
        roommate, closetc1, closetl1, 
        closeto1, closets1, closete1, closett1, closetc2, closetl2, closeto2,
        closets2, closete2, closett2, heater1, heater2, chair1, chair2, 
        windoww11, windowi1, windown1, windowd1, windowo1, windoww12,
        windoww21, windowi2, windown2, windowd2, windowo2, windoww22,
        orange1, cloth1, cloth2, cloth3, cloth4, cloth5, cloth6, cloth7,
        cloth8, cloth9, sock1, sock2, sock3, sock4, sock5, sock6, sock7,
        left1, left2, left3, left4, right1, right2, right3, right4,
        shoe11, shoe21, shoe31, shoe41,shoe12, shoe22, shoe32, shoe42]

things = [orange1, cloth1, cloth2, cloth3, cloth4, cloth5, cloth6, cloth7,
        cloth8, cloth9, sock1, sock2, sock3, sock4, sock5, sock6, sock7,
        left1, left2, left3, left4, right1, right2, right3, right4,
        shoe11, shoe21, shoe31, shoe41,shoe12, shoe22, shoe32, shoe42, 
        dresserOne, deskOne, b1, e1, d1, dresserTwo, deskTwo, b2, e2, d2,
        roommate]

clickables = [doord, dooro1, dooro2, doorr, heater1, heater2]

choices = [choice1, choice2, choice3, choice4]

characters = [you]



def display(time):
    clock = pygame.time.Clock()
    clock.tick(200)
    pygame.event.pump()
    screen.fill((255, 255, 255))
    g = DijkGrid(90, 38)
    g.walls = getObstacles(things)
    #drawGrid()
    #g.draw()
    pathDiction = {}

    if len(objectCharacter.Ben.pathMap) > 0:
    #print(you.pos)
        nextPos = (objectCharacter.Ben.pathMap[0][0] * 10, 
                    objectCharacter.Ben.pathMap[0][1] * 10)
        objectCharacter.Ben.pathMap.pop(0)
        you.set_target(nextPos)
        vecYouPos = (you.pos[0]//10, you.pos[1]//10)
        you.update()
        
#Draw top hour day week
    day = Text(time[1], 33, (85,30), 0)
    week = Text(time[2], 33, (195,10), 0)
    hour = Text(time[0], 33, (335,40), 0)
    hour.draw()
    day.draw()
    week.draw()

    action = Text(f'Action: {objectCharacter.Ben.actionPoint} / 4', 18, (930,100), 0)
    action.draw()

    health = Text(f'Health: {str(objectCharacter.Ben.health)}', 24, (930,280), 0)
    sanity = Text(f'Sanity: {str(objectCharacter.Ben.sanity)}', 24, (930,310), 0)
    knowledge = Text(f'Knowledge: {str(objectCharacter.Ben.knowledge)}', 24, (930,340), 0)
    health.draw()
    sanity.draw()
    knowledge.draw()


#Original Frame
    for line in lines:
        line.draw()
    
    for rect in rects:
        rect.draw()
        
#Game Frames
    objectText.textBox.draw()

#texts
    for text in texts:
        text.draw()

    for chara in characters:
        chara.draw()
        chara.update()
        #pygame.draw.line(screen, (105, 105, 105), chara.pos, 
        #chara.endPoint, 1)

    #Interactiables
    for click in clickables:
        if click.rect.collidepoint(pygame.mouse.get_pos()):
            click.hovered = True
        else:
            click.hovered = False
        
        click.draw()

    
    for choice in choices:
        if choice.rect.collidepoint(pygame.mouse.get_pos()):
            choice.hovered = True
        else:
            choice.hovered = False
        
        choice.draw()

#Keys and sticks
    keys = pygame.key.get_pressed()

    if keys[pygame.K_SPACE]:
        objectCharacter.Ben.actionPoint = 4
        print("here it goes")
        return 42


    for event in pygame.event.get():

        if event.type == pygame.QUIT:
            run = False
            pygame.quit()

        if event.type == pygame.MOUSEBUTTONUP:
            cX, cY = pygame.mouse.get_pos()
            vecPos = vec(pygame.mouse.get_pos()) // TILESIZE
            if ((cX >= 80) and (cX <= 900) and (cY >=230) and (cY <=380)):
                if vecPos not in g.walls:
                    pathDiction = aStar(g, vecPos, 
                            vec(you.pos[0]//10, you.pos[1]//10))

                    objectCharacter.Ben.pathMap = findRoute(pathDiction, 
                                                    (you.pos[0]//10, you.pos[1]//10),
                                                        intVec(vecPos))


            for click in clickables:
                if click.rect.collidepoint(pygame.mouse.get_pos()):
                    if click == doord or click == dooro1 or  \
                        click == dooro2 or  click == doorr:
                        pass



            for choice in choices:
                if choice.rect.collidepoint(pygame.mouse.get_pos()):
                    if objectCharacter.Ben.actionPoint > 0:
                        if choice == choice1:
                            objectCharacter.Ben.actionPoint -= 1
                            print("worked")
                            objectCharacter.Ben.health += 3
                            print(objectCharacter.Ben.health)

                            quotes1 = {
                                "1 sheep, 2 sheep, 3 sheep......":(8, 5, -7),
                                "Just what you need.":(7, 2, -5),
                                "'Good night', said your roommate.":(5, 8, -7),
                            }
                            tempResponse = random.choice(list(quotes1.keys()))
                            objectCharacter.Ben.health += quotes1[tempResponse][0]
                            objectCharacter.Ben.sanity += quotes1[tempResponse][1]
                            objectCharacter.Ben.knowledge += quotes1[tempResponse][2]
                            objectText.textBox.bundle(tempResponse, objectCharacter.Ben.sanity)

                        elif choice == choice2:
                            objectCharacter.Ben.actionPoint -= 1
                            objectCharacter.Ben.health += 5
                            objectCharacter.Ben.sanity -= 3

                            quotes2 = {
                                "This is the time where you'd wish you know how to dance.":(6, 3, -1),
                                "Although excerise is good, there seems to be better places for you to work out. Oh wait nvm.":(2, 5, -1),
                                "Walked from one corner of the room to another, you felt you've made some progress.":(5, 1, -1)
                            }

                            tempResponse = random.choice(list(quotes2.keys()))
                            objectCharacter.Ben.health += quotes2[tempResponse][0]
                            objectCharacter.Ben.sanity += quotes2[tempResponse][1]
                            objectCharacter.Ben.knowledge += quotes2[tempResponse][2]
                            objectText.textBox.bundle(tempResponse, 99)

                        elif choice == choice3:
                            objectCharacter.Ben.actionPoint -= 1
                            objectCharacter.Ben.health += 1
                            objectCharacter.Ben.sanity += 2

                            quotes3 = {
                                "You opened Zoom.":(0, 0, 0),
                            }
                            tempResponse = random.choice(list(quotes3.keys()))
                            objectCharacter.Ben.health += quotes3[tempResponse][0]
                            objectCharacter.Ben.sanity += quotes3[tempResponse][1]
                            objectCharacter.Ben.knowledge += quotes3[tempResponse][2]
                            objectText.textBox.bundle(tempResponse, 99)

                            while True:
                                time = (objectDate.current.hourSymbol[objectDate.current.hour], 
                                    f'Day {objectDate.current.day}', 
                                    f'Week {objectDate.current.week}')

                                slideZoom.display(time)

                                if slideZoom.display(time) == 42:
                                    while True:
                                        return 42

                        elif choice == choice4:
                            objectCharacter.Ben.knowledge += 4
                            objectCharacter.Ben.sanity -= 4
                            objectCharacter.Ben.actionPoint -= 1

                            quotes4 = {
                                "Studying near your bed perhaps isn't the best idea....":(-2, -2, 2),
                                "You tried your best to concentrate, despite the envioriment around you.":(-3, -4, 5),
                            }
                            tempResponse = random.choice(list(quotes4.keys()))
                            objectCharacter.Ben.health += quotes4[tempResponse][0]
                            objectCharacter.Ben.sanity += quotes4[tempResponse][1]
                            objectCharacter.Ben.knowledge += quotes4[tempResponse][2]
                            objectText.textBox.bundle(tempResponse, objectCharacter.Ben.sanity)
                else:
                    print("???")

    pygame.display.update()

                        

                        


