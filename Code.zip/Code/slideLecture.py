
import objectDate
import objectCharacter
import objectText
import slideOHQ

import random
import pygame
import heapq

from os import path
from collections import deque

vec = pygame.math.Vector2

pygame.init()
screen = pygame.display.set_mode((1280, 720))
pygame.display.set_caption("blank")

class Line(object):
    grey = (105, 105, 105)
    white = (255, 255, 255)
    def __init__(self, canvas, color, sp, ep, width):
        self.canvas = canvas
        self.color = color
        self.sp = sp
        self.ep = ep
        self.width = width
    
    def draw(self):
        pygame.draw.line(self.canvas, self.color, self.sp, self.ep,
                            self.width)

class Rect(object):
    grey = (105, 105, 105)
    white = (255, 255, 255)
    def __init__(self, canvas, color, tlsize):
        self.canvas = canvas
        self.color = color
        self.tlsize = tlsize
    
    def draw(self):
        pygame.draw.rect(self.canvas, self.color, self.tlsize)

#OHQ
class Clickable(object):
    hovered = False

    def __init__(self, text, size, pos, tilt):
        self.text = text
        self.pos = pos
        self.size = size
        self.tilt = tilt
        self.clicked = False
        self.set_rect()
        self.draw()

    def set_rend(self):
        font = pygame.font.SysFont('Times New Roman', self.size)
        self.rend = font.render(self.text, True, self.getcolor())
        self.rend = pygame.transform.rotate(self.rend, self.tilt)
        
    def getcolor(self):
        if self.hovered:
            return (0, 0, 0)
        else:
            return (105, 105, 105)
        
    def set_rect(self):
        self.set_rend()
        self.rect = self.rend.get_rect()
        self.rect.topleft = (self.pos)

    def draw(self):
        self.set_rend()
        screen.blit(self.rend, self.rect) #The text    


class Text(object):
    grey = (105, 105, 105)
    white = (255, 255, 255)

    def __init__(self, text, size, pos, tilt):
        self.text = text
        self.pos = pos
        self.size = size
        self.tilt = tilt
    
    def draw(self):
        font = pygame.font.SysFont('Times New Roman', self.size)
        rend = font.render(self.text, True, self.grey)
        rend = pygame.transform.rotate(rend, self.tilt)
        screen.blit(rend, (self.pos))


class Character(object):

    def __init__(self, text, size, pos, speed):
        self.text = text
        self.size = size
        self.pos = pos
        self.speed = speed
        self.set_rect()
        self.endPoint = (0,0)
        self.pos = pygame.Vector2(self.pos)
        self.set_target(self.pos)

    def set_target(self, pos):
        self.target = pygame.Vector2(pos)
        self.endPoint = pos

    def set_rend(self):
        font = pygame.font.SysFont('Times New Roman', self.size)
        self.rend = font.render(self.text, True, (105, 105, 105))

    def set_rect(self):
        self.set_rend()
        self.rect = self.rend.get_rect()
        self.box = (self.pos[0], self.pos[1], self.rect[2], self.rect[3])
        self.rect.topleft = self.pos
    
    def draw(self):
        font = pygame.font.SysFont('Times New Roman', self.size)
        rend = font.render(self.text, True, (105, 105, 105))
        screen.blit(rend, self.pos)

    #Concept(normalize_ip) taken from https://stackoverflow.com/questions/16288905/make-a-sprite-move-to-the-mouse-click-position-step-by-step
    def update(self):
        move = self.target - self.pos
        moveLength = move.length()

        if moveLength < self.speed:
            self.pos = self.target

        elif moveLength != 0:
            move.normalize_ip()
            move = move * self.speed
            self.pos += move

        self.box = (self.pos[0], self.pos[1], self.rect[2], self.rect[3])

    
class StatCheck(object):
    def __init__(self, stat):
        self.stat = stat
        self.targetPos = (0, 0)

chara1Stat = StatCheck("still")
chara2Stat = StatCheck("still")
tobyStat = StatCheck("still")

class Counter(object):
    def __init__(self, num):
        self.counter = num

response1 = Counter(0)
response2 = Counter(0)


#From https://www.youtube.com/watch?v=fa1NSUBqiJc 
class Grid(object):
    def __init__(self, width, height):
        self.width = width
        self.height = height
        self.walls = [(10, 7)]
        #self.connections = [vec(1, 0), vec(-1, 0), vec(0, 1), vec(0, -1), 
                            #vec(-1, 1), vec(-1, -1), vec(1, 1), vec(1, -1)]
        self.connections = [vec(1, 0), vec(-1, 0), vec(0, 1), vec(0, -1)]

    def isInBound(self, node):
        if node.x >= 0 and node.x < self.width:
            if node.y >= 0 and node.y < self.height:
                return True
        return False

    def isPassable(self, node):
        if node in self.walls:
            return False
        return True

    def getNeighbors(self, node):
        counter = 0
        self.neighbors = []
        for direction in self.connections:
            counter += 1
            temp = node + direction
            #Didn't implement no perference path
            if self.isInBound(temp) == True:
                if self.isPassable(temp) == True:
                    self.neighbors.append(temp)
        return self.neighbors

    def draw(self):
        for wall in self.walls:
            rect = pygame.Rect((wall[0])*TILESIZE, (wall[1])*TILESIZE,
                                TILESIZE, TILESIZE)
            pygame.draw.rect(screen, (105, 105, 105), rect)

#From https://www.youtube.com/watch?v=fa1NSUBqiJc
class DijkGrid(Grid):
    def __init__(self, width, height):
        super().__init__(width, height)
        self.weights = {}
    
    def cost(self, fromNode, toNode):
        checker = (abs(fromNode[0] - toNode[0]) - \
                    abs(fromNode[1] - toNode[1])) ** 0.5
        if checker == 1:
            return self.weights.get(toNode, 0) + 10
        else:
            return self.weights.get(toNode, 0) + 14

#From https://www.youtube.com/watch?v=fa1NSUBqiJc
class PriorityQueue(object):
    def __init__(self):
        self.nodes = []

    def put(self, node, cost):
        heapq.heappush(self.nodes, (cost, node))

    def get(self):
        return heapq.heappop(self.nodes)[1]

    def empty(self):
        checker = len(self.nodes)
        if checker == 0:
            return True
        else:
            return False

TILESIZE = 10
GRIDWIDTH = 90 #52
GRIDHEIGHT = 38 #15
WIDTH = TILESIZE * GRIDWIDTH
HEIGHT = TILESIZE * GRIDHEIGHT



def round(n):
    last = n % 10
    if last == 0:
        n = 10
    elif last <= 3:
        n = (n//10) * 10
    elif last > 3:
        n = (n//10) * 10 + 10
    return n

#From https://www.youtube.com/watch?v=fa1NSUBqiJc
def drawGrid():
    for x in range(0, WIDTH+1, TILESIZE):
        pygame.draw.line(screen, (105,105,105), (x, 0), (x, HEIGHT))
    for y in range(0, HEIGHT+1, TILESIZE):
        pygame.draw.line(screen, (105,105,105), (0, y), (WIDTH, y))

def getObstacles(things):
    obstacles = []
    for text in things:
        coordinateTop = (text.pos[0]//10, text.pos[1]//10)
        obstacles.append(coordinateTop)

        restX, restY = (round(text.box[2]) //10, round(text.box[3]) //10)
        for i in range (0, restX ):
            for j in range(0, restY):
                coordinateTemp = (coordinateTop[0] + i, coordinateTop[1] + j)
                obstacles.append(coordinateTemp)

    for stuff in obstacles:
        g.weights[stuff] = 20

    return obstacles

def intVec(vector):
    return (int(vector[0]), int(vector[1]))

#Concept (deque) from: https://www.youtube.com/watch?v=hettiSrJjM4
def ruleOfThumb(node1, node2):
    #mahattan distance
    distance = (abs(node1[0] - node2[0]) + \
                    abs(node1[1] - node2[1]))

    value = 10 * distance
    return value

#From https://www.youtube.com/watch?v=fa1NSUBqiJc
def aStar(graph, start, end):
    frontier = PriorityQueue()
    frontier.put(intVec(start), 0)
    path = {}
    cost = {}
    path[intVec(start)] = None
    cost[intVec(start)] = 0

    while frontier.empty() == False:
        current = frontier.get()
        if current == end:
            break
        for next in graph.getNeighbors(vec(current)):
            next = intVec(next)
            nextCost = cost[current] + graph.cost(current, next)
            if next not in cost or nextCost < cost[next]:
                cost[next] = nextCost
                priority = nextCost + ruleOfThumb(end, vec(next))
                frontier.put(next, priority)
                path[next] = vec(current) - vec(next)
    
    return path

def findRoute(diction, playerInital, gridMousePos):
    playerInital = intVec(playerInital)
    pathMap = []
    while playerInital != (gridMousePos): #should be mouse position
        if playerInital in diction:
            tempDirect = diction[playerInital]
            tempDirect = intVec(tempDirect)

            tempPos = (playerInital[0] + tempDirect[0],
                        playerInital[1] + tempDirect[1])

            pathMap.append(tempPos)

            playerInital = tempPos

    print(pathMap)
    return pathMap


g= DijkGrid(90, 38)
path = aStar(g, vec(28,28), vec(70,32))

Line1 = Line(screen, (105,105,105), (80,80), (900,80), 4)
Line2 = Line(screen, (105,105,105), (80,80), (80,380), 4)
Line3 = Line(screen, (105,105,105), (80,380), (900,380), 4)
Line4 = Line(screen, (105,105,105), (900,80), (900,380), 4)

Line5 = Line(screen, (105,105,105), (920,80), (1080,80), 4)
Line6 = Line(screen, (105,105,105), (920,80), (920,380), 4)
Line7 = Line(screen, (105,105,105), (920,380), (1080,380), 4)
Line8 = Line(screen, (105,105,105), (1080,80), (1080,380), 4)

Line9 = Line(screen, (105,105,105), (80,400), (1080,400), 4)
Line10 = Line(screen, (105,105,105), (80,400), (80,680), 4)
Line11 = Line(screen, (105,105,105), (80,680), (1080,680), 4)
Line12 = Line(screen, (105,105,105), (1080,400), (1080,680), 4)

Line13 = Line(screen, (105,105,105), (1100,80), (1170,80), 4)
Line14 = Line(screen, (105,105,105), (1100,680), (1170,680), 4)
Line15 = Line(screen, (105,105,105), (1100,80), (1100,680), 4)
Line16 = Line(screen, (105,105,105), (1170,80), (1170,680), 4)

#ScrollIndicator
Line17 = Line(screen, (105,105,105), (1055,420), (1055,660), 4) #Black 240
Line18 = Line(screen, (255,255,255), (1055,440), (1055,490), 4) #White 50

#itemBlock
rect1 = Rect(screen, (105,105,105), (1113,120,45,45)) #Item bar 1-5
rect2 = Rect(screen, (105,105,105), (1113,240,45,45))
rect3 = Rect(screen, (105,105,105), (1113,360,45,45))
rect4 = Rect(screen, (105,105,105), (1113,480,45,45))
rect5 = Rect(screen, (105,105,105), (1113,600,45,45))


#Game frame
day = Text("Day 2", 33, (85,30), 0)
week = Text("Week 3", 33, (195,10), 0)
time = Text("Noon", 33, (335,40), 0)

#How to smartly break lines
firstLine = Text("...Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod",
                        30, (100,420), 0)
secondLine = Text("tempor incididunt ut labore et dolore magna aliqua.",
                         30, (110,450), 0)
thirdLine = Text("...Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu",
                         30,(100,500), 0)
fourthLine = Text("fugiat nulla pariatur.",
                         30,(110,530), 0)
fifthLine = Text("...Etiam erat velit scelerisque in. Metus dictum at tempor commodo ullamco",
                         30,(100,580), 0)
sixthLine = Text("met nisl purus consequat id porta nibh in mollis nunc sed id semper.",
                         30,(110,610), 0)
#Lecture Outline
Line19 = Line(screen, (105,105,105), (230,230), (746,230), 2)
Line20 = Line(screen, (105,105,105), (80,380), (230,230), 2)
Line21 = Line(screen, (105,105,105), (900,380), (746,230), 2)
Line22 = Line(screen, (105,105,105), (230,80), (230,230), 2)
Line23 = Line(screen, (105,105,105), (746,80), (746,230), 2)

Line24 = Line(screen, (105,105,105), (430,380), (480,270), 2) #inner outline
Line25 = Line(screen, (105,105,105), (570,380), (520,270), 2)

Line26 = Line(screen, (105,105,105), (640,80), (640,200), 1) #Screen
Line27 = Line(screen, (105,105,105), (340,80), (340,200), 1)
Line28 = Line(screen, (105,105,105), (340,200), (640,200), 1)
Line29 = Line(screen, (105,105,105), (340,80), (640,80), 1)



#Lecture things
you = Character("You", 12, (700,315), 3)

text1 = Text("podium", 14, (580,240), 0)


click1 = Clickable("d", 12, (700,190), 0)
click2 = Clickable("o", 12, (700,200), 0)
click3 = Clickable("o", 12, (700,210), 0)
click4 = Clickable("r", 12, (700,220), 0)
click5 = Clickable("d", 12, (690,190), 0)
click6 = Clickable("o", 12, (690,200), 0)
click7 = Clickable("o", 12, (690,210), 0)
click8 = Clickable("r", 12, (690,220), 0)
click9 = Clickable("d", 12, (290,190), 0)
click10 = Clickable("o", 12, (290,200), 0)
click11 = Clickable("o", 12, (290,210), 0)
click12 = Clickable("r", 12, (290,220), 0)
click13 = Clickable("d", 12, (280,190), 0)
click14 = Clickable("o", 12, (280,200), 0)
click15 = Clickable("o", 12, (280,210), 0)
click16 = Clickable("r", 12, (280,220), 0)

#first row students left
text2 = Text("s", 14, (200,270), 0)
text3 = Text("s", 14, (220,270), 0)
text4 = Text("s", 14, (240,270), 0)
text5 = Text("s", 14, (260,270), 0)
text6 = Text("s", 14, (280,270), 0)
text7 = Text("s", 14, (300,270), 0)
text8 = Text("s", 14, (320,270), 0)
text9 = Text("s", 14, (340,270), 0)
text10 = Text("s", 14, (360,270), 0)
text11 = Text("s", 14, (380,270), 0)
text12 = Text("s", 14, (400,270), 0)
text13 = Text("s", 14, (420,270), 0)
text14 = Text("s", 14, (440,270), 0)

#first row students right
text15 = Text("s", 14, (540,270), 0)
text16 = Text("s", 14, (560,270), 0)
text17 = Text("s", 14, (580,270), 0)
text18 = Text("s", 14, (600,270), 0)
text19 = Text("s", 14, (620,270), 0)
text20 = Text("s", 14, (640,270), 0)
text21 = Text("s", 14, (660,270), 0)
text22 = Text("s", 14, (680,270), 0)
text23 = Text("s", 14, (700,270), 0)
text24 = Text("s", 14, (720,270), 0)
text25 = Text("s", 14, (740,270), 0)
text26 = Text("s", 14, (760,270), 0)

#second row left
text27 = Text("s", 18, (180,290), 0)
text28 = Text("s", 18, (200,290), 0)
text29 = Text("s", 18, (220,290), 0)
text30 = Text("s", 18, (240,290), 0)
text31 = Text("s", 18, (260,290), 0)
text32 = Text("s", 18, (280,290), 0)
text33 = Text("s", 18, (300,290), 0)
text34 = Text("s", 18, (320,290), 0)
text35 = Text("s", 18, (340,290), 0)
text36 = Text("s", 18, (360,290), 0)
text37 = Text("s", 18, (380,290), 0)
text38 = Text("s", 18, (400,290), 0)
text39 = Text("s", 18, (420,290), 0)
text40 = Text("s", 18, (440,290), 0)

#second row right
text41 = Text("s", 18, (540,290), 0)
text42 = Text("s", 18, (560,290), 0)
text43 = Text("s", 18, (580,290), 0)
text44 = Text("s", 18, (600,290), 0)
text45 = Text("s", 18, (620,290), 0)
text46 = Text("s", 18, (640,290), 0)
text47 = Text("s", 18, (660,290), 0)
text48 = Text("s", 18, (680,290), 0)
text49 = Text("s", 18, (700,290), 0)
text50 = Text("s", 18, (720,290), 0)
text51 = Text("s", 18, (740,290), 0)
text52 = Text("s", 18, (760,290), 0)
text53 = Text("s", 18, (780,290), 0)


#third row left
text54 = Text("s", 24, (160,310), 0)
text55 = Text("s", 24, (190,310), 0)
text56 = Text("s", 24, (210,310), 0)
text57 = Text("s", 24, (240,310), 0)
text58 = Text("s", 24, (270,310), 0)
text59 = Text("s", 24, (300,310), 0)
text60 = Text("s", 24, (330,310), 0)
text61 = Text("s", 24, (360,310), 0)
text62 = Text("s", 24, (390,310), 0)
text92 = Text("TA", 16, (418,316), 0)

#third row right
text63 = Text("s", 24, (560,310), 0)
text64 = Text("s", 24, (590,310), 0)
text65 = Text("s", 24, (610,310), 0)
text66 = Text("s", 24, (640,310), 0)
text67 = Text("s", 24, (670,310), 0)
text68 = Text("s", 24, (740,310), 0)
text69 = Text("s", 24, (770,310), 0)
text70 = Text("s", 24, (800,310), 0)

#fourth row left
text71 = Text("s", 30, (130,335), 0)
text72 = Text("s", 30, (160,335), 0)
text73 = Text("s", 30, (190,335), 0)
text74 = Text("s", 30, (210,335), 0)
text75 = Text("s", 30, (240,335), 0)
text76 = Text("s", 30, (270,335), 0)
text77 = Text("s", 30, (300,335), 0)
text78 = Text("s", 30, (330,335), 0)
text79 = Text("s", 30, (360,335), 0)
text80 = Text("s", 30, (390,335), 0)
text81 = Text("s", 30, (420,335), 0)

#fourth row right
text82 = Text("s", 30, (570,335), 0)
text83 = Text("s", 30, (600,335), 0)
text84 = Text("s", 30, (630,335), 0)
text85 = Text("s", 30, (660,335), 0)
text86 = Text("s", 30, (690,335), 0)
text87 = Text("s", 30, (720,335), 0)
text88 = Text("s", 30, (750,335), 0)
text89 = Text("s", 30, (780,335), 0)
text90 = Text("s", 30, (810,335), 0)
text91 =  Text("s", 30, (840,335), 0)

#professors
click17 = Clickable("professor", 18, (380,235), 0)
click18 = Clickable("professor", 14, (690,250), 0)

chara1 = Character("professor", 18, (380,235), 1)
chara2 = Character("professor", 14, (690,250), 1)
toby = Character("Toby", 10, (700,315), 3)

text92 =  Text("???", 10, (840,335), 0)
text93 =  Text("???", 10, (840,335), 0)
text94 =  Text("???", 10, (840,335), 0)
text95 =  Text("???", 10, (840,335), 0)
text96 =  Text("???", 10, (840,335), 0)
text97 =  Text("???", 10, (840,335), 0)
text98 =  Text("???", 10, (840,335), 0)
text99 =  Text("???", 10, (840,335), 0)


choice1 = Clickable("learn", 24, (950,150), 0)
choice2 = Clickable("look around", 24, (950,180), 0)
choice3 = Clickable("sleep", 24, (950,210), 0)
choice4 = Clickable("Toby", 24, (950,240), 0)
#Emploee
#employee1 = Clickable("employee", 18, (565,265), -45)

choices = [choice1, choice2, choice3]

frames = [firstLine, secondLine, thirdLine, fourthLine, 
        fifthLine, sixthLine]
    
doors = [click1, click2, click3, click4, click5, click6, click7,
            click8, click9, click10, click11, click12, click13, click14,
            click15, click16]

texts = [text1, text2, text3, text4, text5, text6, text7, text8, text9, 
        text10, text11, text12, text13, text14, text15, text16, text17,
        text18, text19, text20, text21, text22, text23, text24, text25,
        text26, text27, text28, text29, text30, text31, text32, text33,
        text34, text35, text36, text37, text38, text39, text40, text41,
        text42, text43, text44, text45, text46, text47, text48, text49,
        text50, text51, text52, text53, text54, text55, text56, text57,
        text58, text59, text60, text61, text62, text63, text64, text65,
        text66, text67, text68, text69, text70, text71, text72, text73,
        text74, text75, text76, text77, text78, text79, text80, text81,
        text82,text83, text84, text85, text86, text87, text88, text89,
        text90, text91, text92]

clickables = [click1, click2, click3, click4, click5, click6, click7,
            click8, click9, click10, click11, click12, click13, click14,
            click15, click16, ]


Lines = [Line1, Line2, Line3, Line4, Line5, Line6, Line7, Line8, Line9, Line10, 
        Line11, Line12, Line13, Line14, Line15, Line16, Line17, Line18, Line19,
        Line20, Line21, Line22, Line23, Line24, Line25, Line26, Line27, Line28,
        Line29]

rects = [rect1, rect2, rect3, rect4, rect5]

characters = [you, chara1, chara2]

things = []

def display(time):
    clock = pygame.time.Clock()
    clock.tick(200)
    pygame.event.pump()
    screen.fill((255, 255, 255))
    g = DijkGrid(90, 38)
    g.walls = getObstacles(things)
    #drawGrid()
    #g.draw()
    pathDiction = {}

    if len(objectCharacter.Ben.pathMap) > 0:
    #print(you.pos)
        nextPos = (objectCharacter.Ben.pathMap[0][0] * 10, 
                    objectCharacter.Ben.pathMap[0][1] * 10)
        objectCharacter.Ben.pathMap.pop(0)
        you.set_target(nextPos)
        vecYouPos = (you.pos[0]//10, you.pos[1]//10)
        you.update()

#Draw top hour day week
    day = Text(time[1], 33, (85,30), 0)
    week = Text(time[2], 33, (195,10), 0)
    hour = Text(time[0], 33, (335,40), 0)
    hour.draw()
    day.draw()
    week.draw()

    objectText.textBox.draw()

    action = Text(f'Action: {objectCharacter.Ben.actionPoint} / 4', 18, (930,100), 0)
    action.draw()
    health = Text(f'Health: {str(objectCharacter.Ben.health)}', 24, (930,280), 0)
    sanity = Text(f'Sanity: {str(objectCharacter.Ben.sanity)}', 24, (930,310), 0)
    knowledge = Text(f'Knowledge: {str(objectCharacter.Ben.knowledge)}', 24, (930,340), 0)
    health.draw()
    sanity.draw()
    knowledge.draw()

    for choice in choices:
        if choice.rect.collidepoint(pygame.mouse.get_pos()):
            choice.hovered = True
        else:
            choice.hovered = False
        
        choice.draw()


    if "Toby" in objectCharacter.Ben.items:
        choice4.draw()
        if choice4.rect.collidepoint(pygame.mouse.get_pos()):
            choice4.hovered = True
        else:
            choice4.hovered = False

    if tobyStat.stat == "exist":
        toby.set_target((500,315))
        tobyStat.targetPos = (500,315)
        toby.update()
        toby.draw()
        if toby.pos == tobyStat.targetPos:
            chara1Stat.stat = "???"
            text92.text = ""
            tobyStat.stat = "exist2"

    if tobyStat.stat == "exist2":
        toby.set_target((500,245))
        tobyStat.targetPos = (500,245)
        toby.update()
        toby.draw()
        if toby.pos == tobyStat.targetPos:
            chara1Stat.stat = "still"
            tobyStat.stat = "exist3"

    if tobyStat.stat == "exist3":
        print("got here")
        toby.set_target(chara1.pos)
        tobyStat.targetPos = (chara1.pos)
        toby.update()
        toby.draw()

    chara1Pos = (random.randint(180, 650), random.randint(230, 235))
    if chara1Stat.stat == "still":
        chara1.set_target(chara1Pos)
        chara1Stat.stat = "move"
        chara1Stat.targetPos = chara1Pos
    chara1.update()
    if chara1Stat.stat == "move":
        if chara1.pos == chara1Stat.targetPos:
            chara1Stat.stat = "still"
        
        saying = ["Carpe Diem", "Carpe Diem", "Carpe Diem", "Carpe Diem"
                "Carpe Diem","Carpe Diem","Carpe Diem","Carpe Diem",
                "Carpe Diem","Carpe Diem","Carpe Diem","Carpe Diem","Carpe Diem"
                "Carpe Diem","Carpe Diem","Carpe Diem","Carpe Diem","Carpe Diem",
                "Carpe Diem","Carpe Diem","Carpe Diem","Carpe Diem","Carpe Diem",
                "Carpe Diem","Carpe Diem","Carpe Diem","Carpe Diem","Carpe Diem",
                "Carpe Diem","Carpe Diem","Carpe Diem","Carpe Diem","Carpe Diem"
                ,"Carpe Diem","Carpe Diem","Carpe Diem","Carpe Diem","Carpe Diem"]

        response = ["?", "zzZ", "...", "!", "wait...", "huh?", "ah-ha"]

        text92.text = random.choice(saying)
        text92.pos = (chara1.pos[0] + random.randint(-25, 55), 
                        chara1.pos[1] + random.randint(-20, -5))
        text92.draw()

        #left side
        response1.counter += 1
        if response1.counter >= 25:
            text93.text = random.choice(response)
            text93.pos = (random.randint(150, 400), 
                            random.randint(270, 320))

            text95.text = random.choice(response)
            text95.pos = (random.randint(550, 800), 
                            random.randint(270, 320))

            text96.text = random.choice(response)
            text96.pos = (random.randint(150, 400), 
                            random.randint(270, 320))
            response1.counter = 0

        text93.draw()
        text95.draw()
        text96.draw()
        #right side
        response2.counter += 1
        if response2.counter >= 30:
            text94.text = random.choice(response)
            text94.pos = (random.randint(550, 800), 
                            random.randint(270, 320))

            text97.text = random.choice(response)
            text97.pos = (random.randint(150, 400), 
                            random.randint(270, 320))

            text98.text = random.choice(response)
            text98.pos = (random.randint(550, 800), 
                            random.randint(270, 320))

            response2.counter = 0
        text94.draw()
        text97.draw()
        text98.draw()

#Original Frame
    for line in Lines:
        line.draw()
    
    for rect in rects:
        rect.draw()
        
#Game Frames

#texts
    for text in texts:
        text.draw()

    for click in clickables:
        if click.rect.collidepoint(pygame.mouse.get_pos()):
            click.hovered = True
        else:
            click.hovered = False
        click.draw()

    for chara in characters:
        chara.draw()
        chara.update()
        #pygame.draw.line(screen, (105, 105, 105), chara.pos, 
        #chara.endPoint, 1)
    
#Keys and sticks
    keys = pygame.key.get_pressed()

    if keys[pygame.K_SPACE]:
        objectCharacter.Ben.actionPoint = 4
        return 42

    for event in pygame.event.get():

        if event.type == pygame.QUIT:
            run = False
            pygame.quit()

        if event.type == pygame.MOUSEBUTTONUP:
            cX, cY = pygame.mouse.get_pos()
            vecPos = vec(pygame.mouse.get_pos()) // TILESIZE

            if choice4.rect.collidepoint(pygame.mouse.get_pos()):
                print("Got here")
                if "Toby" in objectCharacter.Ben.items:
                    objectCharacter.Ben.items.remove("Toby")
                    tobyStat.stat = "exist"


            if ((cX >= 80) and (cX <= 900) and (cY >=230) and (cY <=380)):
                if vecPos not in g.walls:
                    pathDiction = aStar(g, vecPos, 
                            vec(you.pos[0]//10, you.pos[1]//10))

                    objectCharacter.Ben.pathMap = findRoute(pathDiction, 
                                                    (you.pos[0]//10, you.pos[1]//10),
                                                        intVec(vecPos))

            for click in clickables:
                if click.rect.collidepoint(pygame.mouse.get_pos()):
                    if click in doors:
                        objectCharacter.Ben.actionPoint = 4
                        return 42

            for choice in choices:
                if choice.rect.collidepoint(pygame.mouse.get_pos()):
                    if objectCharacter.Ben.actionPoint > 0:
                        if choice == choice1:
                            objectCharacter.Ben.actionPoint -= 1
                            objectCharacter.Ben.health -= 1
                            objectCharacter.Ben.sanity -= 2
                            objectCharacter.Ben.knowledge += 5

                            quotes1 = {
                                "You understood every detail that the professor talked about":(-4, -4, 12),
                                "Your neighbor is browsing on youtube, you grabbed his iPad and threw it into the trashcan.":(-1, -2, 10),
                                "A funny joke but you are the only one laughing, the rest of the class is sound asleep, awkward.":(1, -7, 8),
                                "You felt good, thinking about transferring to CS next year?":(-1, -7, 6),
                                "Between taking notes and listening to lecture, you tried to find the best balance":(-1, 5, 1),
                                "Wait, is that python or magic?":(1, -4, 4),
                                "Oh please don’t put this on the test.":(-1, -10, 6),
                                "The professor is looking for volunteers, you put your head down.":(0, 3, 0),
                                "Is cussing allowed in CMU?":(-6, -1, 6),
                                "Name, color, attributes…. Got it": (-3, -3, 5),
                                "You tried to fight the hunger for food within you when the clock approaches closer to noon":(-3, -5, 2),
                                "You might need a cup of coffee":(-1, -7, 5),
                                "You felt the urge of closing your eyes, as much as you don’t want to admit, you are fighting a losing battle.":(-5, -5, -8),
                                "Your mind seems to wander off.": (1, 5, -6),
                                "Your head hurts, maybe you should consider have some sleep tonight...": (-6, -4, 6),
                                "Why is the clock so slow?":(-1, -1, -1)

                            }
                            tempResponse = random.choice(list(quotes1.keys()))
                            objectCharacter.Ben.health += quotes1[tempResponse][0]
                            objectCharacter.Ben.sanity += quotes1[tempResponse][1]
                            objectCharacter.Ben.knowledge += quotes1[tempResponse][2]
                            objectText.textBox.bundle(tempResponse, objectCharacter.Ben.sanity)

                        elif choice == choice2:
                            objectCharacter.Ben.actionPoint -= 1
                            objectCharacter.Ben.knowledge += 2

                            quotes2 = {
                                "Why are TA all wearing blue? Why not red?":(1, -3, 0),
                                "Should you go buy an iPad too?":(-4, 3, 4),
                                "You glanced around, half the class seems to fallen asleep": (-6, -3, 0),
                                "With this amount of blind stares, you start to wonder how many students are going to be on the Queue tonight, are TAs also sleep deprived?": (-1, -1, -3),
                                "Everyone else seem calm. Are you the only one that didn’t understand what the professor talks about?" : (-3, -7, 8)
                            }

                            tempResponse = random.choice(list(quotes2.keys()))
                            objectCharacter.Ben.health += quotes2[tempResponse][0]
                            objectCharacter.Ben.sanity += quotes2[tempResponse][1]
                            objectCharacter.Ben.knowledge += quotes2[tempResponse][2]
                            objectText.textBox.bundle(tempResponse, 99)

                        elif choice == choice3:
                            objectCharacter.Ben.actionPoint -= 1
                            objectCharacter.Ben.TAAtt -= 1
                            objectCharacter.Ben.sanity += 5

                            quotes3 = {
                                "You want to listen, but your mind seems to fades away into the darkness.":(5, 8, -10),
                                "1 sheep, 2 sheep, 3 sheep......":(7, 7, -10),
                                "Your eyelid just seems to be too heavy.":(1, 7, -5),
                                "You regret not waking up 10 mins early to buy that cup of coffee, now you have the rest of the time wondering what could’ve been.":(1, 4, -6),
                                "Carpe Diem, Carpe Diem, Carpe......":(1, 5, -8), 
                                "With the sweet voice from the professor, your mind slowly moves out from your body...": (5, 5, -14)
                            }
                            tempResponse = random.choice(list(quotes3.keys()))
                            objectCharacter.Ben.health += quotes3[tempResponse][0]
                            objectCharacter.Ben.sanity += quotes3[tempResponse][1]
                            objectCharacter.Ben.knowledge += quotes3[tempResponse][2]
                            objectText.textBox.bundle(tempResponse, 99)
                        




    pygame.display.update()



