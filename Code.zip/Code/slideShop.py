
import objectDate
import objectCharacter
import objectText
import slideOHQ

import random
import pygame
import heapq

from os import path
from collections import deque

vec = pygame.math.Vector2

pygame.init()
screen = pygame.display.set_mode((1280, 720))
pygame.display.set_caption("testInGameEntrollpy")

from os import path
from collections import deque

vec = pygame.math.Vector2


class Line(object):
    grey = (105, 105, 105)
    white = (255, 255, 255)
    def __init__(self, canvas, color, sp, ep, width):
        self.canvas = canvas
        self.color = color
        self.sp = sp
        self.ep = ep
        self.width = width
    
    def draw(self):
        pygame.draw.line(self.canvas, self.color, self.sp, self.ep,
                            self.width)


class Rect(object):
    grey = (105, 105, 105)
    white = (255, 255, 255)
    def __init__(self, canvas, color, tlsize):
        self.canvas = canvas
        self.color = color
        self.tlsize = tlsize
    
    def draw(self):
        pygame.draw.rect(self.canvas, self.color, self.tlsize)

#Entrollpy
class Character(object):

    def __init__(self, text, size, pos, speed):
        self.text = text
        self.size = size
        self.pos = pos
        self.speed = speed
        self.set_rect()
        self.endPoint = (0,0)
        self.pos = pygame.Vector2(self.pos)
        self.set_target(self.pos)

    def set_target(self, pos):
        self.target = pygame.Vector2(pos)
        self.endPoint = pos

    def set_rend(self):
        font = pygame.font.SysFont('Times New Roman', self.size)
        self.rend = font.render(self.text, True, (105, 105, 105))

    def set_rect(self):
        self.set_rend()
        self.rect = self.rend.get_rect()
        self.box = (self.pos[0], self.pos[1], self.rect[2], self.rect[3])
        self.rect.topleft = self.pos
    
    def draw(self):
        font = pygame.font.SysFont('Times New Roman', self.size)
        rend = font.render(self.text, True, (105, 105, 105))
        screen.blit(rend, self.pos)

    #Concept(normalize_ip) taken from https://stackoverflow.com/questions/16288905/make-a-sprite-move-to-the-mouse-click-position-step-by-step
    def update(self):
        move = self.target - self.pos
        moveLength = move.length()

        if moveLength < self.speed:
            self.pos = self.target

        elif moveLength != 0:
            move.normalize_ip()
            move = move * self.speed
            self.pos += move

        self.box = (self.pos[0], self.pos[1], self.rect[2], self.rect[3])
    

class Clickable(object):

    def __init__(self, text, size, pos, tilt):
        self.text = text
        self.pos = pos
        self.size = size
        self.tilt = tilt
        self.hovered = False
        self.clicked = False
        self.set_rect()
        self.draw()

    def draw(self):
        self.set_rend()
        screen.blit(self.rend, self.rect)
        
    def set_rend(self):
        font = pygame.font.SysFont('Times New Roman', self.size)
        self.rend = font.render(self.text, True, self.getcolor())
        self.rend = pygame.transform.rotate(self.rend, self.tilt)
        
    def getcolor(self):
        if self.hovered:
            return (0, 0, 0)
        else:
            return (105, 105, 105)
        
    def set_rect(self):
        self.set_rend()
        self.rect = self.rend.get_rect()
        self.box = (self.pos[0], self.pos[1], self.rect[2], self.rect[3])
        self.rect.topleft = self.pos


    #Concept(index into tuples & boxes) from https://stackoverflow.com/questions/35001207/how-to-detect-collision-between-objects-in-pygame
    def checkCollision(self, playerBox):
    #convert rectangles into x,y,w,h
        playerX = playerBox[0]
        playerY = playerBox[1]
        playerWidth = playerBox[2]
        playerHeight = playerBox[3]

        obstacleX = self.box[0]
        obstacleY = self.box[1]
        obstacleWidth = self.box[2]
        obstacleHeight = self.box[3]

        #get the right left top and bottom
        myRight = playerX + playerWidth
        myLeft = playerX
        myTop = playerY
        myBottom = playerY + playerHeight

        otherRight = obstacleX + obstacleWidth
        otherLeft = obstacleX
        otherTop = obstacleY
        otherBottom = obstacleY + obstacleHeight

        #now the collision code
        checker = True

        if ((myRight < otherLeft) or (myLeft > otherRight) \
            or (myBottom < otherTop) or (myTop > otherBottom)):
            checker = False

        return checker

class Item(Clickable):

    def __init__(self, text, size, pos, direct, descript):
        self.text = text
        self.pos = pos
        self.size = size
        self.direct = direct
        self.descript = descript
        self.hovered = False
        self.clicked = False
        self.set_rect()
        self.draw()

    def __repr__(self):
        return self.text

    def set_rect(self):
        self.set_rend()
        self.rect = self.rend.get_rect()
        self.box = (self.pos[0], self.pos[1], self.rect[2], self.rect[3])
        self.rect.topleft = self.pos

    def set_rend(self):
        font = pygame.font.SysFont('Times New Roman', self.size)
        self.rend = font.render(self.text, True, self.getcolor())

    def getIcon(self):
        icon = pygame.image.load(self.direct)
        icon = pygame.transform.scale(icon, (80, 80))
        return icon

    def draw(self):
        self.set_rend()
        screen.blit(self.rend, self.pos) #The text
        self.set_rect()

        if self.hovered == True:  #The icon
            icon = self.getIcon()
            screen.blit(icon, (960,150))

        if self.clicked == True:
            stayIcons.append(self)

        if self.hovered == True:
            self.clicked = False

    #Concept(index into tuples & boxes) from https://stackoverflow.com/questions/35001207/how-to-detect-collision-between-objects-in-pygame
    def checkCollision(self, playerBox):
    #convert rectangles into x,y,w,h
        playerX = playerBox[0]
        playerY = playerBox[1]
        playerWidth = playerBox[2]
        playerHeight = playerBox[3]

        obstacleX = self.box[0]
        obstacleY = self.box[1]
        obstacleWidth = self.box[2]
        obstacleHeight = self.box[3]

        #get the right left top and bottom
        myRight = playerX + playerWidth
        myLeft = playerX
        myTop = playerY
        myBottom = playerY + playerHeight

        otherRight = obstacleX + obstacleWidth
        otherLeft = obstacleX
        otherTop = obstacleY
        otherBottom = obstacleY + obstacleHeight

        #now the collision code
        checker = True

        if ((myRight < otherLeft) or (myLeft > otherRight) \
            or (myBottom < otherTop) or (myTop > otherBottom)):
            checker = False

        return checker


class Text(object):
    grey = (105, 105, 105)
    white = (255, 255, 255)

    def __init__(self, text, size, position, tilt):
        self.text = text
        self.pos = position
        self.size = size
        self.tilt = tilt
        self.set_rect()
    
    def set_rect(self):
        font = pygame.font.SysFont('Times New Roman', self.size)
        rend = font.render(self.text, True, self.grey)
        rend = pygame.transform.rotate(rend, self.tilt)
        self.rend = rend
        self.rect = self.rend.get_rect()
        self.box = (self.pos[0], self.pos[1], self.rect[2], self.rect[3])
        self.rect.topleft = self.pos

    def checkCollision(self, playerBox):
    #convert rectangles into x,y,w,h
        playerX = playerBox[0]
        playerY = playerBox[1]
        playerWidth = playerBox[2]
        playerHeight = playerBox[3]

        obstacleX = self.box[0]
        obstacleY = self.box[1]
        obstacleWidth = self.box[2]
        obstacleHeight = self.box[3]

        #get the right left top and bottom
        myRight = playerX + playerWidth
        myLeft = playerX
        myTop = playerY
        myBottom = playerY + playerHeight

        otherRight = obstacleX + obstacleWidth
        otherLeft = obstacleX
        otherTop = obstacleY
        otherBottom = obstacleY + obstacleHeight

        #now the collision code
        checker = True

        if ((myRight < otherLeft) or (myLeft > otherRight) \
            or (myBottom < otherTop) or (myTop > otherBottom)):
            checker = False

        return checker

    def draw(self):
        font = pygame.font.SysFont('Times New Roman', self.size)
        rend = font.render(self.text, True, self.grey)
        rend = pygame.transform.rotate(rend, self.tilt)
        screen.blit(rend, self.pos)

class RealItems(object):
    def __init__(self):
        self.items = []
    
    def shuffle(self, itemList):
        self.items = []
        for i in range(10):
            tempItem = random.choice(itemList)
            tempItem.pos = (random.randint(180, 700), random.randint(230, 360))
            if tempItem not in self.items:
                if tempItem not in objectCharacter.Ben.items:
                    self.items.append(tempItem)
        

realItems = RealItems()

class movementCheck(object):
    def __init__(self, stat):
        self.stat = stat
    
youMove = movementCheck("still") 


class ItemIdentify(object):
    def __init__(self):
        self.items = []

itemIdentify = ItemIdentify()

class ClickCounter(object):
    def __init__(self, num):
        self.counter = num

refreshCounter = ClickCounter(0)
purchaseCounter = ClickCounter(0)

#From https://www.youtube.com/watch?v=fa1NSUBqiJc
class Grid(object):
    def __init__(self, width, height):
        self.width = width
        self.height = height
        self.walls = [(10, 7)]
        #self.connections = [vec(1, 0), vec(-1, 0), vec(0, 1), vec(0, -1), 
                            #vec(-1, 1), vec(-1, -1), vec(1, 1), vec(1, -1)]
        self.connections = [vec(1, 0), vec(-1, 0), vec(0, 1), vec(0, -1)]

    def isInBound(self, node):
        if node.x >= 0 and node.x < self.width:
            if node.y >= 0 and node.y < self.height:
                return True
        return False

    def isPassable(self, node):
        if node in self.walls:
            return False
        return True

    def getNeighbors(self, node):
        counter = 0
        self.neighbors = []
        for direction in self.connections:
            counter += 1
            temp = node + direction
            #Didn't implement no perference path
            if self.isInBound(temp) == True:
                if self.isPassable(temp) == True:
                    self.neighbors.append(temp)
        return self.neighbors

    def draw(self):
        for wall in self.walls:
            rect = pygame.Rect((wall[0])*TILESIZE, (wall[1])*TILESIZE,
                                TILESIZE, TILESIZE)
            pygame.draw.rect(screen, (105, 105, 105), rect)

#From https://www.youtube.com/watch?v=fa1NSUBqiJc
class DijkGrid(Grid):
    def __init__(self, width, height):
        super().__init__(width, height)
        self.weights = {}
    
    def cost(self, fromNode, toNode):
        checker = (abs(fromNode[0] - toNode[0]) - \
                    abs(fromNode[1] - toNode[1])) ** 0.5
        if checker == 1:
            return self.weights.get(toNode, 0) + 10
        else:
            return self.weights.get(toNode, 0) + 14

#From https://www.youtube.com/watch?v=fa1NSUBqiJc
class PriorityQueue(object):
    def __init__(self):
        self.nodes = []

    def put(self, node, cost):
        heapq.heappush(self.nodes, (cost, node))

    def get(self):
        return heapq.heappop(self.nodes)[1]

    def empty(self):
        checker = len(self.nodes)
        if checker == 0:
            return True
        else:
            return False

TILESIZE = 10
GRIDWIDTH = 90 
GRIDHEIGHT = 38 
WIDTH = TILESIZE * GRIDWIDTH
HEIGHT = TILESIZE * GRIDHEIGHT



def round(n):
    last = n % 10
    if last == 0:
        n = 10
    elif last <= 3:
        n = (n//10) * 10
    elif last > 3:
        n = (n//10) * 10 + 10
    return n



def drawGrid():
    for x in range(0, WIDTH+1, TILESIZE):
        pygame.draw.line(screen, (105,105,105), (x+80, 80), (x, HEIGHT))
    for y in range(0, HEIGHT+1, TILESIZE):
        pygame.draw.line(screen, (105,105,105), (80, y+80), (WIDTH, y))

#Adapted from https://www.youtube.com/watch?v=fa1NSUBqiJc
def getObstacles(items):
    obstacles = []
    for item in items:
        coordinateTop = (item.pos[0]//10, item.pos[1]//10)
        obstacles.append(coordinateTop)

        restX, restY = (round(item.box[2]) //10, round(item.box[3]) //10)
        for i in range (0, restX ):
            for j in range(0, restY):
                coordinateTemp = (coordinateTop[0] + i, coordinateTop[1] + j)
                obstacles.append(coordinateTemp)

    for stuff in obstacles:
        g.weights[stuff] = 20


    return obstacles

def intVec(vector):
    return (int(vector[0]), int(vector[1]))
    
def ruleOfThumb(node1, node2):
    #mahattan distance
    distance = (abs(node1[0] - node2[0]) + \
                    abs(node1[1] - node2[1]))

    value = 10 * distance
    return value

#From https://www.youtube.com/watch?v=fa1NSUBqiJc
def aStar(graph, start, end):
    frontier = PriorityQueue()
    frontier.put(intVec(start), 0)
    path = {}
    cost = {}
    path[intVec(start)] = None
    cost[intVec(start)] = 0

    while frontier.empty() == False:
        current = frontier.get()
        if current == end:
            break
        for next in graph.getNeighbors(vec(current)):
            next = intVec(next)
            nextCost = cost[current] + graph.cost(current, next)
            if next not in cost or nextCost < cost[next]:
                cost[next] = nextCost
                priority = nextCost + ruleOfThumb(end, vec(next))
                frontier.put(next, priority)
                path[next] = vec(current) - vec(next)
    
    return path

def findRoute(diction, playerInital, gridMousePos):
    playerInital = intVec(playerInital)
    pathMap = []
    while playerInital != (gridMousePos): #should be mouse position
        if playerInital in diction:
            tempDirect = diction[playerInital]
            tempDirect = intVec(tempDirect)

            tempPos = (playerInital[0] + tempDirect[0],
                        playerInital[1] + tempDirect[1])

            pathMap.append(tempPos)

            playerInital = tempPos

    print(pathMap)
    return pathMap


g= DijkGrid(90, 38)
path = aStar(g, vec(28,28), vec(70,32))

Line1 = Line(screen, (105,105,105), (80,80), (900,80), 4)
Line2 = Line(screen, (105,105,105), (80,80), (80,380), 4)
Line3 = Line(screen, (105,105,105), (80,380), (900,380), 4)
Line4 = Line(screen, (105,105,105), (900,80), (900,380), 4)

Line5 = Line(screen, (105,105,105), (920,80), (1080,80), 4)
Line6 = Line(screen, (105,105,105), (920,80), (920,380), 4)
Line7 = Line(screen, (105,105,105), (920,380), (1080,380), 4)
Line8 = Line(screen, (105,105,105), (1080,80), (1080,380), 4)

Line9 = Line(screen, (105,105,105), (80,400), (1080,400), 4)
Line10 = Line(screen, (105,105,105), (80,400), (80,680), 4)
Line11 = Line(screen, (105,105,105), (80,680), (1080,680), 4)
Line12 = Line(screen, (105,105,105), (1080,400), (1080,680), 4)

Line13 = Line(screen, (105,105,105), (1100,80), (1170,80), 4)
Line14 = Line(screen, (105,105,105), (1100,680), (1170,680), 4)
Line15 = Line(screen, (105,105,105), (1100,80), (1100,680), 4)
Line16 = Line(screen, (105,105,105), (1170,80), (1170,680), 4)

#ScrollIndicator
Line17 = Line(screen, (105,105,105), (1055,420), (1055,660), 4) #Black 240
Line18 = Line(screen, (255,255,255), (1055,440), (1055,490), 4) #White 50

#itemBlock
rect1 = Rect(screen, (105,105,105), (1113,120,45,45)) #Item bar 1-5
rect2 = Rect(screen, (105,105,105), (1113,240,45,45))
rect3 = Rect(screen, (105,105,105), (1113,360,45,45))
rect4 = Rect(screen, (105,105,105), (1113,480,45,45))
rect5 = Rect(screen, (105,105,105), (1113,600,45,45))


#Game frame
day = Text("Day 2", 33, (85, 30), 0)
week = Text("Week 3", 33, (195, 10), 0)
time = Text("Noon", 33, (335, 40), 0)

#How to smartly break lines
firstLine = Text("...Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod",
                        30, (100,420), 0)
secondLine = Text("tempor incididunt ut labore et dolore magna aliqua.",
                         30, (110,450), 0)
thirdLine = Text("...Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu",
                         30,(100,500), 0)
fourthLine = Text("fugiat nulla pariatur.",
                         30,(110,530), 0)
fifthLine = Text("...Etiam erat velit scelerisque in. Metus dictum at tempor commodo ullamco",
                         30,(100,580), 0)
sixthLine = Text("met nisl purus consequat id porta nibh in mollis nunc sed id semper.",
                         30,(110, 610), 0)
#Entrollpy Outline
Line19 = Line(screen, (105,105,105), (230,230), (746,230), 2)
Line20 = Line(screen, (105,105,105), (80,380), (230,230), 2)
Line21 = Line(screen, (105,105,105), (900,380), (746,230), 2)
Line22 = Line(screen, (105,105,105), (230,80), (230,230), 2)
Line23 = Line(screen, (105,105,105), (746,80), (746,230), 2)
Line24 = Line(screen, (105,105,105), (706,230), (860,380), 2)


orange = Item("orange", 16, (380,320),'images/orange1.png', "'That's better.' 'Needed that.' 'Hits the spot.'")
lemon = Item("lemon", 16, (450,250),'images/lemon1.png', "Just a piece of lemon, nothing Unnatural about it.")
apple = Item("apple", 16, (680,290),'images/apple1.png', "An apple a day, keeps the doctors away.")

cupNoodle = Item("cup noodle", 16, (540,320),'images/cupNoodle1.png', "Comes with everything you need for a quick meal.")
pizza = Item("pizza", 16, (640,240),'images/pizza1.png', "Taste good, although not really helath...")
coffee = Item("coffee", 16, (290,270),'images/coffee1.png', "You can count the number of sleep you got yesterday in one hand.")
hotDog = Item("hot dog", 16, (360,280),'images/hotDog1.png', "Hot dog!")
hotCat = Item("hot cat", 16, (340,300),'images/hotDog1.png', "Like a hot dog, but with little cat ears on the end.")
gum = Item("gum", 16, (720,280),'images/gum1.png', "Gum.")
oreo = Item("oreo", 16, (430,260),'images/cookies1.png', "Some get one, some get two, and you got a whole box.")

tolietPaper1 = Item("toilet paper", 16, (520,250),'images/toiletPaper1.png', "You are not Wilson...")
tolietPaper2 = Item("toilet paper", 16, (520,260),'images/toiletPaper1.png', "You are not Wilson...")
marker = Item("marker", 16, (550,350),'images/marker1.png', "Marker")
iceCube = Item("ice cube", 16, (240,280),'images/iceCube1.png', "You wonder why it hasn't melted yet.")
glasses = Item("black frame glasses", 16, (160,340),'images/glasses1.png', "You sense a dangerous mogic attached to the glasses.")
flamingo = Item("flamingo", 16, (240,240),'images/flamingo1.png', "You sometimes can't stop wondering: What if animals were round?")
trashCan = Item("trash can", 16, (220,260),'images/trashCan1.png', "On the side a small note that says 'Projekt Trashcan'.")
pencil = Item("pencil", 16, (620,260),'images/pencil1.png', "You feel a sense of ease whenever you have this pencil with you.")

redCandy = Item("Vim Tutor", 16, (180,300),'images/placeH1.png', "You don't know what Vim is, but that's the purpose of a tutor, right? Learn it.")
blueCandy = Item("Calligri-Buddy", 16, (240,330),'images/placeH1.png', "A buddy that tracks your hand while you writes calligraphy? YES PLEASE.")
greenCandy = Item("Swimming Note", 16, (560,280),'images/placeH1.png', "???")
yellowCandy = Item("Expensive Portrait", 16, (460,310),'images/placeH1.png', "Today's newspaper titled 'museum lost 20 milllion worth of art', you recognized this portrait from that paper")
pinkCandy = Item("NNV", 16, (370,340),'images/placeH1.png', "Neural Network Visualizer")
whiteCandy = Item("K.I.M.C.H.I", 16, (350,240),'images/placeH1.png', "Presented by iMovie and KN Studios.")
purpleCandy = Item("Derma Diagnose", 16, (650,330),'images/placeH1.png', "Cool stuff.")
orangeCandy = Item("Bagpipe Hero", 16, (570,240),'images/placeH1.png', '"Who do you want be when you grow up son?" "A bagpipe hero!" "Good boy."')
blackCandy = Item("Keytar Hero", 16, (570,240),'images/placeH1.png', "You now lost the last reason to buy an Xbox.")

candy1 = Item("candy", 16, (180,310),'images/candy1.png', "A mysterious candy.")
candy2 = Item("unstable watch", 16, (240,340),'images/unstable1.png', "You swear you saw it ticks backwards")
candy3 = Item("yummy cake", 16, (560,290),'images/cake1.png', "Made with Cream cheese, Carrot, and a good heart")
candy4 = Item("bucket of lava", 16, (460,320),'images/bucket1.png', "You had a hard time figuring out how lava stayed in this white bucket.")
candy5 = Item("42", 16, (370,350),'images/421.png', "You just had a peek at the meaning of life")
candy6 = Item("werid statue", 16, (350,250),'images/statue1.png', "Statue of a boy with Bart Simpson on the left and Wall-E on the right")
candy7 = Item("PNC card", 16, (650,340),'images/bank1.png', "Never seen it outside of Pittsburgh")
candy8 = Item("nice cream", 16, (570,250),'images/niceCream1.png', '"A frozen treat that warms your heart!" said the nice cream guy.')

chicken = Item("chicken soup", 16, (570,250),'images/chicken1.png', 'The logo on the can reminds you of your faviorate professor.')

you = Character("You", 12, (700,320), 3)
sign = Text("Entrollpy+", 48, (390,105), 0)
slogan1 = Text("Buy high", 30, (340,165), 0)
slogan2 = Text("Sell low", 30, (540,165), 0)

windoww11 = Text("w", 28, (180,110), 0)
windowi1 = Text("i", 28, (183,130), 0)
windown1 = Text("n", 28, (180,150), 0)
windowd1 = Text("d", 28, (180,170), 0)
windowo1 = Text("o", 28, (180,190), 0)
windoww12 = Text("w", 28, (180,210), 0)

windoww21 = Text("w", 28, (110,160), 0)
windowi2 = Text("i", 28, (113,180), 0)
windown2 = Text("n", 28, (110,200), 0)
windowd2 = Text("d", 28, (110,220), 0)
windowo2 = Text("o", 28, (110,240), 0)
windoww22 = Text("w", 28, (110,260), 0)

doord1 = Clickable("d", 28, (780,130), 0)
dooro11 = Clickable("o", 28, (780,150), 0)
dooro12 = Clickable("o", 28, (780,170), 0)
doorr1 = Clickable("r", 28, (783,190), 0)

doord2 = Clickable("d", 28, (830,170), 0)
dooro21 = Clickable("o", 28, (830,190), 0)
dooro22 = Clickable("o", 28, (830,210), 0)
doorr2 = Clickable("r", 28, (833,230), 0)

yes = Clickable("O", 70, (1010,280), 0)
no = Clickable("X", 70, (940,280), 0)

employee1 = Clickable("employee", 18, (765,265), -45)

choice1 = Clickable("refresh", 24, (950,100), 0)

choices = [choice1]

frames = [firstLine, secondLine, thirdLine, fourthLine, 
        fifthLine, sixthLine]

texts = [sign, slogan1, slogan2, windoww11, windowi1, windown1, windowd1,
        windowo1, windoww12, windoww21, windowi2, windown2, windowd2, windowo2,
        windoww22]

interacts = [employee1, doord1, dooro11, dooro12, doorr1, doord2, dooro21, 
            dooro22, doorr2, yes, no]

doors = [doord1, dooro11, dooro12, doorr1, doord2, dooro21, 
            dooro22, doorr2]

things = [orange, lemon, cupNoodle, pizza, coffee, hotDog,
                hotCat, gum, oreo, tolietPaper1, tolietPaper2, marker,
                iceCube, marker, glasses, flamingo, trashCan, pencil,
                redCandy, blueCandy, greenCandy, yellowCandy, 
                pinkCandy, whiteCandy, purpleCandy, orangeCandy, blackCandy]

items = [orange, lemon, cupNoodle, pizza, coffee, hotDog,
                hotCat, gum, oreo, tolietPaper1, tolietPaper2, marker,
                iceCube, marker, glasses, flamingo, trashCan, pencil,
                redCandy, blueCandy, greenCandy, yellowCandy, 
                pinkCandy, whiteCandy, purpleCandy, orangeCandy,
                candy1, candy2, candy3, candy4, candy5, candy6,
                candy7, candy8, apple, blackCandy, chicken]

Lines = [Line1, Line2, Line3, Line4, Line5, Line6, Line7, Line8, Line9, Line10, 
        Line11, Line12, Line13, Line14, Line15, Line16, Line17, Line18, Line19,
        Line20, Line21, Line22, Line23, Line24]

rects = [rect1, rect2, rect3, rect4, rect5]

speaks = []

stayIcons = []

characters = [you]


#create a sql database, tranfer data in between data bases.

def display(time):
    clock = pygame.time.Clock()
    clock.tick(200)
    pygame.event.pump()
    screen.fill((255, 255, 255))
    g = DijkGrid(90, 38)
    g.walls = getObstacles(things)
    #drawGrid()
    #g.draw()
    pathDiction = {}

    if len(objectCharacter.Ben.pathMap) > 0:
    #print(you.pos)
        nextPos = (objectCharacter.Ben.pathMap[0][0] * 10, 
                    objectCharacter.Ben.pathMap[0][1] * 10)
        objectCharacter.Ben.pathMap.pop(0)
        you.set_target(nextPos)
        vecYouPos = (you.pos[0]//10, you.pos[1]//10)
        you.update()

    if len(objectCharacter.Ben.pathMap) <= 1:
        #print("here")
        youMove.stat = "still"
    
#Draw top hour day week
    day = Text(time[1], 33, (85,30), 0)
    week = Text(time[2], 33, (195,10), 0)
    hour = Text(time[0], 33, (335,40), 0)
    hour.draw()
    day.draw()
    week.draw()

#Original Frame

    for choice in choices:
        if choice.rect.collidepoint(pygame.mouse.get_pos()):
            choice.hovered = True
        else:
            choice.hovered = False
        
        choice.draw()

    for line in Lines:
        line.draw()
    
    for rect in rects:
        rect.draw()
        
#Game Frames
    objectText.textBox.draw()

#texts
    for text in texts:
        text.draw()

    for chara in characters:
        chara.draw()
        chara.update()
        #pygame.draw.line(screen, (105, 105, 105), chara.pos, 
        #chara.endPoint, 1)

#Interactiables
    for click in interacts:
        if click.rect.collidepoint(pygame.mouse.get_pos()):
            click.hovered = True
        else:
            click.hovered = False
        
        click.draw()

#Items
    for item in realItems.items:
        if item.rect.collidepoint(pygame.mouse.get_pos()):
            item.hovered = True
        else:
            item.hovered = False

        if item.checkCollision(you.box) == True:
            #print("COLLISION")

            if you.box[0] >= item.box[0]:
                you.pos[0] += 1
            elif you.box[0] < item.box[0]:
                you.pos[0] -= 1

            if you.box[1] >= item.box[1]:
                you.pos[1] += 1
            elif you.box[1] < item.box[1]:
                you.pos[1] -= 1

        item.draw()
    
#From Shop employee
    #for speak in speaks:
        #if len(speaks) > 1:
            #speaks = []
        #speak.draw()
    
#Display the current selection
    for ic in stayIcons:
        if len(stayIcons) > 1:
            stayIcons.pop(0)
        icon = ic.getIcon()
        screen.blit(icon, (960,150))

#Keys and sticks
    keys = pygame.key.get_pressed()

    if keys[pygame.K_SPACE]:
        refreshCounter.counter = 0
        purchaseCounter.counter = 0
        objectCharacter.Ben.actionPoint = 4
        return 42

    if keys[pygame.K_a]:
        drawGrid()
        g.draw()

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            run = False
            pygame.quit()

        if event.type == pygame.MOUSEBUTTONUP:
            cX, cY = pygame.mouse.get_pos()
            vecPos = vec(pygame.mouse.get_pos()) // TILESIZE

            for choice in choices:
                    if choice.rect.collidepoint(pygame.mouse.get_pos()):
                        if choice == choice1:
                            if refreshCounter.counter < 1:
                                realItems.shuffle(items)
                                refreshCounter.counter += 1
                            else:
                                objectText.textBox.bundle("You can only refresh once everytime you are at Entrollpy", 99)

        
            if ((cX >= 80) and (cX <= 900) and (cY >=230) and (cY <=380)):
                if youMove.stat == "still":
                    youMove.stat = "move"
                    if vecPos not in g.walls:
                        pathDiction = aStar(g, vecPos, 
                                vec(you.pos[0]//10, you.pos[1]//10))

                        objectCharacter.Ben.pathMap = findRoute(pathDiction, 
                                                        (you.pos[0]//10, you.pos[1]//10),
                                                            intVec(vecPos))


            for item in items:
                if item.rect.collidepoint(pygame.mouse.get_pos()):
                    item.clicked = True
                    itemIdentify.items.append(item)

                elif ((cX >= 1010) and (cX <= 1080) and \
                    (cY >= 280) and (cY <= 350)):
                    if purchaseCounter.counter <= 1:
                        purchaseCounter.counter += 1
                        if len(stayIcons) != 0:
                            description = itemIdentify.items[len(itemIdentify.items)-1].descript
                            objectText.textBox.bundle(description, 99)
                            name = stayIcons[0]
                            print(name)
                            index = realItems.items.index(name)
                            stayIcons.pop()
                            realItems.items.pop(index)
                            #print(name)
                            #print(isinstance(name, str))
                            objectCharacter.Ben.modify(objectCharacter.Ben.items, str(name))
                            print(objectCharacter.Ben.items)

                
                else:
                    if len(stayIcons) != 0:
                        stayIcons.pop()

            for click in doors:
                if click.rect.collidepoint(pygame.mouse.get_pos()):
                    refreshCounter.counter = 0
                    purchaseCounter.counter = 0
                    objectCharacter.Ben.actionPoint = 4
                    return 42

    pygame.display.update()