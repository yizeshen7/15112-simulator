
# from: https://www.cs.cmu.edu/~112/notes/notes-strings.html#basicFileIO
def readFile(path):
    with open(path, "rt") as f:
        return f.read()

def getFile():
    name = f'CC.csv'
    read = readFile(name)
    table = []
    for i in read.splitlines():
        table.append(i.split(","))
    
    #print(table)
    return table

def tableToDiction(table):
    table = table[1:]
    diction = {}
    for List in table:
        key = List[0] + List[1]
        diction[key] = []
        stats = (List[2], List[3], List[4])
        diction[key].append(stats)

        attributes = []
        for elem in List[5:]:
            if elem == "null":
                pass
            else:
                attributes.append(elem)

        diction[key].append(attributes)

    print(diction)
    return diction


table = getFile()
diction = tableToDiction(table)