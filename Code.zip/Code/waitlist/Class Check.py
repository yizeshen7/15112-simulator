
class Line(object):
    grey = (105, 105, 105)
    white = (255, 255, 255)

    def __init__(self, canvas, color, sp, ep, width):
        self.canvas = canvas # Screen
        self.color = color  # Color of the line
        self.sp = sp  # Starting point
        self.ep = ep  # Ending point
        self.width = width # Width of the line
    
    def draw(self):  # Just draw the function out
        pygame.draw.line(self.canvas, self.color, self.sp, self.ep,
                            self.width)


class Rect(object):
    grey = (105, 105, 105)
    white = (255, 255, 255)

    def __init__(self, canvas, color, tlsize):
        self.canvas = canvas # Screen
        self.color = color  # Color of the rect
        self.tlsize = tlsize  # tuple for top, left, height and width
    
    def draw(self):  # Just draw the function out
        pygame.draw.rect(self.canvas, self.color, self.tlsize)



class Text(object):
    grey = (105, 105, 105)
    white = (255, 255, 255)

    def __init__(self, text, size, position, tilt):
        self.text = text
        self.pos = position
        self.size = size
        self.tilt = tilt
        self.set_rect()
    
    def set_rect(self):
        font = pygame.font.SysFont('Times New Roman', self.size)
        rend = font.render(self.text, True, self.grey)
        rend = pygame.transform.rotate(rend, self.tilt)
        self.rend = rend
        self.rect = self.rend.get_rect()
        self.box = (self.pos[0], self.pos[1], self.rect[2], self.rect[3])
        self.rect.topleft = self.pos


    def draw(self):
        font = pygame.font.SysFont('Times New Roman', self.size)
        rend = font.render(self.text, True, self.grey)
        rend = pygame.transform.rotate(rend, self.tilt)
        screen.blit(rend, self.pos)


class Clickable(object):

    def __init__(self, text, size, pos, tilt):
        self.text = text
        self.pos = pos
        self.size = size
        self.tilt = tilt
        self.hovered = False
        self.clicked = False
        self.set_rect()
        self.draw()
        
    def set_rend(self):
        font = pygame.font.SysFont('Times New Roman', self.size)
        self.rend = font.render(self.text, True, self.getcolor())
        self.rend = pygame.transform.rotate(self.rend, self.tilt)
        
    def getcolor(self):
        if self.hovered:
            return (0, 0, 0)
        else:
            return (105, 105, 105)
        
    def set_rect(self):
        self.set_rend()
        self.rect = self.rend.get_rect()
        self.box = (self.pos[0], self.pos[1], self.rect[2], self.rect[3])
        self.rect.topleft = self.pos
    
    
    #Concept(index into tuples & boxes) from https://stackoverflow.com/questions/35001207/how-to-detect-collision-between-objects-in-pygame
    def checkCollision(self, playerBox):
    #convert rectangles into x,y,w,h
        playerX = playerBox[0]
        playerY = playerBox[1]
        playerWidth = playerBox[2]
        playerHeight = playerBox[3]

        obstacleX = self.box[0]
        obstacleY = self.box[1]
        obstacleWidth = self.box[2]
        obstacleHeight = self.box[3]

        myRight = playerX + playerWidth
        myLeft = playerX
        myTop = playerY
        myBottom = playerY + playerHeight

        otherRight = obstacleX + obstacleWidth
        otherLeft = obstacleX
        otherTop = obstacleY
        otherBottom = obstacleY + obstacleHeight

        checker = True
        if ((myRight < otherLeft) or (myLeft > otherRight) \
            or (myBottom < otherTop) or (myTop > otherBottom)):
            checker = False
        return checker

    def draw(self):
        self.set_rend()
        screen.blit(self.rend, self.rect)


class Icon(object):

    def __init__(self, direct, direct2, size, pos):
        self.direct = direct  # directory for grey icon
        self.direct2 = direct2  # directory for black icon
        self.pos = pos  # tuple of icon's position
        self.size = size  # tuple of the size of the icon 
        self.hovered = False  #check for mouse hover over the icon

    def getIcon(self, direct):
        icon = pygame.image.load(direct) #load from folde
        # Transform it into the right size
        icon = pygame.transform.scale(icon, (self.size, self.size))
        return icon

    def draw(self): #Draws it out
        if self.hovered == False:
            icon = self.getIcon(self.direct)
        elif self.hovered == True:
            icon = self.getIcon(self.direct2)
        screen.blit(icon, self.pos)


class Character(object):

    def __init__(self, text, size, pos, speed):
        self.text = text
        self.size = size
        self.pos = pos
        self.speed = speed
        self.set_rect()
        self.endPoint = (0,0)
        self.pos = pygame.Vector2(self.pos)
        self.set_target(self.pos)

    def set_target(self, pos):
        self.target = pygame.Vector2(pos)
        self.endPoint = pos

    def set_rend(self):
        font = pygame.font.SysFont('Times New Roman', self.size)
        self.rend = font.render(self.text, True, (105, 105, 105))

    def set_rect(self):
        self.set_rend()
        self.rect = self.rend.get_rect()
        self.box = (self.pos[0], self.pos[1], self.rect[2], self.rect[3])
        self.rect.topleft = self.pos
    
    def draw(self):
        font = pygame.font.SysFont('Times New Roman', self.size)
        rend = font.render(self.text, True, (105, 105, 105))
        screen.blit(rend, self.pos)

    #Concept(normalize_ip) taken from https://stackoverflow.com/questions/16288905/make-a-sprite-move-to-the-mouse-click-position-step-by-step
    def update(self):
        move = self.target - self.pos
        moveLength = move.length()

        if moveLength < self.speed:
            self.pos = self.target

        elif moveLength != 0:
            move.normalize_ip()
            move = move * self.speed
            self.pos += move

        self.box = (self.pos[0], self.pos[1], self.rect[2], self.rect[3])


'''
frames = [frame1, frame2, frame3]

lines = [Line1, Line2, Line3, Line4, Line5, Line6, Line7]

rects = [rect1, rect2, rect3, rect4, rect5]

texts = [text1, text2]

clickables = [click1, click2, click3, click4, click5, click6]

icons = [icon1, icon2, icon3, icon4, icon5, icon6, icon7]

characters = [chara1, chara2, chara3, chara4]
'''