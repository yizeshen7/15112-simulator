


import objectDate
import objectCharacter
import objectText
import slideOHQ


import random
import pygame
import heapq

from os import path
from collections import deque

vec = pygame.math.Vector2

pygame.init()
screen = pygame.display.set_mode((1280, 720))
pygame.display.set_caption("testInGameRecitation")

class Character(object):

    def __init__(self, text, size, pos, speed):
        self.text = text
        self.size = size
        self.pos = pos
        self.speed = speed
        self.set_rect()
        self.endPoint = (0,0)
        self.pos = pygame.Vector2(self.pos)
        self.set_target(self.pos)

    def set_target(self, pos):
        self.target = pygame.Vector2(pos)
        self.endPoint = pos

    def set_rend(self):
        font = pygame.font.SysFont('Times New Roman', self.size)
        self.rend = font.render(self.text, True, (105, 105, 105))

    def set_rect(self):
        self.set_rend()
        self.rect = self.rend.get_rect()
        self.box = (self.pos[0], self.pos[1], self.rect[2], self.rect[3])
        self.rect.topleft = self.pos
    
    def draw(self):
        font = pygame.font.SysFont('Times New Roman', self.size)
        rend = font.render(self.text, True, (105, 105, 105))
        screen.blit(rend, self.pos)

    #Concept(normalize_ip) taken from https://stackoverflow.com/questions/16288905/make-a-sprite-move-to-the-mouse-click-position-step-by-step
    def update(self):
        move = self.target - self.pos
        moveLength = move.length()

        if moveLength < self.speed:
            self.pos = self.target

        elif moveLength != 0:
            move.normalize_ip()
            move = move * self.speed
            self.pos += move

        self.box = (self.pos[0], self.pos[1], self.rect[2], self.rect[3])


class Line(object):
    grey = (105, 105, 105)
    white = (255, 255, 255)
    def __init__(self, canvas, color, sp, ep, width):
        self.canvas = canvas
        self.color = color
        self.sp = sp
        self.ep = ep
        self.width = width
    
    def draw(self):
        pygame.draw.line(self.canvas, self.color, self.sp, self.ep,
                            self.width)

class Rect(object):
    grey = (105, 105, 105)
    white = (255, 255, 255)
    def __init__(self, canvas, color, tlsize):
        self.canvas = canvas
        self.color = color
        self.tlsize = tlsize
    
    def draw(self):
        pygame.draw.rect(self.canvas, self.color, self.tlsize)

#OHQ
class Clickable(object):

    def __init__(self, text, size, pos, tilt):
        self.text = text
        self.pos = pos
        self.size = size
        self.tilt = tilt
        self.hovered = False
        self.clicked = False
        self.set_rect()
        self.draw()

    def draw(self):
        self.set_rend()
        screen.blit(self.rend, self.rect)
        
    def set_rend(self):
        font = pygame.font.SysFont('Times New Roman', self.size)
        self.rend = font.render(self.text, True, self.getcolor())
        self.rend = pygame.transform.rotate(self.rend, self.tilt)
        
    def getcolor(self):
        if self.hovered:
            return (0, 0, 0)
        else:
            return (105, 105, 105)
        
    def set_rect(self):
        self.set_rend()
        self.rect = self.rend.get_rect()
        self.box = (self.pos[0], self.pos[1], self.rect[2], self.rect[3])
        self.rect.topleft = self.pos


class Text(object):
    grey = (105, 105, 105)
    white = (255, 255, 255)

    def __init__(self, text, size, pos, tilt):
        self.text = text
        self.pos = pos
        self.size = size
        self.tilt = tilt
    
    def draw(self):
        font = pygame.font.SysFont('Times New Roman', self.size)
        rend = font.render(self.text, True, self.grey)
        rend = pygame.transform.rotate(rend, self.tilt)
        screen.blit(rend, (self.pos))

#From https://www.youtube.com/watch?v=fa1NSUBqiJc
class Grid(object):
    def __init__(self, width, height):
        self.width = width
        self.height = height
        self.walls = [(10, 7)]
        #self.connections = [vec(1, 0), vec(-1, 0), vec(0, 1), vec(0, -1), 
                            #vec(-1, 1), vec(-1, -1), vec(1, 1), vec(1, -1)]
        self.connections = [vec(1, 0), vec(-1, 0), vec(0, 1), vec(0, -1)]

    def isInBound(self, node):
        if node.x >= 0 and node.x < self.width:
            if node.y >= 0 and node.y < self.height:
                return True
        return False

    def isPassable(self, node):
        if node in self.walls:
            return False
        return True

    def getNeighbors(self, node):
        counter = 0
        self.neighbors = []
        for direction in self.connections:
            counter += 1
            temp = node + direction
            #Didn't implement no perference path
            if self.isInBound(temp) == True:
                if self.isPassable(temp) == True:
                    self.neighbors.append(temp)
        return self.neighbors

    def draw(self):
        for wall in self.walls:
            rect = pygame.Rect((wall[0])*TILESIZE, (wall[1])*TILESIZE,
                                TILESIZE, TILESIZE)
            pygame.draw.rect(screen, (105, 105, 105), rect)

#From https://www.youtube.com/watch?v=fa1NSUBqiJc
class DijkGrid(Grid):
    def __init__(self, width, height):
        super().__init__(width, height)
        self.weights = {}
    
    def cost(self, fromNode, toNode):
        checker = (abs(fromNode[0] - toNode[0]) - \
                    abs(fromNode[1] - toNode[1])) ** 0.5
        if checker == 1:
            return self.weights.get(toNode, 0) + 10
        else:
            return self.weights.get(toNode, 0) + 14

#From https://www.youtube.com/watch?v=fa1NSUBqiJc
class PriorityQueue(object):
    def __init__(self):
        self.nodes = []

    def put(self, node, cost):
        heapq.heappush(self.nodes, (cost, node))

    def get(self):
        return heapq.heappop(self.nodes)[1]

    def empty(self):
        checker = len(self.nodes)
        if checker == 0:
            return True
        else:
            return False

TILESIZE = 10
GRIDWIDTH = 90 #52
GRIDHEIGHT = 38 #15
WIDTH = TILESIZE * GRIDWIDTH
HEIGHT = TILESIZE * GRIDHEIGHT



def round(n):
    last = n % 10
    if last == 0:
        n = 10
    elif last <= 3:
        n = (n//10) * 10
    elif last > 3:
        n = (n//10) * 10 + 10
    return n

#From https://www.youtube.com/watch?v=fa1NSUBqiJc
def drawGrid():
    for x in range(0, WIDTH+1, TILESIZE):
        pygame.draw.line(screen, (105,105,105), (x, 0), (x, HEIGHT))
    for y in range(0, HEIGHT+1, TILESIZE):
        pygame.draw.line(screen, (105,105,105), (0, y), (WIDTH, y))

def getObstacles(things):
    obstacles = []
    for text in things:
        coordinateTop = (text.pos[0]//10, text.pos[1]//10)
        obstacles.append(coordinateTop)

        restX, restY = (round(text.box[2]) //10, round(text.box[3]) //10)
        for i in range (0, restX ):
            for j in range(0, restY):
                coordinateTemp = (coordinateTop[0] + i, coordinateTop[1] + j)
                obstacles.append(coordinateTemp)

    for stuff in obstacles:
        g.weights[stuff] = 20

    return obstacles

def intVec(vector):
    return (int(vector[0]), int(vector[1]))


#Concept (deque) from: https://www.youtube.com/watch?v=hettiSrJjM4
def ruleOfThumb(node1, node2):
    #mahattan distance
    distance = (abs(node1[0] - node2[0]) + \
                    abs(node1[1] - node2[1]))

    value = 10 * distance
    return value

#From https://www.youtube.com/watch?v=fa1NSUBqiJc
def aStar(graph, start, end):
    frontier = PriorityQueue()
    frontier.put(intVec(start), 0)
    path = {}
    cost = {}
    path[intVec(start)] = None
    cost[intVec(start)] = 0

    while frontier.empty() == False:
        current = frontier.get()
        if current == end:
            break
        for next in graph.getNeighbors(vec(current)):
            next = intVec(next)
            nextCost = cost[current] + graph.cost(current, next)
            if next not in cost or nextCost < cost[next]:
                cost[next] = nextCost
                priority = nextCost + ruleOfThumb(end, vec(next))
                frontier.put(next, priority)
                path[next] = vec(current) - vec(next)
    
    return path

def findRoute(diction, playerInital, gridMousePos):
    playerInital = intVec(playerInital)
    pathMap = []
    while playerInital != (gridMousePos): #should be mouse position
        if playerInital in diction:
            tempDirect = diction[playerInital]
            tempDirect = intVec(tempDirect)

            tempPos = (playerInital[0] + tempDirect[0],
                        playerInital[1] + tempDirect[1])

            pathMap.append(tempPos)

            playerInital = tempPos

    print(pathMap)
    return pathMap


g= DijkGrid(90, 38)
path = aStar(g, vec(28,28), vec(70,32))

Line1 = Line(screen, (105,105,105), (80,80), (900,80), 4)
Line2 = Line(screen, (105,105,105), (80,80), (80,380), 4)
Line3 = Line(screen, (105,105,105), (80,380), (900,380), 4)
Line4 = Line(screen, (105,105,105), (900,80), (900,380), 4)

Line5 = Line(screen, (105,105,105), (920,80), (1080,80), 4)
Line6 = Line(screen, (105,105,105), (920,80), (920,380), 4)
Line7 = Line(screen, (105,105,105), (920,380), (1080,380), 4)
Line8 = Line(screen, (105,105,105), (1080,80), (1080,380), 4)

Line9 = Line(screen, (105,105,105), (80,400), (1080,400), 4)
Line10 = Line(screen, (105,105,105), (80,400), (80,680), 4)
Line11 = Line(screen, (105,105,105), (80,680), (1080,680), 4)
Line12 = Line(screen, (105,105,105), (1080,400), (1080,680), 4)

Line13 = Line(screen, (105,105,105), (1100,80), (1170,80), 4)
Line14 = Line(screen, (105,105,105), (1100,680), (1170,680), 4)
Line15 = Line(screen, (105,105,105), (1100,80), (1100,680), 4)
Line16 = Line(screen, (105,105,105), (1170,80), (1170,680), 4)

#ScrollIndicator
Line17 = Line(screen, (105,105,105), (1055,420), (1055,660), 4) #Black 240
Line18 = Line(screen, (255,255,255), (1055,440), (1055,490), 4) #White 50

#itemBlock
rect1 = Rect(screen, (105,105,105), (1113,120,45,45)) #Item bar 1-5
rect2 = Rect(screen, (105,105,105), (1113,240,45,45))
rect3 = Rect(screen, (105,105,105), (1113,360,45,45))
rect4 = Rect(screen, (105,105,105), (1113,480,45,45))
rect5 = Rect(screen, (105,105,105), (1113,600,45,45))

#Recitation outline
Line19 = Line(screen, (105,105,105), (230,230), (746,230), 2)
Line20 = Line(screen, (105,105,105), (80,380), (230,230), 2)
Line21 = Line(screen, (105,105,105), (900,380), (746,230), 2)
Line22 = Line(screen, (105,105,105), (230,80), (230,230), 2)
Line23 = Line(screen, (105,105,105), (746,80), (746,230), 2)

#Recitation Screen
Line24 = Line(screen, (105,105,105), (260,100), (550,100), 2)
Line25 = Line(screen, (105,105,105), (260,200), (550,200), 2)
Line26 = Line(screen, (105,105,105), (260,100), (260,200), 2)
Line27 = Line(screen, (105,105,105), (550,100), (550,200), 2)

#Game frame
day = Text("Day 2", 33, (85,30), 0)
week = Text("Week 3", 33, (195,10), 0)
time = Text("Noon", 33, (335,40), 0)

#How to smartly break lines
firstLine = Text("...Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod",
                        30, (100,420), 0)
secondLine = Text("tempor incididunt ut labore et dolore magna aliqua.",
                         30, (110,450), 0)
thirdLine = Text("...Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu",
                         30,(100,500), 0)
fourthLine = Text("fugiat nulla pariatur.",
                         30,(110,530), 0)
fifthLine = Text("...Etiam erat velit scelerisque in. Metus dictum at tempor commodo ullamco",
                         30,(100,580), 0)
sixthLine = Text("met nisl purus consequat id porta nibh in mollis nunc sed id semper.",
                         30,(110,610), 0)


#Recitation Things
#employee1 = Clickable("employee", 18, (765,265), -45)
#day = Text("Day 2", 33, (85,30), 0)
#Line18 = Line(screen, (105,105,105), (1055,440), (1055,490), 4)

#TAs
click1 = Clickable("TA", 28, (650,220), 0)
click2 = Clickable("TA", 28, (220,220), 0)
click3 = Clickable("TA", 30, (200,240), 0)

click4 = Clickable("d", 28, (870,260), 0)
click5 = Clickable("o", 28, (870,280), 0)
click6 = Clickable("o", 28, (870,300), 0)
click7 = Clickable("r", 28, (873,320), 0)

click8 = Clickable("computer", 12, (595, 240), 0)

#click9 = Clickable("You", 26, (660,280), 0)

click10 = Clickable("heater", 24, (150,230), 45)
click11 = Clickable("heater", 24, (105,275), 45)

text1 = Text("podium", 33, (600,240), 0)
text2 = Text("S", 26, (280,280), 0)
text3 = Text("S", 26, (320,280), 0)
text4 = Text("S", 26, (480,280), 0)
#text5 = Text("You", 26, (660,280), 0)
text6 = Text("S", 28, (260,310), 0)
text7 = Text("S", 28, (300,310), 0)
text8 = Text("S", 28, (340,310), 0)
text9 = Text("S", 28, (380,310), 0)
text10 = Text("S", 28, (420,310), 0)
text11 = Text("S", 28, (420,310), 0)
text12 = Text("S", 28, (460,310), 0)
text13 = Text("S", 28, (500,310), 0)
text14 = Text("S", 28, (540,310), 0)
text15 = Text("S", 28, (580,310), 0)
text16 = Text("S", 28, (620,310), 0)
text17 = Text("S", 28, (660,310), 0)
text18 = Text("S", 28, (700,310), 0)
text19 = Text("S", 28, (740,310), 0)
text20 = Text("S", 28, (780,310), 0)
text21 = Text("S", 28, (220,310), 0)
text22 = Text("S", 30, (180,340), 0)
text23 = Text("S", 30, (220,340), 0)
text24 = Text("S", 30, (260,340), 0)
text25 = Text("S", 30, (300,340), 0)
text26 = Text("S", 30, (340,340), 0)
text27 = Text("S", 30, (380,340), 0)
text28 = Text("S", 30, (420,340), 0)
text29 = Text("S", 30, (460,340), 0)
text30 = Text("S", 30, (500,340), 0)
text31 = Text("S", 30, (540,340), 0)
text32 = Text("S", 30, (580,340), 0)
text33 = Text("S", 30, (620,340), 0)
text34 = Text("S", 30, (660,340), 0)
text35 = Text("S", 30, (700,340), 0)
text36 = Text("S", 30, (740,340), 0)
text37 = Text("S", 30, (780,340), 0)

you = Character("You", 12, (700,320), 3)


choice1 = Clickable("listen", 24, (950,150), 0)
choice2 = Clickable("question", 24, (950,180), 0)
choice3 = Clickable("sleep", 24, (950,210), 0)


choices = [choice1, choice2, choice3]


frames = [firstLine, secondLine, thirdLine, fourthLine, 
        fifthLine, sixthLine]

texts = [text1, text2, text3, text4, text6, text7, text8, text9,
        text10, text11, text12, text13, text14, text15, text16, text17,
        text18, text19, text20, text21, text22, text23, text24, text25,
        text26, text27, text28, text29, text30, text31, text32, text33,
        text34, text35, text36, text37]

clickables = [click1, click2, click3, click4, click5, click6, click7, click8,
            click10, click11]
things = [click1, click2, click3, click4, click5, click6, click7, click8,
            click10, click11]

Lines = [Line1, Line2, Line3, Line4, Line5, Line6, Line7, Line8, Line9, Line10, 
        Line11, Line12, Line13, Line14, Line15, Line16, Line17, Line18, Line19,
        Line20, Line21, Line22, Line23, Line24, Line25, Line26, Line27]

rects = [rect1, rect2, rect3, rect4, rect5]

selection = []

materials = []

characters = [you]

def display(time):
    clock = pygame.time.Clock()
    clock.tick(200)
    pygame.event.pump()
    screen.fill((255, 255, 255))
    g = DijkGrid(90, 38)
    g.walls = getObstacles(things)
    #drawGrid()
    #g.draw()
    pathDiction = {}


    action = Text(f'Action: {objectCharacter.Ben.actionPoint} / 4', 18, (930,100), 0)
    action.draw()

    health = Text(f'Health: {str(objectCharacter.Ben.health)}', 24, (930,280), 0)
    sanity = Text(f'Sanity: {str(objectCharacter.Ben.sanity)}', 24, (930,310), 0)
    knowledge = Text(f'Knowledge: {str(objectCharacter.Ben.knowledge)}', 24, (930,340), 0)
    health.draw()
    sanity.draw()
    knowledge.draw()


    for choice in choices:
        if choice.rect.collidepoint(pygame.mouse.get_pos()):
            choice.hovered = True
        else:
            choice.hovered = False
        
        choice.draw()
    
    if len(objectCharacter.Ben.pathMap) > 0:
    #print(you.pos)
        nextPos = (objectCharacter.Ben.pathMap[0][0] * 10, 
                    objectCharacter.Ben.pathMap[0][1] * 10)
        objectCharacter.Ben.pathMap.pop(0)
        you.set_target(nextPos)
        vecYouPos = (you.pos[0]//10, you.pos[1]//10)
        you.update()

#Draw top hour day week
    day = Text(time[1], 33, (85,30), 0)
    week = Text(time[2], 33, (195,10), 0)
    hour = Text(time[0], 33, (335,40), 0)
    hour.draw()
    day.draw()
    week.draw()

#Original Frame
    for line in Lines:
        line.draw()
    
    for rect in rects:
        rect.draw()
        
#Game Frames
    objectText.textBox.draw()

#texts
    #for text in texts:
    for i in range (25):
        if len(selection) <= 25:
            pick = random.choice(texts)
            selection.append(pick)
    for text in selection:
        text.draw()
        

    for click in clickables:
        if click.rect.collidepoint(pygame.mouse.get_pos()):
            click.hovered = True
        else:
            click.hovered = False
        click.draw()

    for material in materials:
        #if len(materials) > 30:
            #materials.pop(0)
        material.draw()

    for chara in characters:
        chara.draw()
        chara.update()
        #pygame.draw.line(screen, (105, 105, 105), chara.pos, 
        #chara.endPoint, 1)
#Keys and sticks
    keys = pygame.key.get_pressed()

    if keys[pygame.K_a]:
        print ("space detected")
        quotes = ["recursion", "yummy cake", "magic square" ]
        randomquote = random.choice(quotes)
        randomX = random.randint(260, 500)                   
        randomY = random.randint(100, 190)
        material = Text(randomquote, 12, (randomX,randomY), 0)
        materials.append(material)

    if keys[pygame.K_SPACE]:
        objectCharacter.Ben.actionPoint = 4
        print("here it goes")
        return 42

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            run = False
            pygame.quit()

        if event.type == pygame.MOUSEBUTTONUP:
            cX, cY = pygame.mouse.get_pos()
            vecPos = vec(pygame.mouse.get_pos()) // TILESIZE
            if ((cX >= 80) and (cX <= 900) and (cY >=230) and (cY <=380)):
                if vecPos not in g.walls:
                    pathDiction = aStar(g, vecPos, 
                            vec(you.pos[0]//10, you.pos[1]//10))

                    objectCharacter.Ben.pathMap = findRoute(pathDiction, 
                                                    (you.pos[0]//10, you.pos[1]//10),
                                                        intVec(vecPos))
            for click in clickables:
                if click.rect.collidepoint(pygame.mouse.get_pos()):
                    if click == click4 or click == click5 or click == click6 \
                        or click == click7:
                        objectCharacter.Ben.actionPoint = 4
                        return 42

            for choice in choices:
                if choice.rect.collidepoint(pygame.mouse.get_pos()):
                    if objectCharacter.Ben.actionPoint > 0:
                        if choice == choice1:
                            objectCharacter.Ben.actionPoint -= 1
                            objectCharacter.Ben.health -= 1
                            objectCharacter.Ben.sanity -= 2
                            objectCharacter.Ben.knowledge += 5

                            response1 = {
                                "Hard question, you seem to be the only one who knows the answer.":(-1, -8, 8),
                                "With TA’s help, this question seems to no longer trouble you.":(-1, -6, 8),
                                "Do TAs get extra printing quotas when they print out 30 copies of that every week?":(1, -7, 2),
                                "With what your learned, you felt quiet confident about the next writing session":(-1, -7, 6),
                                "Oreos for those who participate? Oh the game is on":(-1, 5, 1),
                                "There are quite a few blank stares at the TA, you hope you were not one of them":(1, -4, 4),
                                "You sometimes wish that there would be a recitation that just let everyone to get some sleep":(-1, -10, -1),
                                "The TA is running out of time, you can almost see the anxiety coming out of their body.":(0, -4, -2),
                                "You wish you had VS Code with you when going reasoning over code":(-1, -7, -1)
                            }
                            tempResponse = random.choice(list(response1.keys()))
                            objectCharacter.Ben.health += response1[tempResponse][0]
                            objectCharacter.Ben.sanity += response1[tempResponse][1]
                            objectCharacter.Ben.knowledge += response1[tempResponse][2]
                            objectText.textBox.bundle(tempResponse, objectCharacter.Ben.sanity)

                        elif choice == choice2:
                            objectCharacter.Ben.actionPoint -= 1
                            objectCharacter.Ben.knowledge += 2
                            objectCharacter.Ben.sanity += 1

                            response2 = {
                                "There is no bad questions, but you do feel like you've ask a bit too much.":(-3, 0, 2),
                                "Good question.":(-1, 3, 4),
                            }

                            tempResponse = random.choice(list(response2.keys()))
                            objectCharacter.Ben.health += response2[tempResponse][0]
                            objectCharacter.Ben.sanity += response2[tempResponse][1]
                            objectCharacter.Ben.knowledge += response2[tempResponse][2]
                            objectText.textBox.bundle(tempResponse, 99)

                        elif choice == choice3:
                            objectCharacter.Ben.actionPoint -= 1
                            objectCharacter.Ben.TAAtt -= 1
                            objectCharacter.Ben.sanity += 5

                            response3 = {
                                "TAs voice came in from your right ear and came out from the left, your brain is no longer processing.":(1, 3, -2),
                                "You felt like recitation is the second easiest place to fall asleep, with lecture being the first.":(-1, 6, -3),
                                "You are tired, but so is everyone else, even TAs, but you seems to be the worst at pretending you are awake.":(1, 7, -5),
                                "TAs seem sad when they see you not paying attention, you are sad, too, but what can you do?":(-4, 8, -2),
                                "You wrote down the solution, you woke up.":(-1, 5, 0), 
                            }
                            tempResponse = random.choice(list(response3.keys()))
                            objectCharacter.Ben.health += response3[tempResponse][0]
                            objectCharacter.Ben.sanity += response3[tempResponse][1]
                            objectCharacter.Ben.knowledge += response3[tempResponse][2]
                            objectText.textBox.bundle(tempResponse, 99)

    pygame.display.update()


