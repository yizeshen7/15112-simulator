# https://gist.github.com/ohsqueezy/2802185

import slideCC
import objectDate
import objectCharacter
import objectText

import pygame
import random
pygame.init()
screen = pygame.display.set_mode((1280, 720))
pygame.display.set_caption("title")

class Text(object):
    grey = (105, 105, 105)
    white = (255, 255, 255)

    def __init__(self, text, size, position, tilt):
        self.text = text
        self.pos = position
        self.size = size
        self.tilt = tilt
        self.set_rect()
    
    def set_rect(self):
        font = pygame.font.SysFont('Times New Roman', self.size)
        rend = font.render(self.text, True, self.grey)
        rend = pygame.transform.rotate(rend, self.tilt)
        self.rend = rend
        self.rect = self.rend.get_rect()
        self.box = (self.pos[0], self.pos[1], self.rect[2], self.rect[3])
        self.rect.topleft = self.pos


    def draw(self):
        font = pygame.font.SysFont('Times New Roman', self.size)
        rend = font.render(self.text, True, self.grey)
        rend = pygame.transform.rotate(rend, self.tilt)
        screen.blit(rend, self.pos)

    #Concept(index into tuples & boxes) from https://stackoverflow.com/questions/35001207/how-to-detect-collision-between-objects-in-pygame
    def checkCollision(self, playerBox):

        playerX = playerBox[0]
        playerY = playerBox[1]
        playerWidth = playerBox[2]
        playerHeight = playerBox[3]

        obstacleX = self.box[0]
        obstacleY = self.box[1]
        obstacleWidth = self.box[2]
        obstacleHeight = self.box[3]


        myRight = playerX + playerWidth
        myLeft = playerX
        myTop = playerY
        myBottom = playerY + playerHeight

        otherRight = obstacleX + obstacleWidth
        otherLeft = obstacleX
        otherTop = obstacleY
        otherBottom = obstacleY + obstacleHeight

        checker = True

        if ((myRight < otherLeft) or (myLeft > otherRight) \
            or (myBottom < otherTop) or (myTop > otherBottom)):
            checker = False

        return checker

# Concept (global variable) taken from https://gist.github.com/ohsqueezy/2802185
class Clickable(object):

    def __init__(self, text, size, pos, tilt):
        self.text = text
        self.pos = pos
        self.size = size
        self.tilt = tilt
        self.hovered = False
        self.clicked = False
        self.set_rect()
        self.draw()

    def __repr__(self):
        return self.text
        
    def set_rend(self):
        font = pygame.font.SysFont('Times New Roman', self.size)
        self.rend = font.render(self.text, True, self.getcolor())
        self.rend = pygame.transform.rotate(self.rend, self.tilt)
        
    def getcolor(self):
        if self.hovered:
            return (0, 0, 0)
        else:
            return (105, 105, 105)
        
    def set_rect(self):
        self.set_rend()
        self.rect = self.rend.get_rect()
        self.box = (self.pos[0], self.pos[1], self.rect[2], self.rect[3])
        self.rect.topleft = self.pos
    
    
    #Concept(index into tuples & boxes) from https://stackoverflow.com/questions/35001207/how-to-detect-collision-between-objects-in-pygame
    def checkCollision(self, playerBox):
    #convert rectangles into x,y,w,h
        playerX = playerBox[0]
        playerY = playerBox[1]
        playerWidth = playerBox[2]
        playerHeight = playerBox[3]

        obstacleX = self.box[0]
        obstacleY = self.box[1]
        obstacleWidth = self.box[2]
        obstacleHeight = self.box[3]

        myRight = playerX + playerWidth
        myLeft = playerX
        myTop = playerY
        myBottom = playerY + playerHeight

        otherRight = obstacleX + obstacleWidth
        otherLeft = obstacleX
        otherTop = obstacleY
        otherBottom = obstacleY + obstacleHeight

        checker = True
        if ((myRight < otherLeft) or (myLeft > otherRight) \
            or (myBottom < otherTop) or (myTop > otherBottom)):
            checker = False
        return checker

    def draw(self):
        self.set_rend()
        screen.blit(self.rend, self.rect)


class Character(object):

    def __init__(self, text, size, pos, speed):
        self.text = text
        self.size = size
        self.pos = pos
        self.speed = speed
        self.set_rect()
        self.endPoint = (0,0)
        self.pos = pygame.Vector2(self.pos)
        self.set_target(self.pos)

    def set_target(self, pos):
        self.target = pygame.Vector2(pos)
        self.endPoint = pos

    def set_rend(self):
        font = pygame.font.SysFont('Times New Roman', self.size)
        self.rend = font.render(self.text, True, (105, 105, 105))

    def set_rect(self):
        self.set_rend()
        self.rect = self.rend.get_rect()
        self.box = (self.pos[0], self.pos[1], self.rect[2], self.rect[3])
        self.rect.topleft = self.pos
    
    def draw(self):
        font = pygame.font.SysFont('Times New Roman', self.size)
        rend = font.render(self.text, True, (105, 105, 105))
        screen.blit(rend, self.pos)

    #Concept(normalize_ip) taken from https://stackoverflow.com/questions/16288905/make-a-sprite-move-to-the-mouse-click-position-step-by-step
    def update(self):
        move = self.target - self.pos
        moveLength = move.length()

        if moveLength < self.speed:
            self.pos = self.target

        elif moveLength != 0:
            move.normalize_ip()
            move = move * self.speed
            self.pos += move

        self.box = (self.pos[0], self.pos[1], self.rect[2], self.rect[3])
    

click1 = Clickable("New Game", 40, (910,405), 0)
click2 = Clickable("Options", 40, (964,455), 0)
click3 = Clickable("Quit", 40, (1015,505), 0)

text1 = Text("15-112 Simulator", 72, (140,170), 0)

you = Character("You", 18, (700,320), 1)

clickables = [click1, click2, click3]

texts = [text1]

characters = []


def display(result):
    pygame.event.pump()
    screen.fill((255, 255, 255))

    for text in texts:

        if text.checkCollision(you.box) == True:

            if you.box[0] >= text.box[0]:
                you.pos[0] += 1
            elif you.box[0] < text.box[0]:
                you.pos[0] -= 1

            if you.box[1] >= text.box[1]:
                you.pos[1] += 1
            elif you.box[1] < text.box[1]:
                you.pos[1] -= 1

        text.draw()

    for click in clickables:
        if click.rect.collidepoint(pygame.mouse.get_pos()):
            click.hovered = True
        else:
            click.hovered = False
    
        if click.checkCollision(you.box) == True:

            if you.box[0] >= click.box[0]:
                you.pos[0] += 1
            elif you.box[0] < click.box[0]:
                you.pos[0] -= 1

            if you.box[1] >= click.box[1]:
                you.pos[1] += 1
            elif you.box[1] < click.box[1]:
                you.pos[1] -= 1
            
        click.draw()

    for chara in characters:
        chara.draw()
        chara.update()
        pygame.draw.line(screen, (105, 105, 105), chara.pos, 
        chara.endPoint, 1)
    
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            run = False
            pygame.quit()

        if event.type == pygame.MOUSEBUTTONUP:
            for click in clickables:
                if click.rect.collidepoint(pygame.mouse.get_pos()):
                    if click == click1:
                        print("new game")

                        time = (objectDate.current.hourSymbol[objectDate.current.hour], 
                                f'Day {objectDate.current.day}', 
                                f'Week {objectDate.current.week}')

                        while True:
                            slideCC.display(time)

                    elif click == click2:
                        print("option")

                    elif click == click3:
                        pygame.quit()

            if len(characters) > 0:
                chara.set_target(pygame.mouse.get_pos())

    pygame.display.update()
